import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

/**
 * Receptor / Servidor UDP.
 * Escucha en el puerto 9876, recibe los paquetes que llegan, muestra el texto
 * junto con la IP y el puerto de origen, y termina cuando recibe la palabra FIN.
 *
 * Hay que ejecutarlo ANTES que el cliente.
 */
public class ServidorUDP {

    private static final int PUERTO = 9876;
    private static final int TAMANIO_BUFFER = 1024;

    public static void main(String[] args) {
        // try-with-resources: el socket se cierra solo al terminar
        try (DatagramSocket socket = new DatagramSocket(PUERTO)) {

            System.out.println("Servidor UDP escuchando en el puerto " + PUERTO + "...");
            System.out.println("(se detiene cuando un cliente envía FIN)");
            System.out.println();

            boolean seguir = true;
            while (seguir) {
                // 1) Preparar un paquete vacío donde se va a guardar lo que llegue
                byte[] buffer = new byte[TAMANIO_BUFFER];
                DatagramPacket paquete = new DatagramPacket(buffer, buffer.length);

                // 2) Esperar un paquete (receive se queda bloqueado hasta que llega uno)
                socket.receive(paquete);

                // 3) Extraer los datos: solo los bytes recibidos (getLength), no todo el buffer
                String mensaje = new String(paquete.getData(), 0, paquete.getLength(), StandardCharsets.UTF_8);
                InetAddress ipOrigen = paquete.getAddress();
                int puertoOrigen = paquete.getPort();

                // 4) Mostrar el mensaje con la IP y el puerto de quien lo envió
                System.out.println("[" + ipOrigen.getHostAddress() + ":" + puertoOrigen + "] " + mensaje);

                // 5) Si el cliente envió FIN, se termina
                if (mensaje.trim().equalsIgnoreCase("FIN")) {
                    System.out.println();
                    System.out.println("El cliente " + ipOrigen.getHostAddress() + ":" + puertoOrigen
                            + " envió FIN. Cerrando el servidor.");
                    seguir = false;
                }
            }

        } catch (IOException e) {
            System.out.println("Error en el servidor: " + e.getMessage());
            System.out.println("¿Puede ser que el puerto " + PUERTO + " ya esté en uso?");
        }
    }
}
