import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

/**
 * Emisor / Cliente UDP.
 * Pide al usuario textos por consola y los envía al servidor por UDP.
 * Si el usuario escribe FIN, se lo envía al servidor (para avisarle) y cierra el socket.
 *
 * Para probar en la misma computadora se usa "localhost".
 * Para enviar a otra computadora, cambiar SERVIDOR por su IP (ej: "192.168.0.15").
 */
public class ClienteUDP {

    private static final String SERVIDOR = "localhost";
    private static final int PUERTO = 9876;

    public static void main(String[] args) {
        BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

        // El cliente no necesita un puerto fijo: el sistema le asigna uno libre
        try (DatagramSocket socket = new DatagramSocket()) {

            InetAddress direccionServidor = InetAddress.getByName(SERVIDOR);
            System.out.println("Cliente UDP. Enviando a " + SERVIDOR + ":" + PUERTO);
            System.out.println("Escribí mensajes y presioná ENTER. Escribí FIN para terminar.");
            System.out.println();

            boolean seguir = true;
            while (seguir) {
                System.out.print("> ");
                String mensaje = teclado.readLine();
                if (mensaje == null) {          // se cerró la entrada (Ctrl+D / Ctrl+Z): se avisa con FIN
                    mensaje = "FIN";
                }
                if (mensaje.isEmpty()) {
                    continue;                   // no se envían mensajes vacíos
                }

                // 1) Pasar el texto a bytes
                byte[] datos = mensaje.getBytes(StandardCharsets.UTF_8);

                // 2) Armar el paquete con los datos, la IP y el puerto del servidor
                DatagramPacket paquete = new DatagramPacket(datos, datos.length, direccionServidor, PUERTO);

                // 3) Enviarlo
                socket.send(paquete);

                // 4) Si fue FIN, ya se notificó al servidor: se termina
                if (mensaje.trim().equalsIgnoreCase("FIN")) {
                    seguir = false;
                }
            }
            System.out.println("Se envió FIN al servidor. Cerrando el socket del cliente.");

        } catch (IOException e) {
            System.out.println("Error en el cliente: " + e.getMessage());
        }
    }
}
