import java.util.ArrayList;
import java.util.HashMap;

/**
 * Ejercicio 9: Traductor de frases.
 * Pide una frase, la separa en palabras (split) y traduce cada una con el HashMap.
 * Si una palabra no existe se puede dejar igual o mostrar [???] (lo elige el usuario).
 */
public class Ejercicio09 {

    public static void main(String[] args) {
        HashMap<String, String> diccionario = Ejercicio07.cargarDiccionario();
        traducirFrase(diccionario);
    }

    public static void traducirFrase(HashMap<String, String> diccionario) {
        Color.titulo("Ejercicio 9: Traductor de frases");
        System.out.println("Palabras disponibles: " + diccionario.keySet());
        String frase = Entrada.texto("Frase a traducir: ");

        System.out.println("Si una palabra no está en el diccionario:");
        System.out.println("  1. Dejarla igual");
        System.out.println("  2. Mostrar [???]");
        int modo = Entrada.entero("Opción: ", 1, 2);

        String[] palabras = frase.toLowerCase().split(" ");
        ArrayList<String> traduccion = new ArrayList<>();
        for (String palabra : palabras) {
            if (palabra.isEmpty()) {
                continue;
            }
            String traducida;
            if (diccionario.containsKey(palabra)) {
                traducida = Color.pintar(diccionario.get(palabra), Color.VERDE);
            } else if (modo == 1) {
                traducida = palabra;
            } else {
                traducida = Color.pintar("[???]", Color.ROJO);
            }
            traduccion.add(traducida);
        }

        System.out.println("Original:  " + frase);
        System.out.println("Traducida: " + String.join(" ", traduccion));
    }
}
