/**
 * Colores ANSI para la consola.
 * Funcionan en la terminal de IntelliJ, VS Code, Eclipse (2022+), Windows Terminal, Linux y macOS.
 */
public class Color {

    public static final String RESET = "\u001B[0m";
    public static final String ROJO = "\u001B[31m";
    public static final String VERDE = "\u001B[32m";
    public static final String AMARILLO = "\u001B[33m";
    public static final String AZUL = "\u001B[34m";
    public static final String MAGENTA = "\u001B[35m";
    public static final String CIAN = "\u001B[36m";
    public static final String NEGRITA = "\u001B[1m";

    /** Colores para ir rotando cuando se muestra una lista. */
    public static final String[] PALETA = {ROJO, VERDE, AMARILLO, AZUL, MAGENTA, CIAN};

    public static String pintar(String texto, String color) {
        return color + texto + RESET;
    }

    public static void titulo(String texto) {
        System.out.println();
        System.out.println(NEGRITA + CIAN + "=== " + texto + " ===" + RESET);
    }

    public static void ok(String texto) {
        System.out.println(pintar(texto, VERDE));
    }

    public static void error(String texto) {
        System.out.println(pintar(texto, ROJO));
    }
}
