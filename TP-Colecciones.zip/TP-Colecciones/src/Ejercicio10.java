import java.util.HashMap;
import java.util.Map;

/**
 * Ejercicio 10: Contador de palabras.
 * Pide una frase y cuenta cuántas veces aparece cada palabra con un HashMap<String, Integer>.
 * Ej: "hola hola chau" → hola: 2, chau: 1
 */
public class Ejercicio10 {

    public static void main(String[] args) {
        contar();
    }

    public static void contar() {
        Color.titulo("Ejercicio 10: Contador de palabras");
        String frase = Entrada.texto("Escribí una frase: ");

        // Minúsculas y sin signos de puntuación, así "Hola," y "hola" cuentan como la misma
        String limpia = frase.toLowerCase().replaceAll("[^a-záéíóúüñ0-9 ]", " ");
        String[] palabras = limpia.split(" ");

        HashMap<String, Integer> contador = new HashMap<>();
        for (String palabra : palabras) {
            if (palabra.isEmpty()) {
                continue;
            }
            if (contador.containsKey(palabra)) {
                contador.put(palabra, contador.get(palabra) + 1);
            } else {
                contador.put(palabra, 1);
            }
        }

        for (Map.Entry<String, Integer> entrada : contador.entrySet()) {
            System.out.println("→ " + entrada.getKey() + ": " + entrada.getValue());
        }
    }
}
