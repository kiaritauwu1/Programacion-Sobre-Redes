import java.util.ArrayList;

/**
 * Ejercicio 2: Buscar elemento.
 * Pide un nombre e informa si existe (contains) y en qué posición está (indexOf).
 * Si no existe, muestra el mensaje en rojo.
 */
public class Ejercicio02 {

    public static void main(String[] args) {
        ArrayList<String> nombres = Ejercicio01.cargarNombres();
        buscar(nombres);
    }

    public static void buscar(ArrayList<String> nombres) {
        Color.titulo("Ejercicio 2: Buscar elemento");
        System.out.println("Lista: " + nombres);
        String buscado = Entrada.texto("Nombre a buscar: ");

        if (nombres.contains(buscado)) {
            int posicion = nombres.indexOf(buscado);
            Color.ok("\"" + buscado + "\" existe en la lista.");
            System.out.println("Está en la posición " + posicion + " (índice) → lugar número " + (posicion + 1) + ".");
        } else {
            Color.error("\"" + buscado + "\" NO existe en la lista. (indexOf devuelve " + nombres.indexOf(buscado) + ")");
        }
    }
}
