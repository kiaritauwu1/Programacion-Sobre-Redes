import java.util.HashMap;

/**
 * Ejercicio 8: Traductor.
 * Pide una palabra, la busca en el diccionario (get) y muestra la traducción,
 * o un error si no existe (containsKey).
 */
public class Ejercicio08 {

    public static void main(String[] args) {
        HashMap<String, String> diccionario = Ejercicio07.cargarDiccionario();
        traducir(diccionario);
    }

    public static void traducir(HashMap<String, String> diccionario) {
        Color.titulo("Ejercicio 8: Traductor");
        String palabra = Entrada.texto("Palabra a traducir: ").toLowerCase();

        if (diccionario.containsKey(palabra)) {
            Color.ok(palabra + " → " + diccionario.get(palabra));
        } else {
            Color.error("Error: \"" + palabra + "\" no está en el diccionario.");
        }
    }
}
