import java.util.ArrayList;
import java.util.HashMap;

/**
 * Menú general. Guarda los datos entre ejercicios:
 *  - la lista de nombres del Ej. 1 la usan el 2, 3 y 4
 *  - la lista de palabras del Ej. 5 la usa el 6
 *  - el diccionario del Ej. 7 lo usan el 8 y el 9
 * Si un ejercicio necesita datos que todavía no se cargaron, los pide primero.
 * (Cada EjercicioXX también tiene su propio main y se puede ejecutar solo.)
 */
public class Main {

    private static ArrayList<String> nombres;
    private static ArrayList<String> palabras;
    private static HashMap<String, String> diccionario;

    public static void main(String[] args) {
        int opcion;
        do {
            Color.titulo("COLECCIONES: ArrayList, HashMap y HashSet");
            System.out.println(" 1. Lista de nombres          7. Diccionario simple");
            System.out.println(" 2. Buscar elemento           8. Traductor");
            System.out.println(" 3. Modificar lista           9. Traductor de frases");
            System.out.println(" 4. Recorrer lista           10. Contador de palabras");
            System.out.println(" 5. Procesar texto           11. Eliminar duplicados");
            System.out.println(" 6. Normalización            12. Sistema de alumnos");
            System.out.println(" 0. Salir");
            opcion = Entrada.entero("Elegí un ejercicio: ", 0, 12);

            switch (opcion) {
                case 1:
                    nombres = Ejercicio01.cargarNombres();
                    Ejercicio01.mostrar(nombres);
                    break;
                case 2: Ejercicio02.buscar(nombresCargados()); break;
                case 3: Ejercicio03.modificar(nombresCargados()); break;
                case 4: Ejercicio04.recorrer(nombresCargados()); break;
                case 5:
                    palabras = Ejercicio05.cargarPalabras();
                    Ejercicio05.procesar(palabras);
                    break;
                case 6: Ejercicio06.normalizar(palabrasCargadas()); break;
                case 7:
                    diccionario = Ejercicio07.cargarDiccionario();
                    Ejercicio07.mostrar(diccionario);
                    break;
                case 8: Ejercicio08.traducir(diccionarioCargado()); break;
                case 9: Ejercicio09.traducirFrase(diccionarioCargado()); break;
                case 10: Ejercicio10.contar(); break;
                case 11: Ejercicio11.eliminarDuplicados(); break;
                case 12: Ejercicio12.main(args); break;
                default: Color.ok("¡Hasta luego!");
            }
        } while (opcion != 0);
    }

    private static ArrayList<String> nombresCargados() {
        if (nombres == null) {
            Color.error("Primero hay que cargar la lista del Ejercicio 1.");
            nombres = Ejercicio01.cargarNombres();
        }
        return nombres;
    }

    private static ArrayList<String> palabrasCargadas() {
        if (palabras == null) {
            Color.error("Primero hay que cargar la frase del Ejercicio 5.");
            palabras = Ejercicio05.cargarPalabras();
        }
        return palabras;
    }

    private static HashMap<String, String> diccionarioCargado() {
        if (diccionario == null) {
            Color.error("Primero hay que cargar el diccionario del Ejercicio 7.");
            diccionario = Ejercicio07.cargarDiccionario();
        }
        return diccionario;
    }
}
