import java.util.ArrayList;
import java.util.Iterator;

/**
 * Ejercicio 4: Recorrer lista de 3 formas (for clásico, for-each, Iterator),
 * cada elemento en un color distinto. Además se muestra el error típico de usar <=.
 */
public class Ejercicio04 {

    public static void main(String[] args) {
        ArrayList<String> nombres = Ejercicio01.cargarNombres();
        recorrer(nombres);
    }

    public static void recorrer(ArrayList<String> nombres) {
        Color.titulo("Ejercicio 4: Recorrer lista");

        // Error típico: i <= size() se pasa una posición (los índices van de 0 a size()-1)
        System.out.println(Color.pintar("For clásico CON ERROR (i <= nombres.size()):", Color.AMARILLO));
        try {
            for (int i = 0; i <= nombres.size(); i++) {
                System.out.println("  [" + i + "] " + nombres.get(i));
            }
        } catch (IndexOutOfBoundsException e) {
            Color.error("  ¡Error detectado! " + e.getClass().getSimpleName() + ": " + e.getMessage());
            Color.error("  Con <= se intenta leer el índice " + nombres.size()
                    + ", que no existe. Hay que usar i < nombres.size().");
        }

        // 1) For clásico correcto
        System.out.println(Color.pintar("\n1) For clásico (i < nombres.size()):", Color.NEGRITA));
        for (int i = 0; i < nombres.size(); i++) {
            System.out.println("  [" + i + "] " + Color.pintar(nombres.get(i), colorDe(i)));
        }

        // 2) For-each
        System.out.println(Color.pintar("\n2) For-each:", Color.NEGRITA));
        int i = 0;
        for (String nombre : nombres) {
            System.out.println("  - " + Color.pintar(nombre, colorDe(i)));
            i++;
        }

        // 3) Iterator
        System.out.println(Color.pintar("\n3) Iterator:", Color.NEGRITA));
        Iterator<String> it = nombres.iterator();
        i = 0;
        while (it.hasNext()) {
            System.out.println("  > " + Color.pintar(it.next(), colorDe(i)));
            i++;
        }
    }

    private static String colorDe(int indice) {
        return Color.PALETA[indice % Color.PALETA.length];
    }
}
