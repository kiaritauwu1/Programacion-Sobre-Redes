import java.util.Scanner;

/** Lectura de datos por teclado (un único Scanner para todo el programa). */
public class Entrada {

    private static final Scanner TECLADO = new Scanner(System.in);

    /** Pide un texto. Si el usuario no escribe nada, vuelve a preguntar. */
    public static String texto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            if (!TECLADO.hasNextLine()) {
                System.out.println();
                System.exit(0);   // se terminó la entrada (Ctrl+D / Ctrl+Z)
            }
            String linea = TECLADO.nextLine().trim();
            if (!linea.isEmpty()) {
                return linea;
            }
            Color.error("No puede estar vacío.");
        }
    }

    /** Pide un número entero entre minimo y maximo. */
    public static int entero(String mensaje, int minimo, int maximo) {
        while (true) {
            String linea = texto(mensaje);
            try {
                int valor = Integer.parseInt(linea);
                if (valor >= minimo && valor <= maximo) {
                    return valor;
                }
            } catch (NumberFormatException e) {
                // cae al mensaje de error
            }
            Color.error("Ingresá un número entero entre " + minimo + " y " + maximo + ".");
        }
    }
}
