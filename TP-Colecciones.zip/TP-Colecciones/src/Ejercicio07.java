import java.util.HashMap;
import java.util.Map;

/**
 * Ejercicio 7: Diccionario simple.
 * HashMap<String, String> con 5 palabras en español y su traducción (put).
 * Muestra todo (entrySet), solo claves (keySet) y solo valores (values).
 */
public class Ejercicio07 {

    public static final int CANTIDAD = 5;

    public static void main(String[] args) {
        HashMap<String, String> diccionario = cargarDiccionario();
        mostrar(diccionario);
    }

    /** Pide las 5 palabras. Lo usan también los ejercicios 8 y 9. */
    public static HashMap<String, String> cargarDiccionario() {
        Color.titulo("Ejercicio 7: Diccionario simple");
        HashMap<String, String> diccionario = new HashMap<>();
        while (diccionario.size() < CANTIDAD) {
            int numero = diccionario.size() + 1;
            String espanol = Entrada.texto("Palabra " + numero + " en español: ").toLowerCase();
            if (diccionario.containsKey(espanol)) {
                Color.error("Esa palabra ya está cargada, ingresá otra.");
                continue;
            }
            String traduccion = Entrada.texto("Traducción de \"" + espanol + "\": ").toLowerCase();
            diccionario.put(espanol, traduccion);
        }
        return diccionario;
    }

    public static void mostrar(HashMap<String, String> diccionario) {
        System.out.println(Color.pintar("\nDiccionario completo (entrySet):", Color.NEGRITA));
        for (Map.Entry<String, String> entrada : diccionario.entrySet()) {
            System.out.println("  " + entrada.getKey() + " → " + entrada.getValue());
        }

        System.out.println(Color.pintar("Solo claves (keySet):", Color.NEGRITA));
        System.out.println("  " + diccionario.keySet());

        System.out.println(Color.pintar("Solo valores (values):", Color.NEGRITA));
        System.out.println("  " + diccionario.values());
    }
}
