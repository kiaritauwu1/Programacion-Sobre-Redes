import java.util.ArrayList;
import java.util.HashMap;

/**
 * Ejercicio 12: Sistema de alumnos.
 *  - ArrayList<String>         → nombres (en el orden en que se cargaron)
 *  - HashMap<String, Integer>  → nombre → nota
 * Menú: agregar, mostrar todos, buscar, modificar nota, promedio.
 * Bonus: aprobado/desaprobado y colores.
 */
public class Ejercicio12 {

    private static final int NOTA_MINIMA = 1;
    private static final int NOTA_MAXIMA = 10;
    private static final int NOTA_APROBACION = 6;

    private static final ArrayList<String> nombres = new ArrayList<>();
    private static final HashMap<String, Integer> notas = new HashMap<>();

    public static void main(String[] args) {
        int opcion;
        do {
            Color.titulo("Ejercicio 12: Sistema de alumnos");
            System.out.println("1. Agregar alumno");
            System.out.println("2. Mostrar todos");
            System.out.println("3. Buscar alumno");
            System.out.println("4. Modificar nota");
            System.out.println("5. Mostrar promedio");
            System.out.println("0. Salir");
            opcion = Entrada.entero("Opción: ", 0, 5);

            switch (opcion) {
                case 1: agregar(); break;
                case 2: mostrarTodos(); break;
                case 3: buscar(); break;
                case 4: modificarNota(); break;
                case 5: mostrarPromedio(); break;
                default: Color.ok("¡Hasta luego!");
            }
        } while (opcion != 0);
    }

    private static void agregar() {
        String nombre = Entrada.texto("Nombre del alumno: ");
        if (notas.containsKey(nombre)) {
            Color.error("Ya existe un alumno llamado " + nombre + ".");
            return;
        }
        int nota = pedirNota();
        nombres.add(nombre);
        notas.put(nombre, nota);
        Color.ok("Alumno " + nombre + " agregado.");
    }

    private static void mostrarTodos() {
        if (nombres.isEmpty()) {
            Color.error("No hay alumnos cargados.");
            return;
        }
        System.out.printf("%-4s %-20s %5s   %s%n", "#", "NOMBRE", "NOTA", "ESTADO");
        for (int i = 0; i < nombres.size(); i++) {
            String nombre = nombres.get(i);
            int nota = notas.get(nombre);
            System.out.printf("%-4d %-20s %5d   %s%n", i + 1, nombre, nota, estado(nota));
        }
    }

    private static void buscar() {
        String nombre = Entrada.texto("Nombre a buscar: ");
        if (notas.containsKey(nombre)) {
            int nota = notas.get(nombre);
            Color.ok("Encontrado: " + nombre + " (posición " + (nombres.indexOf(nombre) + 1) + ")");
            System.out.println("Nota: " + nota + " → " + estado(nota));
        } else {
            Color.error("No existe un alumno llamado " + nombre + ".");
        }
    }

    private static void modificarNota() {
        String nombre = Entrada.texto("Nombre del alumno: ");
        if (!notas.containsKey(nombre)) {
            Color.error("No existe un alumno llamado " + nombre + ".");
            return;
        }
        System.out.println("Nota actual: " + notas.get(nombre));
        int nueva = pedirNota();
        notas.put(nombre, nueva);   // put sobre una clave existente reemplaza el valor
        Color.ok("Nota de " + nombre + " actualizada a " + nueva + " → " + estado(nueva));
    }

    private static void mostrarPromedio() {
        if (nombres.isEmpty()) {
            Color.error("No hay alumnos cargados.");
            return;
        }
        int suma = 0;
        int aprobados = 0;
        for (int nota : notas.values()) {
            suma += nota;
            if (nota >= NOTA_APROBACION) {
                aprobados++;
            }
        }
        double promedio = (double) suma / notas.size();
        String color = promedio >= NOTA_APROBACION ? Color.VERDE : Color.ROJO;
        System.out.println("Promedio del curso: " + Color.pintar(String.format("%.2f", promedio), color));
        System.out.println(Color.pintar("Aprobados: " + aprobados, Color.VERDE) + "  |  "
                + Color.pintar("Desaprobados: " + (notas.size() - aprobados), Color.ROJO));
    }

    private static int pedirNota() {
        return Entrada.entero("Nota (" + NOTA_MINIMA + " a " + NOTA_MAXIMA + "): ", NOTA_MINIMA, NOTA_MAXIMA);
    }

    private static String estado(int nota) {
        return nota >= NOTA_APROBACION
                ? Color.pintar("APROBADO", Color.VERDE)
                : Color.pintar("DESAPROBADO", Color.ROJO);
    }
}
