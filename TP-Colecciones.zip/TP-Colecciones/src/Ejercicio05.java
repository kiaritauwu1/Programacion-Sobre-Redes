import java.util.ArrayList;

/**
 * Ejercicio 5: Procesar texto.
 * Pide una frase, la separa en palabras (split), las guarda en un ArrayList y muestra:
 * cantidad de palabras, la más larga y cuántas contienen una letra elegida.
 */
public class Ejercicio05 {

    public static void main(String[] args) {
        ArrayList<String> palabras = cargarPalabras();
        procesar(palabras);
    }

    /** Pide la frase y la separa. Lo usa también el ejercicio 6. */
    public static ArrayList<String> cargarPalabras() {
        Color.titulo("Ejercicio 5: Procesar texto");
        String frase = Entrada.texto("Escribí una frase: ");
        String[] partes = frase.split(" ");   // split por espacio

        ArrayList<String> palabras = new ArrayList<>();
        for (String parte : partes) {
            if (!parte.isEmpty()) {           // si había dos espacios seguidos queda un "" que se descarta
                palabras.add(parte);
            }
        }
        return palabras;
    }

    public static void procesar(ArrayList<String> palabras) {
        System.out.println("Palabras: " + palabras);
        System.out.println("Cantidad de palabras: " + palabras.size());

        String masLarga = "";
        for (String palabra : palabras) {
            if (palabra.length() > masLarga.length()) {
                masLarga = palabra;
            }
        }
        System.out.println("Palabra más larga: " + masLarga + " (" + masLarga.length() + " letras)");

        String letra = Entrada.texto("Letra a buscar: ").substring(0, 1).toLowerCase();
        int contador = 0;
        for (String palabra : palabras) {
            if (palabra.toLowerCase().contains(letra)) {
                contador++;
            }
        }
        System.out.println("Palabras que contienen la letra '" + letra + "': " + contador);
    }
}
