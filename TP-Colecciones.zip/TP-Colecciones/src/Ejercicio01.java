import java.util.ArrayList;

/**
 * Ejercicio 1: Lista de nombres.
 * Pide 5 nombres, los guarda en un ArrayList y muestra: lista completa,
 * cantidad, primero y último. Extra: los nombres en mayúsculas.
 */
public class Ejercicio01 {

    public static final int CANTIDAD = 5;

    public static void main(String[] args) {
        ArrayList<String> nombres = cargarNombres();
        mostrar(nombres);
    }

    /** Pide los 5 nombres. Lo usan también los ejercicios 2, 3 y 4. */
    public static ArrayList<String> cargarNombres() {
        Color.titulo("Carga de " + CANTIDAD + " nombres");
        ArrayList<String> nombres = new ArrayList<>();
        for (int i = 1; i <= CANTIDAD; i++) {
            nombres.add(Entrada.texto("Nombre " + i + ": "));
        }
        return nombres;
    }

    public static void mostrar(ArrayList<String> nombres) {
        Color.titulo("Ejercicio 1: Lista de nombres");
        System.out.println("Lista completa: " + nombres);
        System.out.println("Cantidad de elementos: " + nombres.size());
        System.out.println("Primero: " + nombres.get(0));
        System.out.println("Último: " + nombres.get(nombres.size() - 1));

        // Extra: en mayúsculas
        ArrayList<String> mayusculas = new ArrayList<>();
        for (String nombre : nombres) {
            mayusculas.add(nombre.toUpperCase());
        }
        System.out.println("En mayúsculas: " + mayusculas);
    }
}
