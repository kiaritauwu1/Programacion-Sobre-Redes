import java.util.ArrayList;

/**
 * Ejercicio 6: Normalización.
 * Toma la lista del ejercicio 5 y: pasa todo a minúscula, elimina espacios (trim)
 * y reemplaza las vocales por *.
 */
public class Ejercicio06 {

    public static void main(String[] args) {
        ArrayList<String> palabras = Ejercicio05.cargarPalabras();
        normalizar(palabras);
    }

    public static ArrayList<String> normalizar(ArrayList<String> palabras) {
        Color.titulo("Ejercicio 6: Normalización");
        System.out.println("Original:   " + palabras);

        ArrayList<String> normalizadas = new ArrayList<>();
        for (String palabra : palabras) {
            String p = palabra.toLowerCase();                  // 1) minúscula
            p = p.trim();                                      // 2) sin espacios en los extremos
            p = p.replaceAll("[aeiouáéíóúü]", "*");            // 3) vocales (con o sin tilde) por *
            normalizadas.add(p);
        }

        System.out.println("Normalizada: " + normalizadas);
        return normalizadas;
    }
}
