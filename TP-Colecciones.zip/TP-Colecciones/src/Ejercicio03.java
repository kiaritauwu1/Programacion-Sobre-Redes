import java.util.ArrayList;

/**
 * Ejercicio 3: Modificar lista.
 * Reemplaza el tercer elemento (set), elimina un elemento por nombre (remove)
 * y muestra la lista final.
 */
public class Ejercicio03 {

    public static void main(String[] args) {
        ArrayList<String> nombres = Ejercicio01.cargarNombres();
        modificar(nombres);
    }

    public static void modificar(ArrayList<String> nombres) {
        Color.titulo("Ejercicio 3: Modificar lista");
        System.out.println("Lista actual: " + nombres);

        // Reemplazar el tercer elemento (índice 2)
        if (nombres.size() >= 3) {
            String nuevo = Entrada.texto("Nuevo valor para el 3er elemento (\"" + nombres.get(2) + "\"): ");
            String anterior = nombres.set(2, nuevo);
            Color.ok("Se reemplazó \"" + anterior + "\" por \"" + nuevo + "\".");
        } else {
            Color.error("La lista tiene menos de 3 elementos, no se puede reemplazar el tercero.");
        }
        System.out.println("Lista: " + nombres);

        // Eliminar por nombre
        String aBorrar = Entrada.texto("Nombre a eliminar: ");
        if (nombres.remove(aBorrar)) {          // remove(Object) devuelve true si lo encontró
            Color.ok("Se eliminó \"" + aBorrar + "\".");
        } else {
            Color.error("\"" + aBorrar + "\" no está en la lista, no se eliminó nada.");
        }

        System.out.println("Lista final: " + nombres);
    }
}
