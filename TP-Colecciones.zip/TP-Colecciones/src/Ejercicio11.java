import java.util.ArrayList;
import java.util.HashSet;

/**
 * Ejercicio 11: Eliminar duplicados.
 * Pide una lista de números, los guarda en un ArrayList, los pasa a un HashSet
 * y muestra la lista original y la lista sin repetidos.
 */
public class Ejercicio11 {

    public static void main(String[] args) {
        eliminarDuplicados();
    }

    public static void eliminarDuplicados() {
        Color.titulo("Ejercicio 11: Eliminar duplicados");
        ArrayList<Integer> numeros = new ArrayList<>();

        while (numeros.isEmpty()) {
            String linea = Entrada.texto("Ingresá números separados por espacio o coma (ej: 3 5 3 8 5): ");
            for (String parte : linea.split("[ ,]+")) {
                if (parte.isEmpty()) {
                    continue;
                }
                try {
                    numeros.add(Integer.parseInt(parte));
                } catch (NumberFormatException e) {
                    Color.error("  \"" + parte + "\" no es un número entero, se ignora.");
                }
            }
            if (numeros.isEmpty()) {
                Color.error("No se ingresó ningún número válido.");
            }
        }

        HashSet<Integer> sinRepetidos = new HashSet<>(numeros);

        System.out.println("Lista original (" + numeros.size() + "): " + numeros);
        System.out.println("Sin repetidos (" + sinRepetidos.size() + "): " + sinRepetidos);
        System.out.println("Se eliminaron " + (numeros.size() - sinRepetidos.size()) + " repetidos.");
    }
}
