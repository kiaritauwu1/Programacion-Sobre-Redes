import java.util.ArrayList;

/**
 * Sistema de Inventario.
 * Menú en bucle: Agregar producto, Mostrar, Editar, Eliminar y Salir.
 * Los datos se guardan en "Inventario.dat" (nombre;precioCompra;precioVenta;stock).
 */
public class Main {

    private static final int STOCK_BAJO = 10;   // a partir de cuánto se marca el stock en amarillo

    public static void main(String[] args) {
        if (ArchivoInventario.crear()) {
            Consola.ok("Se creó el archivo " + ArchivoInventario.ARCHIVO.getName());
        }

        boolean seguir = true;
        while (seguir) {
            mostrarMenu();
            String opcion = Consola.preguntar("Elegí una opción: ");
            switch (opcion) {
                case "1": agregarProducto(); break;
                case "2": mostrarProductos(); Consola.pausa(); break;
                case "3": editarProducto(); break;
                case "4": eliminarProducto(); break;
                case "5": seguir = false; break;
                default:  Consola.error("Opción inválida. Elegí un número del 1 al 5.");
            }
        }
        Consola.SALIDA.println(Color.pintar("\n\t¡Hasta luego!\n", Color.NEGRITA + Color.MAGENTA));
    }

    // =====================================================================
    //  MENÚ
    // =====================================================================

    private static void mostrarMenu() {
        Consola.titulo("SISTEMA DE INVENTARIO");
        Consola.SALIDA.println();
        Consola.SALIDA.println("\t" + Color.pintar("1.", Color.AMARILLO) + "\tAgregar producto");
        Consola.SALIDA.println("\t" + Color.pintar("2.", Color.AMARILLO) + "\tMostrar");
        Consola.SALIDA.println("\t" + Color.pintar("3.", Color.AMARILLO) + "\tEditar");
        Consola.SALIDA.println("\t" + Color.pintar("4.", Color.AMARILLO) + "\tEliminar");
        Consola.SALIDA.println("\t" + Color.pintar("5.", Color.ROJO) + "\tSalir");
        Consola.SALIDA.println();
    }

    // =====================================================================
    //  1. AGREGAR
    // =====================================================================

    private static void agregarProducto() {
        Consola.titulo("AGREGAR PRODUCTO");
        ArrayList<Producto> productos = ArchivoInventario.leer();

        String nombre;
        while (true) {
            nombre = Consola.pedirTexto("Nombre: ");
            if (ArchivoInventario.buscarPorNombre(productos, nombre) >= 0) {
                Consola.error("Ya existe un producto llamado \"" + nombre + "\".");
            } else {
                break;
            }
        }
        float compra = Consola.pedirFloatPositivo("Precio de compra: $");
        float venta = Consola.pedirFloatPositivo("Precio de venta:  $");
        if (venta < compra) {
            Consola.aviso("El precio de venta es menor al de compra: se vendería a pérdida.");
        }
        int stock = Consola.pedirEntero("Stock: ", 0);

        Producto nuevo = new Producto(nombre, compra, venta, stock);
        if (ArchivoInventario.agregar(nuevo)) {
            Consola.ok("Producto \"" + nombre + "\" guardado en " + ArchivoInventario.ARCHIVO.getName() + ".");
        }
    }

    // =====================================================================
    //  2. MOSTRAR
    // =====================================================================

    /** Muestra la tabla alineada. Devuelve la lista leída (la usan Editar y Eliminar). */
    private static ArrayList<Producto> mostrarProductos() {
        Consola.titulo("INVENTARIO");
        ArrayList<Producto> productos = ArchivoInventario.leer();
        if (productos.isEmpty()) {
            Consola.aviso("El inventario está vacío. Agregá un producto con la opción 1.");
            return productos;
        }

        String formatoTitulo = "\t%-4s %-20s %14s %14s %12s %8s%n";
        String separador = "\t" + "─".repeat(77);

        Consola.SALIDA.println();
        Consola.SALIDA.print(Color.NEGRITA + Color.CIAN);
        Consola.SALIDA.printf(formatoTitulo, "N°", "NOMBRE", "P. COMPRA", "P. VENTA", "GANANCIA", "STOCK");
        Consola.SALIDA.print(Color.RESET);
        Consola.SALIDA.println(Color.pintar(separador, Color.GRIS));

        float valorTotal = 0;
        int unidades = 0;
        for (int i = 0; i < productos.size(); i++) {
            Producto p = productos.get(i);

            // Primero se arma cada columna con su ancho y después se colorea,
            // así los códigos de color no desalinean la tabla.
            String numero = String.format("%-4s", (i + 1) + ".");
            String nombre = String.format("%-20s", recortar(p.getNombre(), 20));
            String compra = String.format("%14s", dinero(p.getPrecioCompra()));
            String venta = String.format("%14s", dinero(p.getPrecioVenta()));
            String ganancia = String.format("%12s", dinero(p.getGanancia()));
            String stock = String.format("%8d", p.getStock());

            String colorGanancia = p.getGanancia() >= 0 ? Color.VERDE : Color.ROJO;
            String colorStock = p.getStock() == 0 ? Color.ROJO
                    : p.getStock() < STOCK_BAJO ? Color.AMARILLO : Color.RESET;

            Consola.SALIDA.println("\t" + Color.pintar(numero, Color.AMARILLO) + " " + nombre + " "
                    + compra + " " + venta + " "
                    + Color.pintar(ganancia, colorGanancia) + " "
                    + Color.pintar(stock, colorStock));

            valorTotal += p.getValorStock();
            unidades += p.getStock();
        }

        Consola.SALIDA.println(Color.pintar(separador, Color.GRIS));
        Consola.SALIDA.println("\tProductos: " + Color.pintar(String.valueOf(productos.size()), Color.NEGRITA)
                + "\tUnidades: " + Color.pintar(String.valueOf(unidades), Color.NEGRITA)
                + "\tValor del stock (compra): " + Color.pintar(dinero(valorTotal), Color.NEGRITA + Color.VERDE));
        Consola.SALIDA.println(Color.pintar("\tStock en rojo = agotado · en amarillo = menos de " + STOCK_BAJO
                + " unidades", Color.GRIS));
        Consola.SALIDA.println();
        return productos;
    }

    // =====================================================================
    //  3. EDITAR
    // =====================================================================

    private static void editarProducto() {
        ArrayList<Producto> productos = mostrarProductos();
        if (productos.isEmpty()) {
            return;
        }
        int posicion = elegirProducto(productos, "editar");
        if (posicion < 0) {
            return;
        }
        Producto p = productos.get(posicion);
        Consola.SALIDA.println(Color.pintar("\n\tEditando \"" + p.getNombre() + "\". "
                + "Dejá vacío (ENTER) para conservar el valor actual.\n", Color.GRIS));

        // Nombre
        while (true) {
            String nombre = Consola.preguntar("Nombre [" + p.getNombre() + "]: ");
            if (nombre.isEmpty()) break;
            if (nombre.contains(";")) {
                Consola.error("No se puede usar el carácter ';'.");
                continue;
            }
            int otro = ArchivoInventario.buscarPorNombre(productos, nombre);
            if (otro >= 0 && otro != posicion) {
                Consola.error("Ya existe otro producto llamado \"" + nombre + "\".");
                continue;
            }
            p.setNombre(nombre);
            break;
        }
        p.setPrecioCompra(editarFloat("Precio de compra", p.getPrecioCompra()));
        p.setPrecioVenta(editarFloat("Precio de venta", p.getPrecioVenta()));
        if (p.getPrecioVenta() < p.getPrecioCompra()) {
            Consola.aviso("El precio de venta es menor al de compra: se vendería a pérdida.");
        }
        p.setStock(editarEntero("Stock", p.getStock()));

        if (ArchivoInventario.editar(posicion, p)) {
            Consola.ok("Producto actualizado en " + ArchivoInventario.ARCHIVO.getName() + ".");
        }
    }

    /** Pide un nuevo float positivo; si se deja vacío devuelve el valor actual. */
    private static float editarFloat(String campo, float actual) {
        while (true) {
            String texto = Consola.preguntar(campo + " [" + dinero(actual) + "]: $");
            if (texto.isEmpty()) {
                return actual;
            }
            if (!Consola.esNumerico(texto)) {
                Consola.error("\"" + texto + "\" no es un número.");
                continue;
            }
            float valor = Consola.aFloat(texto, -1f);
            if (valor > 0) {
                return valor;
            }
            Consola.error("Tiene que ser mayor que cero.");
        }
    }

    /** Pide un nuevo entero >= 0; si se deja vacío devuelve el valor actual. */
    private static int editarEntero(String campo, int actual) {
        while (true) {
            String texto = Consola.preguntar(campo + " [" + actual + "]: ");
            if (texto.isEmpty()) {
                return actual;
            }
            switch (Consola.tipoDeDato(texto)) {
                case ENTERO:
                    int valor = Consola.aInt(texto, -1);
                    if (valor >= 0) {
                        return valor;
                    }
                    Consola.error("Tiene que ser un entero mayor o igual a 0.");
                    break;
                case DECIMAL:
                    Consola.error("\"" + texto + "\" es decimal. El stock tiene que ser ENTERO.");
                    break;
                default:
                    Consola.error("\"" + texto + "\" no es un número.");
            }
        }
    }

    // =====================================================================
    //  4. ELIMINAR
    // =====================================================================

    private static void eliminarProducto() {
        ArrayList<Producto> productos = mostrarProductos();
        if (productos.isEmpty()) {
            return;
        }
        int posicion = elegirProducto(productos, "eliminar");
        if (posicion < 0) {
            return;
        }
        String nombre = productos.get(posicion).getNombre();
        if (Consola.confirmar("¿Seguro que querés eliminar \"" + nombre + "\"?")) {
            if (ArchivoInventario.eliminar(posicion)) {
                Consola.ok("Producto \"" + nombre + "\" eliminado de " + ArchivoInventario.ARCHIVO.getName() + ".");
            }
        } else {
            Consola.aviso("No se eliminó nada.");
        }
    }

    // =====================================================================
    //  AUXILIARES
    // =====================================================================

    /**
     * Pide el número de producto (o su nombre). 0 cancela.
     * Devuelve la posición en la lista (desde 0) o -1 si se canceló.
     */
    private static int elegirProducto(ArrayList<Producto> productos, String accion) {
        while (true) {
            String texto = Consola.preguntar("N° o nombre del producto a " + accion + " (0 = cancelar): ");
            if (texto.equals("0")) {
                Consola.aviso("Operación cancelada.");
                return -1;
            }
            if (Consola.esEntero(texto)) {
                int numero = Consola.aInt(texto, -1);
                if (numero >= 1 && numero <= productos.size()) {
                    return numero - 1;
                }
                Consola.error("No existe el producto N° " + texto + ".");
            } else {
                int posicion = ArchivoInventario.buscarPorNombre(productos, texto);
                if (posicion >= 0) {
                    return posicion;
                }
                Consola.error("No existe un producto llamado \"" + texto + "\".");
            }
        }
    }

    private static String dinero(float valor) {
        return String.format("$ %,.2f", valor);
    }

    private static String recortar(String texto, int maximo) {
        return texto.length() <= maximo ? texto : texto.substring(0, maximo - 1) + ".";
    }
}
