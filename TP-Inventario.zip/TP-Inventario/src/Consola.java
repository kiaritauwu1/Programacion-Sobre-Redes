import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;

/**
 * Lectura de consola, validación de tipo de dato y conversiones seguras.
 *  - Lectura: métodos de la clase Reader (read()), devolviendo un String.
 *  - Escritura: PrintStream (System.out).
 */
public class Consola {

    /** Resultado de analizar un texto. */
    public enum TipoDato { NO_NUMERICO, ENTERO, DECIMAL }

    private static final Reader ENTRADA = new InputStreamReader(System.in);
    public static final PrintStream SALIDA = System.out;

    // =====================================================================
    //  LECTURA
    // =====================================================================

    /**
     * Lee una línea de la consola carácter por carácter con Reader.read()
     * y la devuelve como String (sin espacios en los extremos).
     * Si se termina la entrada (Ctrl+D / Ctrl+Z) devuelve null.
     */
    public static String leer() {
        StringBuilder linea = new StringBuilder();
        try {
            int c = ENTRADA.read();
            if (c == -1) {
                return null;
            }
            while (c != -1 && c != '\n') {
                if (c != '\r') {
                    linea.append((char) c);
                }
                c = ENTRADA.read();
            }
        } catch (IOException e) {
            error("Error al leer la consola: " + e.getMessage());
            return null;
        }
        return linea.toString().trim();
    }

    /** Muestra un mensaje y lee la respuesta. Si se cerró la entrada, termina el programa. */
    public static String preguntar(String mensaje) {
        SALIDA.print(Color.pintar("  » ", Color.CIAN) + mensaje);
        SALIDA.flush();
        String respuesta = leer();
        if (respuesta == null) {
            SALIDA.println();
            SALIDA.println(Color.pintar("\n  Entrada finalizada. Saliendo...", Color.AMARILLO));
            System.exit(0);
        }
        return respuesta;
    }

    // =====================================================================
    //  VALIDACIÓN DEL TIPO DE DATO
    // =====================================================================

    /**
     * Indica si el texto es NO_NUMERICO, ENTERO o DECIMAL.
     * Acepta signo inicial y como separador decimal tanto '.' como ','.
     *   "240" → ENTERO   "50.6" / "50,6" → DECIMAL   "abc" / "" / "5.2.1" → NO_NUMERICO
     */
    public static TipoDato tipoDeDato(String texto) {
        if (texto == null || texto.isEmpty()) {
            return TipoDato.NO_NUMERICO;
        }
        int inicio = (texto.charAt(0) == '-' || texto.charAt(0) == '+') ? 1 : 0;
        boolean hayDigito = false;
        boolean haySeparador = false;

        for (int i = inicio; i < texto.length(); i++) {
            char c = texto.charAt(i);
            if (Character.isDigit(c)) {
                hayDigito = true;
            } else if ((c == '.' || c == ',') && !haySeparador) {
                haySeparador = true;
            } else {
                return TipoDato.NO_NUMERICO;
            }
        }
        if (!hayDigito) {
            return TipoDato.NO_NUMERICO;
        }
        return haySeparador ? TipoDato.DECIMAL : TipoDato.ENTERO;
    }

    public static boolean esNumerico(String texto) {
        return tipoDeDato(texto) != TipoDato.NO_NUMERICO;
    }

    public static boolean esEntero(String texto) {
        return tipoDeDato(texto) == TipoDato.ENTERO;
    }

    public static boolean esDecimal(String texto) {
        return tipoDeDato(texto) == TipoDato.DECIMAL;
    }

    // =====================================================================
    //  CONVERSIONES SEGURAS (nunca lanzan excepción)
    // =====================================================================

    /** Convierte a int. Si el texto no es un entero válido devuelve valorPorDefecto. */
    public static int aInt(String texto, int valorPorDefecto) {
        if (!esEntero(texto)) {
            return valorPorDefecto;
        }
        try {
            return Integer.parseInt(texto);
        } catch (NumberFormatException e) {   // por ejemplo, un número demasiado grande
            return valorPorDefecto;
        }
    }

    /** Convierte a float (acepta enteros y decimales con '.' o ','). Si no es número devuelve valorPorDefecto. */
    public static float aFloat(String texto, float valorPorDefecto) {
        if (!esNumerico(texto)) {
            return valorPorDefecto;
        }
        try {
            float valor = Float.parseFloat(texto.replace(',', '.'));
            return Float.isInfinite(valor) ? valorPorDefecto : valor;
        } catch (NumberFormatException e) {
            return valorPorDefecto;
        }
    }

    // =====================================================================
    //  PEDIDOS CON VALIDACIÓN (repiten hasta que el dato sea correcto)
    // =====================================================================

    /** Pide un texto obligatorio que no contenga ';' (es el separador del archivo). */
    public static String pedirTexto(String mensaje) {
        while (true) {
            String texto = preguntar(mensaje);
            if (texto.isEmpty()) {
                error("Este dato es obligatorio.");
            } else if (texto.contains(";")) {
                error("No se puede usar el carácter ';'.");
            } else {
                return texto;
            }
        }
    }

    /** Pide un entero mayor o igual a minimo. */
    public static int pedirEntero(String mensaje, int minimo) {
        while (true) {
            String texto = preguntar(mensaje);
            switch (tipoDeDato(texto)) {
                case ENTERO:
                    int valor = aInt(texto, Integer.MIN_VALUE);
                    if (valor == Integer.MIN_VALUE) {
                        error("El número es demasiado grande.");
                    } else if (valor < minimo) {
                        error("Tiene que ser mayor o igual a " + minimo + ".");
                    } else {
                        return valor;
                    }
                    break;
                case DECIMAL:
                    error("\"" + texto + "\" es decimal. Se necesita un número ENTERO.");
                    break;
                default:
                    error("\"" + texto + "\" no es un número.");
            }
        }
    }

    /** Pide un número (entero o decimal) mayor que cero. */
    public static float pedirFloatPositivo(String mensaje) {
        while (true) {
            String texto = preguntar(mensaje);
            if (!esNumerico(texto)) {
                error("\"" + texto + "\" no es un número.");
                continue;
            }
            float valor = aFloat(texto, -1f);
            if (valor <= 0) {
                error("Tiene que ser mayor que cero.");
            } else {
                return valor;
            }
        }
    }

    /** Pregunta S/N. */
    public static boolean confirmar(String mensaje) {
        while (true) {
            String r = preguntar(mensaje + Color.pintar(" (S/N): ", Color.GRIS)).toUpperCase();
            if (r.equals("S")) return true;
            if (r.equals("N")) return false;
            error("Respondé S o N.");
        }
    }

    // =====================================================================
    //  SALIDA CON FORMATO
    // =====================================================================

    public static void titulo(String texto) {
        String linea = "═".repeat(texto.length() + 4);
        SALIDA.println();
        SALIDA.println(Color.pintar("  ╔" + linea + "╗", Color.AZUL));
        SALIDA.println(Color.pintar("  ║  ", Color.AZUL) + Color.pintar(texto, Color.NEGRITA + Color.CIAN)
                + Color.pintar("  ║", Color.AZUL));
        SALIDA.println(Color.pintar("  ╚" + linea + "╝", Color.AZUL));
    }

    public static void ok(String texto) {
        SALIDA.println(Color.pintar("  [OK] " + texto, Color.VERDE));
    }

    public static void error(String texto) {
        SALIDA.println(Color.pintar("  [ERROR] " + texto, Color.ROJO));
    }

    public static void aviso(String texto) {
        SALIDA.println(Color.pintar("  [AVISO] " + texto, Color.AMARILLO));
    }

    public static void pausa() {
        preguntar(Color.pintar("Presioná ENTER para continuar...", Color.GRIS));
    }
}
