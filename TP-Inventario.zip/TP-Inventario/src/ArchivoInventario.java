import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Persistencia del inventario en "Inventario.dat" (texto plano, campos separados por ';').
 *  - Escritura: PrintWriter.
 *  - Lectura: BufferedReader.
 * El archivo se crea en la carpeta del proyecto (desde donde se ejecuta el programa).
 */
public class ArchivoInventario {

    public static final File ARCHIVO = new File("Inventario.dat");

    /** Crea el archivo vacío si todavía no existe. Devuelve true si lo creó. */
    public static boolean crear() {
        if (ARCHIVO.exists()) {
            return false;
        }
        try (PrintWriter pw = new PrintWriter(ARCHIVO, "UTF-8")) {
            // se crea vacío
        } catch (IOException e) {
            Consola.error("No se pudo crear " + ARCHIVO.getName() + ": " + e.getMessage());
            return false;
        }
        return true;
    }

    /** Lee todos los productos del archivo. Los renglones mal formados se informan y se ignoran. */
    public static ArrayList<Producto> leer() {
        ArrayList<Producto> productos = new ArrayList<>();
        crear();
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO, StandardCharsets.UTF_8))) {
            String linea;
            int numeroLinea = 0;
            while ((linea = br.readLine()) != null) {
                numeroLinea++;
                if (linea.trim().isEmpty()) {
                    continue;
                }
                Producto p = Producto.desdeLinea(linea);
                if (p == null) {
                    Consola.aviso("Renglón " + numeroLinea + " con formato inválido, se ignora: " + linea);
                } else {
                    productos.add(p);
                }
            }
        } catch (IOException e) {
            Consola.error("No se pudo leer " + ARCHIVO.getName() + ": " + e.getMessage());
        }
        return productos;
    }

    /** Sobrescribe el archivo con la lista completa de productos. */
    public static boolean escribir(ArrayList<Producto> productos) {
        try (PrintWriter pw = new PrintWriter(ARCHIVO, "UTF-8")) {
            for (Producto p : productos) {
                pw.println(p.aLinea());
            }
        } catch (IOException e) {
            Consola.error("No se pudo escribir " + ARCHIVO.getName() + ": " + e.getMessage());
            return false;
        }
        return true;
    }

    /** Agrega un producto al final del archivo. */
    public static boolean agregar(Producto nuevo) {
        ArrayList<Producto> productos = leer();
        productos.add(nuevo);
        return escribir(productos);
    }

    /** Reemplaza el producto de la posición indicada (empezando en 0). */
    public static boolean editar(int posicion, Producto modificado) {
        ArrayList<Producto> productos = leer();
        if (posicion < 0 || posicion >= productos.size()) {
            return false;
        }
        productos.set(posicion, modificado);
        return escribir(productos);
    }

    /** Elimina del archivo el producto de la posición indicada (empezando en 0). */
    public static boolean eliminar(int posicion) {
        ArrayList<Producto> productos = leer();
        if (posicion < 0 || posicion >= productos.size()) {
            return false;
        }
        productos.remove(posicion);
        return escribir(productos);
    }

    /** Busca un producto por nombre (sin importar mayúsculas). Devuelve su posición o -1. */
    public static int buscarPorNombre(ArrayList<Producto> productos, String nombre) {
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getNombre().equalsIgnoreCase(nombre)) {
                return i;
            }
        }
        return -1;
    }
}
