/**
 * Un artículo del inventario.
 * En el archivo se guarda como: nombre;precioCompra;precioVenta;stock
 * Ejemplo: manzana;50.6;100.7;240
 */
public class Producto {

    public static final String SEPARADOR = ";";

    private String nombre;
    private float precioCompra;
    private float precioVenta;
    private int stock;

    public Producto(String nombre, float precioCompra, float precioVenta, int stock) {
        this.nombre = nombre;
        this.precioCompra = precioCompra;
        this.precioVenta = precioVenta;
        this.stock = stock;
    }

    /** Convierte el producto en un renglón del archivo. */
    public String aLinea() {
        return nombre + SEPARADOR + precioCompra + SEPARADOR + precioVenta + SEPARADOR + stock;
    }

    /**
     * Crea un producto a partir de un renglón del archivo.
     * Devuelve null si el renglón no tiene el formato correcto.
     */
    public static Producto desdeLinea(String linea) {
        if (linea == null) {
            return null;
        }
        String[] campos = linea.split(SEPARADOR, -1);
        if (campos.length != 4 || campos[0].trim().isEmpty()) {
            return null;
        }
        String nombre = campos[0].trim();
        String compra = campos[1].trim();
        String venta = campos[2].trim();
        String stock = campos[3].trim();

        if (!Consola.esNumerico(compra) || !Consola.esNumerico(venta) || !Consola.esEntero(stock)) {
            return null;
        }
        return new Producto(nombre,
                Consola.aFloat(compra, 0f),
                Consola.aFloat(venta, 0f),
                Consola.aInt(stock, 0));
    }

    /** Ganancia por unidad. */
    public float getGanancia() {
        return precioVenta - precioCompra;
    }

    /** Valor del stock a precio de compra. */
    public float getValorStock() {
        return precioCompra * stock;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public float getPrecioCompra() { return precioCompra; }
    public void setPrecioCompra(float precioCompra) { this.precioCompra = precioCompra; }

    public float getPrecioVenta() { return precioVenta; }
    public void setPrecioVenta(float precioVenta) { this.precioVenta = precioVenta; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
}
