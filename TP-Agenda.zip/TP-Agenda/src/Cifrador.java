import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Cifrado AES con la biblioteca nativa de Java (javax.crypto.Cipher).
 *
 * Se usa AES en modo GCM ("AES/GCM/NoPadding"):
 *  - Cada nota se cifra con un IV (vector de inicialización) aleatorio de 12 bytes,
 *    así dos notas iguales nunca quedan iguales en el archivo.
 *  - GCM además detecta si el texto cifrado fue modificado o está corrupto.
 *
 * Lo que se guarda es Base64( IV + texto cifrado ). Base64 nunca contiene ';',
 * así que no rompe el separador de campos del archivo.
 *
 * La clave AES (128 bits) se genera la primera vez y se guarda en "agenda.key".
 * Sin ese archivo las notas no se pueden desencriptar.
 */
public class Cifrador {

    private static final String ALGORITMO = "AES";
    private static final String TRANSFORMACION = "AES/GCM/NoPadding";
    private static final int BITS_CLAVE = 128;
    private static final int BYTES_IV = 12;
    private static final int BITS_TAG = 128;

    private final SecretKey clave;
    private final SecureRandom aleatorio = new SecureRandom();

    /** Carga la clave desde el archivo, o la genera y la guarda si no existe. */
    public Cifrador(File archivoClave) throws IOException, GeneralSecurityException {
        if (archivoClave.exists()) {
            clave = leerClave(archivoClave);
        } else {
            KeyGenerator generador = KeyGenerator.getInstance(ALGORITMO);
            generador.init(BITS_CLAVE, aleatorio);
            clave = generador.generateKey();

            ArrayList<String> contenido = new ArrayList<>();
            contenido.add(Base64.getEncoder().encodeToString(clave.getEncoded()));
            ArchivoSeguro.escribir(archivoClave, contenido);
            Consola.aviso("Se generó una clave AES nueva en " + archivoClave.getName()
                    + ". Sin ella no se pueden leer las notas privadas.");
        }
    }

    private static SecretKey leerClave(File archivo) throws IOException, GeneralSecurityException {
        String base64;
        try (BufferedReader br = new BufferedReader(new FileReader(archivo, StandardCharsets.UTF_8))) {
            base64 = br.readLine();
        }
        if (base64 == null) {
            throw new GeneralSecurityException("el archivo de clave está vacío");
        }
        byte[] bytes;
        try {
            bytes = Base64.getDecoder().decode(base64.trim());
        } catch (IllegalArgumentException e) {
            throw new GeneralSecurityException("el archivo de clave no es Base64 válido");
        }
        if (bytes.length != 16 && bytes.length != 24 && bytes.length != 32) {
            throw new GeneralSecurityException("la clave no tiene un tamaño AES válido");
        }
        return new SecretKeySpec(bytes, ALGORITMO);
    }

    /** Encripta un texto y lo devuelve en Base64 (IV + datos cifrados). */
    public String encriptar(String texto) throws GeneralSecurityException {
        byte[] iv = new byte[BYTES_IV];
        aleatorio.nextBytes(iv);

        Cipher cipher = Cipher.getInstance(TRANSFORMACION);
        cipher.init(Cipher.ENCRYPT_MODE, clave, new GCMParameterSpec(BITS_TAG, iv));
        byte[] cifrado = cipher.doFinal(texto.getBytes(StandardCharsets.UTF_8));

        byte[] resultado = new byte[iv.length + cifrado.length];
        System.arraycopy(iv, 0, resultado, 0, iv.length);
        System.arraycopy(cifrado, 0, resultado, iv.length, cifrado.length);
        return Base64.getEncoder().encodeToString(resultado);
    }

    /** Desencripta un texto generado por encriptar(). Lanza excepción si está corrupto o la clave no coincide. */
    public String desencriptar(String base64) throws GeneralSecurityException {
        byte[] datos;
        try {
            datos = Base64.getDecoder().decode(base64);
        } catch (IllegalArgumentException e) {
            throw new GeneralSecurityException("no es Base64 válido");
        }
        if (datos.length < BYTES_IV + BITS_TAG / 8) {
            throw new GeneralSecurityException("datos cifrados incompletos");
        }
        Cipher cipher = Cipher.getInstance(TRANSFORMACION);
        cipher.init(Cipher.DECRYPT_MODE, clave, new GCMParameterSpec(BITS_TAG, datos, 0, BYTES_IV));
        byte[] plano = cipher.doFinal(datos, BYTES_IV, datos.length - BYTES_IV);
        return new String(plano, StandardCharsets.UTF_8);
    }
}
