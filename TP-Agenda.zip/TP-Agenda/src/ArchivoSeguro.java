import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * Lectura y escritura SEGURA de archivos de texto.
 *
 * Nunca se escribe directo sobre el archivo principal. Para guardar:
 *   1. Se escribe todo en un archivo temporal en la MISMA carpeta (ej: agenda.dat.123.tmp).
 *   2. Se fuerza a que los datos lleguen al disco (sync), por si se corta la luz.
 *   3. Si no hubo ningún error, el temporal reemplaza al original con un movimiento ATÓMICO:
 *      el sistema operativo cambia uno por otro en un solo paso, así que en cualquier momento
 *      existe o el archivo viejo completo o el nuevo completo, nunca uno a medio escribir.
 * Si algo falla, se borra el temporal y el original queda intacto.
 */
public class ArchivoSeguro {

    /** Lee todas las líneas con BufferedReader. Si el archivo no existe devuelve una lista vacía. */
    public static List<String> leer(File archivo) throws IOException {
        List<String> lineas = new ArrayList<>();
        if (!archivo.exists()) {
            return lineas;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(archivo, StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                lineas.add(linea);
            }
        }
        return lineas;
    }

    /** Guarda las líneas en el archivo usando un temporal y un reemplazo atómico. */
    public static void escribir(File destino, List<String> lineas) throws IOException {
        File carpeta = destino.getAbsoluteFile().getParentFile();
        File temporal = File.createTempFile(destino.getName() + ".", ".tmp", carpeta);

        try {
            // 1) y 2) Escribir el temporal con PrintWriter y forzar el guardado en disco
            FileOutputStream salida = new FileOutputStream(temporal);
            try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(salida, StandardCharsets.UTF_8))) {
                for (String linea : lineas) {
                    pw.println(linea);
                }
                pw.flush();
                if (pw.checkError()) {      // PrintWriter no lanza excepciones: hay que preguntarle
                    throw new IOException("falló la escritura del archivo temporal");
                }
                salida.getFD().sync();
            }

            // 3) Reemplazo atómico del original
            try {
                Files.move(temporal.toPath(), destino.toPath(),
                        StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                // Muy raro (algunos discos de red). Se reemplaza igual, pero avisando.
                Consola.aviso("El sistema no permite reemplazo atómico; se usa reemplazo normal.");
                Files.move(temporal.toPath(), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            // Si se movió con éxito ya no existe; si hubo error se limpia
            if (temporal.exists()) {
                temporal.delete();
            }
        }
    }

    /**
     * Borra temporales que hayan quedado de una ejecución que se cortó a mitad de un guardado.
     * Devuelve cuántos se borraron. El archivo original no se toca.
     */
    public static int limpiarTemporales(File destino) {
        File carpeta = destino.getAbsoluteFile().getParentFile();
        String prefijo = destino.getName() + ".";
        File[] sobrantes = carpeta.listFiles((dir, nombre) -> nombre.startsWith(prefijo) && nombre.endsWith(".tmp"));
        int borrados = 0;
        if (sobrantes != null) {
            for (File f : sobrantes) {
                if (f.delete()) {
                    borrados++;
                }
            }
        }
        return borrados;
    }
}
