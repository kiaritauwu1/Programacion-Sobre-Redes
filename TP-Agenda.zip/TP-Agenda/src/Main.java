import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;
import java.util.function.Function;

/**
 * AGENDA SEGURA
 *  - Al iniciar carga agenda.dat en una colección (ArrayList) en memoria.
 *  - Agregar / Mostrar / Editar / Quitar trabajan sobre la colección y guardan al instante.
 *  - La Nota Privada se guarda encriptada con AES (javax.crypto.Cipher) y se
 *    desencripta en tiempo real al mostrarla.
 *  - El guardado usa un archivo temporal + reemplazo atómico (ver ArchivoSeguro).
 */
public class Main {

    private static Agenda agenda;

    public static void main(String[] args) {
        Consola.titulo("AGENDA SEGURA  ·  AES");
        try {
            agenda = new Agenda();
        } catch (IOException | GeneralSecurityException e) {
            Consola.error("No se pudo iniciar la agenda: " + e.getMessage());
            return;
        }

        boolean seguir = true;
        while (seguir) {
            mostrarMenu();
            String opcion = Consola.preguntar("Elegí una opción: ");
            switch (opcion) {
                case "1": agregar(); break;
                case "2": mostrar(); Consola.pausa(); break;
                case "3": editar(); break;
                case "4": quitar(); break;
                case "5": verArchivo(); Consola.pausa(); break;
                case "6": seguir = false; break;
                default:  Consola.error("Opción inválida. Elegí un número del 1 al 6.");
            }
        }
        Consola.SALIDA.println(Color.pintar("\n\t¡Hasta luego! Tus datos quedaron guardados.\n",
                Color.NEGRITA + Color.MAGENTA));
    }

    // =====================================================================
    //  MENÚ
    // =====================================================================

    private static void mostrarMenu() {
        Consola.titulo("MENÚ PRINCIPAL");
        Consola.SALIDA.println(Color.pintar("\tContactos en memoria: " + agenda.cantidad(), Color.GRIS));
        Consola.SALIDA.println();
        opcionMenu("1", "Agregar contacto", Color.VERDE);
        opcionMenu("2", "Mostrar agenda", Color.CIAN);
        opcionMenu("3", "Editar contacto", Color.AMARILLO);
        opcionMenu("4", "Quitar contacto", Color.ROJO);
        opcionMenu("5", "Ver agenda.dat tal como se guarda (nota cifrada)", Color.MAGENTA);
        opcionMenu("6", "Salir", Color.GRIS);
        Consola.SALIDA.println();
    }

    private static void opcionMenu(String numero, String texto, String color) {
        Consola.SALIDA.println("\t" + Color.pintar(numero + ".", Color.NEGRITA + color) + "\t" + texto);
    }

    // =====================================================================
    //  1. AGREGAR
    // =====================================================================

    private static void agregar() {
        Consola.titulo("AGREGAR CONTACTO");
        String nombre = pedirCampo("Nombre", null, texto -> validarNombre(texto, -1));
        String telefono = pedirCampo("Teléfono", null, Main::validarTelefono);
        String email = pedirCampo("Email", null, Main::validarEmail);
        String nota = Consola.preguntar("Nota privada " + Color.pintar("(se guarda encriptada, puede quedar vacía)", Color.GRIS) + ": ");

        try {
            agenda.agregar(nombre, telefono, email, nota);
            Consola.ok("Contacto \"" + nombre + "\" agregado y guardado en " + Agenda.ARCHIVO.getName() + ".");
        } catch (IOException | GeneralSecurityException e) {
            Consola.error("No se pudo guardar, el contacto NO se agregó: " + e.getMessage());
        }
    }

    // =====================================================================
    //  2. MOSTRAR
    // =====================================================================

    private static final String FORMATO = "%-4s %-20s %-20s %-28s %s";

    private static void mostrar() {
        Consola.titulo("AGENDA");
        List<Contacto> contactos = agenda.getContactos();
        if (contactos.isEmpty()) {
            Consola.aviso("La agenda está vacía. Agregá un contacto con la opción 1.");
            return;
        }

        String separador = Color.pintar("\t" + "─".repeat(104), Color.GRIS);
        Consola.SALIDA.println();
        Consola.SALIDA.println("\t" + Color.pintar(String.format(FORMATO,
                "N°", "NOMBRE", "TELÉFONO", "EMAIL", "NOTA PRIVADA (desencriptada)"), Color.NEGRITA + Color.CIAN));
        Consola.SALIDA.println(separador);

        int ilegibles = 0;
        for (int i = 0; i < contactos.size(); i++) {
            Contacto c = contactos.get(i);
            String nota = agenda.notaDesencriptada(c);      // desencriptado en tiempo real

            // Primero se arma cada columna con su ancho y después se colorea (así no se desalinea)
            String colNumero = Color.pintar(String.format("%-4s", (i + 1) + "."), Color.AMARILLO);
            String colNombre = Color.pintar(String.format("%-20s", recortar(c.getNombre(), 20)), Color.NEGRITA);
            String colTelefono = Color.pintar(String.format("%-20s", recortar(c.getTelefono(), 20)), Color.VERDE);
            String colEmail = Color.pintar(String.format("%-28s", recortar(c.getEmail(), 28)), Color.AZUL);
            String colNota;
            if (nota == null) {
                colNota = Color.pintar("[ERROR: nota ilegible o clave incorrecta]", Color.ROJO);
                ilegibles++;
            } else if (nota.isEmpty()) {
                colNota = Color.pintar("(sin nota)", Color.GRIS);
            } else {
                colNota = Color.pintar(nota, Color.MAGENTA);
            }
            Consola.SALIDA.println("\t" + colNumero + " " + colNombre + " " + colTelefono + " " + colEmail + " " + colNota);
        }

        Consola.SALIDA.println(separador);
        Consola.SALIDA.println("\tTotal: " + Color.pintar(String.valueOf(contactos.size()), Color.NEGRITA) + " contactos"
                + "\t" + Color.pintar("Notas desencriptadas con AES en tiempo real", Color.GRIS));
        if (ilegibles > 0) {
            Consola.error(ilegibles + " nota(s) no se pudieron desencriptar.");
        }
        Consola.SALIDA.println();
    }

    // =====================================================================
    //  3. EDITAR
    // =====================================================================

    private static void editar() {
        mostrar();
        if (agenda.cantidad() == 0) {
            return;
        }
        int posicion = elegirContacto("editar");
        if (posicion < 0) {
            return;
        }
        Contacto actual = agenda.getContactos().get(posicion);
        String notaActual = agenda.notaDesencriptada(actual);
        if (notaActual == null) {
            Consola.aviso("La nota actual no se puede desencriptar. Si no escribís una nueva, quedará vacía.");
            notaActual = "";
        }

        Consola.info("Editando \"" + actual.getNombre() + "\". Dejá vacío (ENTER) para conservar el valor actual.");
        String nombre = pedirCampo("Nombre", actual.getNombre(), texto -> validarNombre(texto, posicion));
        String telefono = pedirCampo("Teléfono", actual.getTelefono(), Main::validarTelefono);
        String email = pedirCampo("Email", actual.getEmail(), Main::validarEmail);

        String nota = notaActual;
        String nueva = Consola.preguntar("Nota privada [" + (notaActual.isEmpty() ? "sin nota" : notaActual) + "] "
                + Color.pintar("(ENTER = conservar, - = borrar)", Color.GRIS) + ": ");
        if (nueva.equals("-")) {
            nota = "";
        } else if (!nueva.isEmpty()) {
            nota = nueva;
        }

        try {
            agenda.editar(posicion, nombre, telefono, email, nota);
            Consola.ok("Contacto actualizado y guardado en " + Agenda.ARCHIVO.getName() + ".");
        } catch (IOException | GeneralSecurityException e) {
            Consola.error("No se pudo guardar, el contacto NO se modificó: " + e.getMessage());
        }
    }

    // =====================================================================
    //  4. QUITAR
    // =====================================================================

    private static void quitar() {
        mostrar();
        if (agenda.cantidad() == 0) {
            return;
        }
        int posicion = elegirContacto("quitar");
        if (posicion < 0) {
            return;
        }
        String nombre = agenda.getContactos().get(posicion).getNombre();
        if (!Consola.confirmar(Color.pintar("¿Seguro que querés quitar a \"" + nombre + "\"?", Color.AMARILLO))) {
            Consola.aviso("No se quitó nada.");
            return;
        }
        try {
            agenda.quitar(posicion);
            Consola.ok("Contacto \"" + nombre + "\" quitado y cambio guardado en " + Agenda.ARCHIVO.getName() + ".");
        } catch (IOException e) {
            Consola.error("No se pudo guardar, el contacto NO se quitó: " + e.getMessage());
        }
    }

    // =====================================================================
    //  5. VER ARCHIVO (para comprobar que la nota está cifrada)
    // =====================================================================

    private static void verArchivo() {
        Consola.titulo("CONTENIDO REAL DE " + Agenda.ARCHIVO.getName().toUpperCase());
        try {
            List<String> lineas = ArchivoSeguro.leer(Agenda.ARCHIVO);
            if (lineas.isEmpty()) {
                Consola.aviso("El archivo está vacío.");
                return;
            }
            Consola.info("Nombre, teléfono y email en texto plano; la nota privada cifrada con AES (Base64).");
            Consola.SALIDA.println();
            for (String linea : lineas) {
                int ultimo = linea.lastIndexOf(Contacto.SEPARADOR);
                if (ultimo < 0) {
                    Consola.SALIDA.println("\t" + linea);
                } else {
                    Consola.SALIDA.println("\t" + linea.substring(0, ultimo + 1)
                            + Color.pintar(linea.substring(ultimo + 1), Color.MAGENTA));
                }
            }
            Consola.SALIDA.println();
        } catch (IOException e) {
            Consola.error("No se pudo leer el archivo: " + e.getMessage());
        }
    }

    // =====================================================================
    //  ENTRADA Y VALIDACIONES
    // =====================================================================

    /**
     * Pide un campo hasta que sea válido.
     * @param actual    valor actual (al editar, ENTER lo conserva) o null (al agregar, es obligatorio)
     * @param validador devuelve el mensaje de error, o null si el texto es válido
     */
    private static String pedirCampo(String etiqueta, String actual, Function<String, String> validador) {
        while (true) {
            String mensaje = actual == null ? etiqueta + ": " : etiqueta + " [" + actual + "]: ";
            String texto = Consola.preguntar(mensaje);
            if (texto.isEmpty() && actual != null) {
                return actual;
            }
            String error = validador.apply(texto);
            if (error == null) {
                return texto;
            }
            Consola.error(error);
        }
    }

    private static String validarNombre(String texto, int posicionPropia) {
        if (texto.isEmpty()) return "El nombre es obligatorio.";
        if (texto.contains(Contacto.SEPARADOR)) return "No se puede usar el carácter ';'.";
        int existente = agenda.buscar(texto);
        if (existente >= 0 && existente != posicionPropia) return "Ya existe un contacto llamado \"" + texto + "\".";
        return null;
    }

    private static String validarTelefono(String texto) {
        if (texto.isEmpty()) return "El teléfono es obligatorio.";
        int digitos = 0;
        for (char c : texto.toCharArray()) {
            if (Character.isDigit(c)) {
                digitos++;
            } else if ("+-() ".indexOf(c) < 0) {
                return "El teléfono solo puede tener números, espacios y los signos + - ( ).";
            }
        }
        if (digitos < 6) return "El teléfono tiene que tener al menos 6 dígitos.";
        return null;
    }

    private static String validarEmail(String texto) {
        if (texto.isEmpty()) return "El email es obligatorio.";
        if (!texto.matches("[^@\\s;]+@[^@\\s;]+\\.[^@\\s;]+")) return "Email inválido. Ejemplo: nombre@dominio.com";
        return null;
    }

    /** Pide el N° o nombre del contacto. 0 cancela. Devuelve la posición o -1. */
    private static int elegirContacto(String accion) {
        while (true) {
            String texto = Consola.preguntar("N° o nombre del contacto a " + accion + " (0 = cancelar): ");
            if (texto.equals("0")) {
                Consola.aviso("Operación cancelada.");
                return -1;
            }
            if (Consola.esEntero(texto)) {
                int numero = Consola.aInt(texto, -1);
                if (numero >= 1 && numero <= agenda.cantidad()) {
                    return numero - 1;
                }
                Consola.error("No existe el contacto N° " + texto + ".");
            } else {
                int posicion = agenda.buscar(texto);
                if (posicion >= 0) {
                    return posicion;
                }
                Consola.error("No existe un contacto llamado \"" + texto + "\".");
            }
        }
    }

    private static String recortar(String texto, int maximo) {
        return texto.length() <= maximo ? texto : texto.substring(0, maximo - 1) + ".";
    }
}
