import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * La agenda en memoria.
 *
 * Al crearse lee "agenda.dat" y carga los contactos en un ArrayList.
 * Todas las operaciones (agregar, quitar, editar, mostrar) trabajan sobre esa lista,
 * y después de cada modificación se guarda el archivo de inmediato (con ArchivoSeguro).
 * Si el guardado falla, el cambio se deshace en memoria para que lista y archivo sigan iguales.
 */
public class Agenda {

    public static final File ARCHIVO = new File("agenda.dat");
    public static final File ARCHIVO_CLAVE = new File("agenda.key");

    private final ArrayList<Contacto> contactos = new ArrayList<>();
    private final Cifrador cifrador;

    public Agenda() throws IOException, GeneralSecurityException {
        int sobrantes = ArchivoSeguro.limpiarTemporales(ARCHIVO) + ArchivoSeguro.limpiarTemporales(ARCHIVO_CLAVE);
        if (sobrantes > 0) {
            Consola.aviso("Se encontraron archivos temporales (" + sobrantes + ") de un guardado interrumpido. "
                    + "Se borraron; agenda.dat no se vio afectado.");
        }
        if (ARCHIVO.exists() && !ARCHIVO_CLAVE.exists()) {
            throw new GeneralSecurityException("existe " + ARCHIVO.getName() + " pero falta " + ARCHIVO_CLAVE.getName()
                    + ": sin la clave no se pueden leer las notas privadas");
        }
        cifrador = new Cifrador(ARCHIVO_CLAVE);
        cargar();
    }

    // =====================================================================
    //  ARCHIVO ↔ COLECCIÓN
    // =====================================================================

    private void cargar() throws IOException {
        if (!ARCHIVO.exists()) {
            ArchivoSeguro.escribir(ARCHIVO, new ArrayList<>());
            Consola.ok("Se creó el archivo " + ARCHIVO.getName() + ".");
            return;
        }
        List<String> lineas = ArchivoSeguro.leer(ARCHIVO);
        for (int i = 0; i < lineas.size(); i++) {
            if (lineas.get(i).trim().isEmpty()) {
                continue;
            }
            Contacto c = Contacto.desdeLinea(lineas.get(i));
            if (c == null) {
                Consola.aviso("Renglón " + (i + 1) + " de " + ARCHIVO.getName() + " con formato inválido, se ignora.");
            } else {
                contactos.add(c);
            }
        }
        ordenar();
        Consola.ok("Se cargaron " + contactos.size() + " contactos desde " + ARCHIVO.getName() + ".");
    }

    private void guardar() throws IOException {
        List<String> lineas = new ArrayList<>();
        for (Contacto c : contactos) {
            lineas.add(c.aLinea());
        }
        ArchivoSeguro.escribir(ARCHIVO, lineas);
    }

    private void ordenar() {
        contactos.sort((a, b) -> a.getNombre().compareToIgnoreCase(b.getNombre()));
    }

    // =====================================================================
    //  OPERACIONES (cada una guarda de inmediato)
    // =====================================================================

    /** Agrega un contacto. La nota se encripta acá, antes de entrar a la colección. */
    public void agregar(String nombre, String telefono, String email, String nota)
            throws IOException, GeneralSecurityException {
        Contacto nuevo = new Contacto(nombre, telefono, email, cifrador.encriptar(nota));
        contactos.add(nuevo);
        try {
            guardar();
        } catch (IOException e) {
            contactos.remove(nuevo);                 // deshacer
            throw e;
        }
        ordenar();
    }

    /** Reemplaza el contacto de la posición indicada. */
    public void editar(int posicion, String nombre, String telefono, String email, String nota)
            throws IOException, GeneralSecurityException {
        Contacto anterior = contactos.get(posicion);
        contactos.set(posicion, new Contacto(nombre, telefono, email, cifrador.encriptar(nota)));
        try {
            guardar();
        } catch (IOException e) {
            contactos.set(posicion, anterior);       // deshacer
            throw e;
        }
        ordenar();
    }

    /** Quita el contacto de la posición indicada y lo devuelve. */
    public Contacto quitar(int posicion) throws IOException {
        Contacto quitado = contactos.remove(posicion);
        try {
            guardar();
        } catch (IOException e) {
            contactos.add(posicion, quitado);        // deshacer
            throw e;
        }
        return quitado;
    }

    // =====================================================================
    //  CONSULTAS
    // =====================================================================

    /** Desencripta en tiempo real la nota de un contacto. Devuelve null si no se puede. */
    public String notaDesencriptada(Contacto c) {
        try {
            return cifrador.desencriptar(c.getNotaCifrada());
        } catch (GeneralSecurityException e) {
            return null;
        }
    }

    /** Posición del contacto con ese nombre (sin importar mayúsculas) o -1. */
    public int buscar(String nombre) {
        for (int i = 0; i < contactos.size(); i++) {
            if (contactos.get(i).getNombre().equalsIgnoreCase(nombre)) {
                return i;
            }
        }
        return -1;
    }

    /** Vista de solo lectura de la colección (para mostrarla sin poder modificarla desde afuera). */
    public List<Contacto> getContactos() {
        return Collections.unmodifiableList(contactos);
    }

    public int cantidad() {
        return contactos.size();
    }
}
