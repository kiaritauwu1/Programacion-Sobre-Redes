/**
 * Un contacto de la agenda.
 *
 * Nombre, teléfono y email están en texto plano. La nota privada se guarda SIEMPRE
 * encriptada (AES, en Base64), tanto en memoria como en el archivo, y solo se
 * desencripta en el momento de mostrarla.
 *
 * Renglón del archivo:  nombre;telefono;email;NOTA_ENCRIPTADA
 *
 * Es inmutable: para editar se crea un contacto nuevo (así se puede deshacer si falla el guardado).
 */
public class Contacto {

    public static final String SEPARADOR = ";";

    private final String nombre;
    private final String telefono;
    private final String email;
    private final String notaCifrada;

    public Contacto(String nombre, String telefono, String email, String notaCifrada) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
        this.notaCifrada = notaCifrada;
    }

    /** Renglón para el archivo. */
    public String aLinea() {
        return nombre + SEPARADOR + telefono + SEPARADOR + email + SEPARADOR + notaCifrada;
    }

    /** Crea un contacto desde un renglón del archivo, o devuelve null si el formato es inválido. */
    public static Contacto desdeLinea(String linea) {
        String[] campos = linea.split(SEPARADOR, -1);
        if (campos.length != 4 || campos[0].trim().isEmpty()) {
            return null;
        }
        return new Contacto(campos[0].trim(), campos[1].trim(), campos[2].trim(), campos[3].trim());
    }

    public String getNombre() { return nombre; }
    public String getTelefono() { return telefono; }
    public String getEmail() { return email; }
    public String getNotaCifrada() { return notaCifrada; }
}
