# Parte de Redes: Docker + VM Linux

Esquema de la prueba:

```
 PC Windows (host)                              VM Debian / Alpine (VMware)
 ┌───────────────────────────────┐              ┌──────────────────────────┐
 │ Docker: servidor-batalla      │◄── red ──────│ JDK 17 + ClienteBatalla  │  Jugador 1
 │ puerto 7000                   │              └──────────────────────────┘
 │                               │
 │ 2-JUGADOR.bat (ClienteBatalla)│  Jugador 2
 └───────────────────────────────┘
```

---

## 1. Servidor en Docker (en la PC Windows)

Requisito: tener **Docker Desktop** instalado y abierto.

Abrir una terminal en la carpeta `TP-BatallaNaval` y ejecutar:

```bash
docker compose up -d --build      # construye la imagen y levanta el servidor
docker compose ps                 # verifica que el contenedor esté "running"
docker compose logs -f            # muestra el log del servidor en vivo (Ctrl+C para salir del log)
```

Para apagarlo:

```bash
docker compose down
```

- El servidor queda escuchando en el **puerto 7000 de la PC Windows**.
- El historial de partidas se guarda en la carpeta `datos/` (volumen del compose).
- Las IP que muestra el servidor al arrancar son las internas del contenedor (172.x.x.x).
  Para conectarse hay que usar **la IP de la PC Windows** (ver con `ipconfig`, por ejemplo `192.168.1.10`).
- Si la VM no conecta, permitir el puerto 7000 en el firewall de Windows.

---

## 2. Máquina virtual con Debian liviano

1. Crear la VM en VMware con la imagen ISO de **Debian netinst** (1 CPU, 1–2 GB de RAM, 10 GB de disco).
2. En la configuración de la VM, poner el adaptador de red en **Bridged** (puente):
   así la VM recibe una IP de la misma red que la PC.
3. Instalar Debian sin entorno gráfico (solo "utilidades estándar del sistema").
4. Dentro de la VM, instalar la JDK:

```bash
sudo apt update
sudo apt install default-jdk         # o: sudo apt install openjdk-17-jdk
java -version                         # verifica la instalación
```

### Alternativa: Alpine Linux

```bash
apk update
apk add openjdk17
java -version
```

---

## 3. Copiar el cliente a la VM

La forma más simple es clonar la rama del repositorio:

```bash
sudo apt install git
git clone -b NOMBRE_DE_LA_RAMA https://github.com/USUARIO/REPO.git
cd REPO/TP-BatallaNaval
```

(También se puede copiar la carpeta con un pendrive o una carpeta compartida de VMware.)

---

## 4. Probar el juego

1. En la VM:

```bash
sh jugar.sh
```

   - IP del servidor: la IP de la PC Windows (ej. `192.168.1.10`)
   - Puerto: `7000`
   - Nombre: el del jugador 1

2. En Windows: abrir `2-JUGADOR.bat` como jugador 2 (IP `127.0.0.1` o la misma IP de la PC).
3. Cuando los dos están conectados, la sala de espera arma la partida.
4. Ver en `docker compose logs -f` las conexiones, los disparos y el ganador.

### Capturas sugeridas para la entrega

- `docker compose ps` con el contenedor en ejecución.
- `java -version` dentro de la VM.
- La partida en la consola de la VM y en la de Windows.
- El log del servidor (`docker compose logs`) mostrando la conexión desde la IP de la VM.
