@echo off
chcp 65001 >nul
title SERVIDOR BATALLA NAVAL
cd /d "%~dp0"
if not exist bin mkdir bin
javac -encoding UTF-8 -d bin src\*.java
if errorlevel 1 (
  echo.
  echo No se pudo compilar. Revisa que tengas instalado Java JDK 11 o superior.
  pause
  exit /b
)
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -cp bin ServidorBatalla
pause
