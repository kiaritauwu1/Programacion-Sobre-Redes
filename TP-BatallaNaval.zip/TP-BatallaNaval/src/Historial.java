import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Historial de partidas guardado en el archivo de texto "historial_partidas.txt".
 * Cada renglón: fecha;partida;jugador1;jugador2;ganador;motivo;disparos;segundos
 *
 * Los métodos son synchronized: varias partidas pueden terminar al mismo tiempo
 * y no deben escribir el archivo a la vez.
 */
public class Historial {

    private static final File ARCHIVO = new File("historial_partidas.txt");
    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    /** Agrega una partida al final del archivo (PrintWriter sobre FileWriter en modo agregar). */
    public static synchronized void registrar(int partida, String jugador1, String jugador2, String ganador,
                                              String motivo, int disparos, long segundos) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ARCHIVO, StandardCharsets.UTF_8, true))) {
            pw.println(LocalDateTime.now().format(FECHA) + ";" + partida + ";" + jugador1 + ";" + jugador2 + ";"
                    + ganador + ";" + motivo + ";" + disparos + ";" + segundos);
            Log.sistema("Partida #" + partida + " guardada en " + ARCHIVO.getName());
        } catch (IOException e) {
            Log.error("", "No se pudo guardar el historial: " + e.getMessage());
        }
    }

    /** Lee el archivo con BufferedReader y arma las estadísticas de un jugador. */
    public static synchronized String estadisticas(String nombre) {
        int jugadas = 0, ganadas = 0;
        StringBuilder ultimas = new StringBuilder();

        if (ARCHIVO.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO, StandardCharsets.UTF_8))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    String[] c = linea.split(";");
                    if (c.length < 8) continue;
                    boolean participo = c[2].equalsIgnoreCase(nombre) || c[3].equalsIgnoreCase(nombre);
                    if (!participo) continue;
                    jugadas++;
                    boolean gano = c[4].equalsIgnoreCase(nombre);
                    if (gano) ganadas++;
                    String rival = c[2].equalsIgnoreCase(nombre) ? c[3] : c[2];
                    ultimas.append(String.format("   %s  vs %-15s %-8s (%s, %s disparos)%n",
                            c[0], rival, gano ? "GANADA" : "PERDIDA", c[5], c[6]));
                }
            } catch (IOException e) {
                return "No se pudo leer el historial: " + e.getMessage();
            }
        }
        if (jugadas == 0) {
            return "Todavía no terminaste ninguna partida.";
        }
        int porcentaje = ganadas * 100 / jugadas;
        return "ESTADÍSTICAS DE " + nombre.toUpperCase() + "\n"
                + "   Jugadas: " + jugadas + "   Ganadas: " + ganadas + "   Perdidas: " + (jugadas - ganadas)
                + "   Efectividad: " + porcentaje + "%\n"
                + "HISTORIAL:\n" + ultimas.toString().replaceAll("\\s+$", "");
    }
}
