import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.SocketException;

/**
 * Hilo del cliente que escucha al servidor todo el tiempo.
 *
 * Se necesita un hilo aparte porque el hilo principal se queda bloqueado leyendo el teclado,
 * y mientras tanto pueden llegar mensajes en cualquier momento: el disparo del rival,
 * un chat, el cambio de turno o el fin de la partida.
 */
public class ReceptorServidor implements Runnable {

    private final ObjectInputStream entrada;
    private final EstadoCliente estado;

    public ReceptorServidor(ObjectInputStream entrada, EstadoCliente estado) {
        this.entrada = entrada;
        this.estado = estado;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Mensaje m = (Mensaje) entrada.readObject();   // espera el próximo mensaje
                procesar(m);
            }
        } catch (EOFException | SocketException e) {
            if (estado.getFase() != EstadoCliente.Fase.DESCONECTADO) {
                Pantalla.error("Se perdió la conexión con el servidor. Presioná ENTER para salir.");
            }
        } catch (IOException | ClassNotFoundException e) {
            Pantalla.error("Error al recibir datos del servidor: " + e.getMessage());
        } finally {
            estado.setFase(EstadoCliente.Fase.DESCONECTADO);
        }
    }

    private void procesar(Mensaje m) {
        switch (m.getTipo()) {
            case ESPERANDO_RIVAL:
                Pantalla.info("Sala de espera: " + m.getTexto());
                break;

            case PARTIDA_ENCONTRADA:
                estado.nuevaPartida(m.getTexto());
                Pantalla.titulo(m.getRemitente() + "  ·  " + estado.getNombre() + " vs " + m.getTexto());
                estado.setFase(EstadoCliente.Fase.COLOCANDO);
                break;

            case BARCOS_RECHAZADOS:
                Pantalla.error(m.getTexto() + " Presioná ENTER.");
                estado.setFase(EstadoCliente.Fase.COLOCANDO);
                break;

            case ESPERANDO_RIVAL_BARCOS:
                Pantalla.info(m.getTexto());
                break;

            case INICIO_JUEGO:
                estado.setFase(EstadoCliente.Fase.JUGANDO);
                Pantalla.exito(m.getTexto());
                break;

            case TU_TURNO:
                estado.setMiTurno(true);
                estado.mostrarTableros();
                Pantalla.turno("TU TURNO → escribí la coordenada del disparo (ej: B7)");
                break;

            case TURNO_RIVAL:
                estado.setMiTurno(false);
                Pantalla.info("Turno de " + m.getTexto() + ". Esperando su disparo...");
                break;

            case RESULTADO_DISPARO:
                estado.getEnemigo().registrarResultado(m.getFila(), m.getColumna(), m.isImpacto(), m.getBarcoHundido());
                if (m.getBarcoHundido() != null) {
                    estado.getEnemigosHundidos().add(m.getBarcoHundido());
                }
                Pantalla.resultado("Disparaste a " + Coordenada.texto(m.getFila(), m.getColumna()), m.getResultado());
                estado.mostrarTableros();
                break;

            case DISPARO_RECIBIDO:
                estado.getPropio().disparar(m.getFila(), m.getColumna());   // se refleja en mi copia del tablero
                Pantalla.resultado(m.getRemitente() + " disparó a " + Coordenada.texto(m.getFila(), m.getColumna()), m.getResultado());
                break;

            case CHAT:
                Pantalla.chat(m.getRemitente(), m.getTexto());
                break;

            case ESTADISTICAS:
                Pantalla.bloque(m.getTexto());
                break;

            case FIN_PARTIDA:
                estado.setMiTurno(false);
                estado.mostrarTableros();
                if (m.isGano()) {
                    estado.getEnemigo().verificarVictoria();
                    Pantalla.exito("Le ganaste a " + m.getTexto() + ".");
                } else {
                    estado.getPropio().verificarDerrota();
                    Pantalla.error("Ganó " + m.getTexto() + ".");
                }
                estado.setFase(EstadoCliente.Fase.TERMINADA);
                Pantalla.info("Escribí OTRA para jugar de nuevo, STATS para ver tus estadísticas o SALIR.");
                break;

            case RIVAL_DESCONECTADO:
                estado.setMiTurno(false);
                estado.setFase(EstadoCliente.Fase.TERMINADA);
                Pantalla.exito(m.getTexto());
                Pantalla.info("Escribí OTRA para jugar de nuevo, STATS para ver tus estadísticas o SALIR.");
                break;

            case ERROR:
                Pantalla.error(m.getTexto());
                break;

            default:
                Pantalla.info(m.toString());
        }
    }
}
