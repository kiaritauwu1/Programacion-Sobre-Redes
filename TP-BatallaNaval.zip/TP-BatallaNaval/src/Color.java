/**
 * Códigos de color ANSI para la consola.
 * Se ven en IntelliJ, VS Code, Eclipse (2022+), Windows Terminal, Linux y macOS.
 */
public class Color {

    public static final String RESET    = "\u001B[0m";
    public static final String NEGRITA  = "\u001B[1m";
    public static final String ROJO     = "\u001B[31m";
    public static final String VERDE    = "\u001B[32m";
    public static final String AMARILLO = "\u001B[33m";
    public static final String AZUL     = "\u001B[34m";
    public static final String MAGENTA  = "\u001B[35m";
    public static final String CIAN     = "\u001B[36m";
    public static final String BLANCO   = "\u001B[97m";
    public static final String GRIS     = "\u001B[90m";

    public static String pintar(String texto, String color) {
        return color + texto + RESET;
    }
}
