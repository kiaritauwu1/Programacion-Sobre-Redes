import java.io.Serializable;
import java.util.ArrayList;

/**
 * PROTOCOLO: todo lo que se intercambian cliente y servidor es un objeto Mensaje
 * serializado con ObjectOutputStream / ObjectInputStream.
 *
 *  Cliente → Servidor                       Servidor → Cliente
 *  ───────────────────────────────────      ─────────────────────────────────────────────
 *  CONECTAR (texto = nombre)                BIENVENIDA / ERROR
 *  BUSCAR_PARTIDA                           ESPERANDO_RIVAL / PARTIDA_ENCONTRADA (texto = rival)
 *  COLOCAR_BARCOS (barcos)                  BARCOS_RECHAZADOS / ESPERANDO_RIVAL_BARCOS / INICIO_JUEGO
 *  DISPARO (fila, columna)                  TU_TURNO / TURNO_RIVAL (texto = quién juega)
 *  CHAT (texto)                             RESULTADO_DISPARO (a quien disparó)
 *  ESTADISTICAS                             DISPARO_RECIBIDO (al que recibió el disparo)
 *  SALIR                                    CHAT / ESTADISTICAS / FIN_PARTIDA (gano) / RIVAL_DESCONECTADO
 */
public class Mensaje implements Serializable {

    private static final long serialVersionUID = 1L;

    public enum Tipo {
        // conexión y sala
        CONECTAR, BIENVENIDA, ERROR, BUSCAR_PARTIDA, ESPERANDO_RIVAL, PARTIDA_ENCONTRADA,
        // ubicación de barcos
        COLOCAR_BARCOS, BARCOS_RECHAZADOS, ESPERANDO_RIVAL_BARCOS, INICIO_JUEGO,
        // turnos y disparos
        TU_TURNO, TURNO_RIVAL, DISPARO, RESULTADO_DISPARO, DISPARO_RECIBIDO,
        // extras y fin
        CHAT, ESTADISTICAS, FIN_PARTIDA, RIVAL_DESCONECTADO, SALIR
    }

    private final Tipo tipo;
    private String texto;
    private String remitente;
    private int fila;
    private int columna;
    private String resultado;
    private boolean impacto;
    private String barcoHundido;
    private boolean gano;
    private ArrayList<PosicionBarco> barcos;

    public Mensaje(Tipo tipo) {
        this.tipo = tipo;
    }

    public Mensaje(Tipo tipo, String texto) {
        this.tipo = tipo;
        this.texto = texto;
    }

    /** Mensaje de disparo (cliente → servidor). */
    public static Mensaje disparo(int fila, int columna) {
        Mensaje m = new Mensaje(Tipo.DISPARO);
        m.fila = fila;
        m.columna = columna;
        return m;
    }

    /** Resultado de un disparo (servidor → clientes). */
    public static Mensaje resultado(Tipo tipo, String tirador, int fila, int columna, String resultado,
                                    boolean impacto, String barcoHundido) {
        Mensaje m = new Mensaje(tipo);
        m.remitente = tirador;
        m.fila = fila;
        m.columna = columna;
        m.resultado = resultado;
        m.impacto = impacto;
        m.barcoHundido = barcoHundido;
        return m;
    }

    public Tipo getTipo() { return tipo; }
    public String getTexto() { return texto; }
    public String getRemitente() { return remitente; }
    public void setRemitente(String remitente) { this.remitente = remitente; }
    public int getFila() { return fila; }
    public int getColumna() { return columna; }
    public String getResultado() { return resultado; }
    public boolean isImpacto() { return impacto; }
    public String getBarcoHundido() { return barcoHundido; }
    public boolean isGano() { return gano; }
    public void setGano(boolean gano) { this.gano = gano; }
    public ArrayList<PosicionBarco> getBarcos() { return barcos; }
    public void setBarcos(ArrayList<PosicionBarco> barcos) { this.barcos = barcos; }

    @Override
    public String toString() {
        switch (tipo) {
            case DISPARO: return "DISPARO " + Coordenada.texto(fila, columna);
            case COLOCAR_BARCOS: return "COLOCAR_BARCOS (" + (barcos == null ? 0 : barcos.size()) + " barcos)";
            default: return tipo + (texto == null ? "" : " \"" + texto + "\"");
        }
    }
}
