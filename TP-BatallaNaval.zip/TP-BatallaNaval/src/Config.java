/**
 * Constantes del juego compartidas por el servidor y el cliente.
 */
public class Config {

    public static final int PUERTO = 7000;

    /** Flota de cada jugador: nombre y cantidad de casillas. */
    public static final String[] NOMBRES_BARCOS = {"Portaaviones", "Acorazado", "Crucero", "Submarino", "Destructor"};
    public static final int[] LONGITUDES_BARCOS = {5, 4, 3, 3, 2};

    public static final int CANTIDAD_BARCOS = NOMBRES_BARCOS.length;

    /** Longitud del barco con ese nombre, o -1 si no existe. */
    public static int longitudDe(String nombre) {
        for (int i = 0; i < NOMBRES_BARCOS.length; i++) {
            if (NOMBRES_BARCOS[i].equals(nombre)) {
                return LONGITUDES_BARCOS[i];
            }
        }
        return -1;
    }
}
