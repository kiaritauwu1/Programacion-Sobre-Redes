import java.util.ArrayList;

/**
 * Tablero de 10x10 de un jugador.
 *
 * La grilla es un ArrayList de ArrayList de Celda: tablero.get(fila).get(columna).
 * El servidor guarda el tablero real de cada jugador; el cliente guarda su propio tablero
 * (copia) y un tablero "vista del enemigo" donde solo anota los resultados de sus disparos.
 */
public class Tablero {

    public static final int TAMANIO = 10;

    // Resultados posibles de disparar()
    public static final String RES_AGUA = "Agua";
    public static final String RES_IMPACTO = "¡IMPACTO!";
    public static final String RES_HUNDIDO = "¡HUNDIDO!";
    public static final String RES_REPETIDO = "Ya se disparó en esa posición";
    public static final String RES_INVALIDA = "Posición inválida";

    private ArrayList<ArrayList<Celda>> tablero;
    private ArrayList<Barco> barcos;

    public Tablero() {
        inicializarTablero();
    }

    // =====================================================================
    //  INICIALIZACIÓN
    // =====================================================================

    /** Crea la grilla de 10x10 con todas las celdas en AGUA y sin barcos. */
    public void inicializarTablero() {
        tablero = new ArrayList<>();
        for (int fila = 0; fila < TAMANIO; fila++) {
            ArrayList<Celda> filaCeldas = new ArrayList<>();
            for (int col = 0; col < TAMANIO; col++) {
                filaCeldas.add(new Celda());
            }
            tablero.add(filaCeldas);
        }
        barcos = new ArrayList<>();
    }

    // =====================================================================
    //  COLOCACIÓN DE BARCOS
    // =====================================================================

    /**
     * Coloca un barco a partir de (fila, col), hacia la derecha si es horizontal o hacia abajo si es vertical.
     * Devuelve false si no entra en el tablero, si choca con otro barco o si ese barco ya fue colocado.
     */
    public boolean colocarBarco(String nombre, int fila, int col, int longitud, boolean horizontal) {
        if (longitud < 1 || buscarBarco(nombre) != null) {
            return false;
        }
        int filaFin = horizontal ? fila : fila + longitud - 1;
        int colFin = horizontal ? col + longitud - 1 : col;

        // 1) ¿Entra en el tablero?
        if (!posicionValida(fila, col) || !posicionValida(filaFin, colFin)) {
            return false;
        }
        // 2) ¿Choca con otro barco?
        for (int i = 0; i < longitud; i++) {
            int f = horizontal ? fila : fila + i;
            int c = horizontal ? col + i : col;
            if (getCelda(f, c).getTipo() != TipoCelda.AGUA) {
                return false;
            }
        }
        // 3) Se coloca
        for (int i = 0; i < longitud; i++) {
            int f = horizontal ? fila : fila + i;
            int c = horizontal ? col + i : col;
            Celda celda = getCelda(f, c);
            celda.setTipo(TipoCelda.BARCO);
            celda.setNombreBarco(nombre);
        }
        barcos.add(new Barco(nombre, longitud));
        return true;
    }

    // =====================================================================
    //  DISPARAR
    // =====================================================================

    /**
     * Dispara a (fila, col) y devuelve el resultado:
     * "Agua", "¡IMPACTO!", "¡HUNDIDO! <barco>", "Ya se disparó en esa posición" o "Posición inválida".
     */
    public String disparar(int fila, int col) {
        if (!posicionValida(fila, col)) {
            return RES_INVALIDA;
        }
        Celda celda = getCelda(fila, col);
        if (celda.isDisparada()) {
            return RES_REPETIDO;
        }
        celda.setDisparada(true);

        if (celda.getTipo() == TipoCelda.BARCO) {
            celda.setTipo(TipoCelda.IMPACTO);
            Barco barco = buscarBarco(celda.getNombreBarco());
            barco.recibirImpacto();
            if (barco.estaHundido()) {
                return RES_HUNDIDO + " " + barco.getNombre();
            }
            return RES_IMPACTO;
        }
        celda.setTipo(TipoCelda.FALLO);
        return RES_AGUA;
    }

    /**
     * Para el tablero "vista del enemigo" del cliente: anota el resultado que informó el servidor,
     * sin conocer dónde están los barcos.
     */
    public void registrarResultado(int fila, int col, boolean impacto, String barcoHundido) {
        if (!posicionValida(fila, col)) {
            return;
        }
        Celda celda = getCelda(fila, col);
        celda.setDisparada(true);
        celda.setTipo(impacto ? TipoCelda.IMPACTO : TipoCelda.FALLO);

        if (barcoHundido != null && buscarBarco(barcoHundido) == null) {
            // Se registra el barco enemigo como hundido para poder verificar la victoria
            Barco barco = new Barco(barcoHundido, Config.longitudDe(barcoHundido));
            for (int i = 0; i < barco.getLongitud(); i++) {
                barco.recibirImpacto();
            }
            barcos.add(barco);
        }
    }

    // =====================================================================
    //  VISUALIZACIÓN
    // =====================================================================

    /**
     * Muestra el tablero en consola.
     * ocultarBarcos = true → no muestra los barcos intactos (vista del oponente).
     * Símbolos: ~ agua, B barco, X impacto, O fallo.
     */
    public void mostrarTablero(boolean ocultarBarcos) {
        for (String linea : lineasTablero(ocultarBarcos)) {
            System.out.println("  " + linea);
        }
    }

    /** Muestra dos tableros uno al lado del otro (el propio y el del enemigo). */
    public static void mostrarDosTableros(Tablero izquierdo, String tituloIzq, Tablero derecho, String tituloDer) {
        ArrayList<String> izq = izquierdo.lineasTablero(false);
        ArrayList<String> der = derecho.lineasTablero(true);
        int ancho = 3 + TAMANIO * 3;          // ancho visible de cada línea del tablero

        System.out.println();
        System.out.println("  " + Color.pintar(centrar(tituloIzq, ancho), Color.NEGRITA + Color.VERDE)
                + "      " + Color.pintar(centrar(tituloDer, ancho), Color.NEGRITA + Color.ROJO));
        for (int i = 0; i < izq.size(); i++) {
            System.out.println("  " + izq.get(i) + "      " + der.get(i));
        }
        System.out.println("  " + Color.pintar("~ agua   B barco   X impacto   O fallo", Color.GRIS));
        System.out.println();
    }

    /** Arma las líneas del tablero con colores (todas del mismo ancho visible). */
    private ArrayList<String> lineasTablero(boolean ocultarBarcos) {
        ArrayList<String> lineas = new ArrayList<>();

        StringBuilder encabezado = new StringBuilder("   ");
        for (int c = 1; c <= TAMANIO; c++) {
            encabezado.append(String.format("%2d ", c));
        }
        lineas.add(Color.pintar(encabezado.toString(), Color.AMARILLO));

        for (int f = 0; f < TAMANIO; f++) {
            StringBuilder linea = new StringBuilder(Color.pintar(" " + (char) ('A' + f) + " ", Color.AMARILLO));
            for (int c = 0; c < TAMANIO; c++) {
                linea.append(simbolo(getCelda(f, c), ocultarBarcos));
            }
            lineas.add(linea.toString());
        }
        return lineas;
    }

    private String simbolo(Celda celda, boolean ocultarBarcos) {
        switch (celda.getTipo()) {
            case BARCO:
                return ocultarBarcos ? Color.pintar(" ~ ", Color.AZUL) : Color.pintar(" B ", Color.NEGRITA + Color.BLANCO);
            case IMPACTO:
                return Color.pintar(" X ", Color.NEGRITA + Color.ROJO);
            case FALLO:
                return Color.pintar(" O ", Color.AMARILLO);
            default:
                return Color.pintar(" ~ ", Color.AZUL);
        }
    }

    /** Lista los barcos con su estado. */
    public void mostrarBarcos() {
        System.out.println(Color.pintar(String.format("    %-14s %8s %10s   %s", "BARCO", "LONGITUD", "IMPACTOS", "ESTADO"), Color.NEGRITA + Color.CIAN));
        for (Barco b : barcos) {
            String estado = b.estaHundido() ? Color.pintar("HUNDIDO", Color.ROJO) : Color.pintar("ACTIVO", Color.VERDE);
            System.out.printf("    %-14s %8d %10d   %s%n", b.getNombre(), b.getLongitud(), b.getImpactos(), estado);
        }
    }

    // =====================================================================
    //  VICTORIA / DERROTA
    // =====================================================================

    /** true si están los barcos de toda la flota y todos están hundidos. */
    public boolean todosLosBarcosCaidos() {
        if (barcos.size() < Config.CANTIDAD_BARCOS) {
            return false;
        }
        for (Barco b : barcos) {
            if (!b.estaHundido()) {
                return false;
            }
        }
        return true;
    }

    /** Se llama sobre el tablero ENEMIGO: muestra el mensaje de victoria si toda su flota se hundió. */
    public boolean verificarVictoria() {
        if (todosLosBarcosCaidos()) {
            System.out.println(Color.pintar("  ★ ¡VICTORIA! Hundiste todos los barcos enemigos ★", Color.NEGRITA + Color.VERDE));
            return true;
        }
        return false;
    }

    /** Se llama sobre el tablero PROPIO: muestra el mensaje de derrota si toda tu flota se hundió. */
    public boolean verificarDerrota() {
        if (todosLosBarcosCaidos()) {
            System.out.println(Color.pintar("  ✖ DERROTA: hundieron todos tus barcos ✖", Color.NEGRITA + Color.ROJO));
            return true;
        }
        return false;
    }

    // =====================================================================
    //  AUXILIARES
    // =====================================================================

    public boolean posicionValida(int fila, int col) {
        return fila >= 0 && fila < TAMANIO && col >= 0 && col < TAMANIO;
    }

    public Celda getCelda(int fila, int col) {
        return tablero.get(fila).get(col);
    }

    public ArrayList<Barco> getBarcos() {
        return barcos;
    }

    private Barco buscarBarco(String nombre) {
        for (Barco b : barcos) {
            if (b.getNombre().equals(nombre)) {
                return b;
            }
        }
        return null;
    }

    private static String centrar(String texto, int ancho) {
        if (texto.length() >= ancho) return texto.substring(0, ancho);
        int izq = (ancho - texto.length()) / 2;
        return " ".repeat(izq) + texto + " ".repeat(ancho - texto.length() - izq);
    }
}
