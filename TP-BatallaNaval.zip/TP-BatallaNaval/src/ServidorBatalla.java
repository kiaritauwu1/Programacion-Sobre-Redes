import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * SERVIDOR DE BATALLA NAVAL
 *
 * HILOS:
 *  - El hilo main solo acepta conexiones (accept) en un bucle infinito.
 *  - Cada jugador que se conecta es atendido por un ManejadorJugador en un Thread propio.
 *  - La SalaEspera empareja a los jugadores de a dos y crea una Partida por cada pareja,
 *    así el servidor puede tener muchas partidas al mismo tiempo.
 *
 * SINCRONIZACIÓN:
 *  - Los nombres en uso se reservan con métodos synchronized (dos jugadores no pueden usar el mismo).
 *  - SalaEspera y Partida tienen sus métodos synchronized: aunque los dos hilos de una partida
 *    disparen o se desconecten al mismo tiempo, el estado del juego queda consistente.
 */
public class ServidorBatalla {

    private static final Set<String> NOMBRES_EN_USO = new HashSet<>();
    private static int contadorJugadores = 0;

    public static void main(String[] args) {
        Log.titulo("SERVIDOR BATALLA NAVAL  ·  PUERTO " + Config.PUERTO);
        mostrarIps();

        SalaEspera sala = new SalaEspera();

        try (ServerSocket servidor = new ServerSocket(Config.PUERTO)) {
            Log.sistema("Esperando jugadores...");
            while (true) {
                Socket socket = servidor.accept();             // espera a un jugador
                contadorJugadores++;
                Thread hilo = new Thread(new ManejadorJugador(socket, sala), "Jugador-" + contadorJugadores);
                hilo.start();                                  // lo atiende otro hilo; el main vuelve a esperar
            }
        } catch (IOException e) {
            Log.error("", "No se pudo abrir el puerto " + Config.PUERTO + ": " + e.getMessage()
                    + " (¿ya hay un servidor abierto?)");
        }
    }

    /** Reserva el nombre si está libre. synchronized: dos hilos no pueden reservar el mismo nombre. */
    public static synchronized boolean reservarNombre(String nombre) {
        return NOMBRES_EN_USO.add(nombre.toLowerCase());
    }

    public static synchronized void liberarNombre(String nombre) {
        if (nombre != null) {
            NOMBRES_EN_USO.remove(nombre.toLowerCase());
        }
    }

    private static void mostrarIps() {
        try {
            for (NetworkInterface red : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!red.isUp() || red.isLoopback()) continue;
                for (InetAddress ip : Collections.list(red.getInetAddresses())) {
                    if (ip instanceof Inet4Address) {
                        Log.sistema("IP de esta PC: " + Color.pintar(ip.getHostAddress(), Color.NEGRITA + Color.BLANCO)
                                + "  (" + red.getDisplayName() + ")");
                    }
                }
            }
        } catch (SocketException e) {
            Log.sistema("No se pudieron listar las IP (usá ipconfig).");
        }
    }
}
