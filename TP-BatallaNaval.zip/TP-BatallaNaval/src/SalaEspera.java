/**
 * Sala de espera: empareja a los jugadores de a dos.
 *
 * Si no hay nadie esperando, el jugador queda en espera. Si ya había uno, se crea una
 * Partida nueva con los dos. Los métodos son synchronized porque los llaman los hilos
 * de distintos jugadores al mismo tiempo.
 */
public class SalaEspera {

    private ManejadorJugador enEspera;

    public synchronized void buscarRival(ManejadorJugador jugador) {
        if (enEspera == null || enEspera == jugador) {
            enEspera = jugador;
            Log.evento("SALA", Color.AZUL, jugador.getOrigen(), "En la sala de espera, buscando rival...");
            jugador.enviar(new Mensaje(Mensaje.Tipo.ESPERANDO_RIVAL, "Esperando a otro jugador..."));
            return;
        }
        ManejadorJugador rival = enEspera;
        enEspera = null;
        Partida partida = new Partida(rival, jugador);
        rival.setPartida(partida);
        jugador.setPartida(partida);
        partida.iniciar();
    }

    /** Saca al jugador de la sala si estaba esperando (por ejemplo, si se desconectó). */
    public synchronized void quitar(ManejadorJugador jugador) {
        if (enEspera == jugador) {
            enEspera = null;
        }
    }
}
