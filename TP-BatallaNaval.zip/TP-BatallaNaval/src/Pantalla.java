/**
 * Mensajes del cliente en consola, con formato y colores.
 * synchronized: escriben el hilo principal y el receptor, así las líneas no se mezclan.
 */
public class Pantalla {

    public static synchronized void titulo(String texto) {
        String linea = "═".repeat(texto.length() + 6);
        System.out.println();
        System.out.println(Color.pintar("  ╔" + linea + "╗", Color.AZUL));
        System.out.println(Color.pintar("  ║   ", Color.AZUL) + Color.pintar(texto, Color.NEGRITA + Color.BLANCO)
                + Color.pintar("   ║", Color.AZUL));
        System.out.println(Color.pintar("  ╚" + linea + "╝", Color.AZUL));
    }

    public static synchronized void info(String texto) {
        System.out.println(Color.pintar("  » ", Color.CIAN) + texto);
    }

    public static synchronized void exito(String texto) {
        System.out.println(Color.pintar("  ✔ " + texto, Color.NEGRITA + Color.VERDE));
    }

    public static synchronized void error(String texto) {
        System.out.println(Color.pintar("  ✖ " + texto, Color.ROJO));
    }

    public static synchronized void turno(String texto) {
        System.out.println(Color.pintar("  ▶ " + texto, Color.NEGRITA + Color.AMARILLO));
    }

    public static synchronized void chat(String autor, String texto) {
        System.out.println(Color.pintar("  [chat] " + autor + ": ", Color.NEGRITA + Color.MAGENTA) + texto);
    }

    /** Resultado de un disparo, con el color según sea agua, impacto o hundido. */
    public static synchronized void resultado(String quien, String resultado) {
        String color = resultado.startsWith(Tablero.RES_HUNDIDO) ? Color.NEGRITA + Color.ROJO
                : resultado.startsWith(Tablero.RES_IMPACTO) ? Color.NEGRITA + Color.AMARILLO
                : Color.AZUL;
        System.out.printf("  %-34s → %s%n", quien, Color.pintar(resultado, color));
    }

    /** Texto de varias líneas con sangría. */
    public static synchronized void bloque(String texto) {
        System.out.println();
        for (String linea : texto.split("\n")) {
            System.out.println(Color.pintar("    " + linea, Color.CIAN));
        }
        System.out.println();
    }

    public static synchronized void ayuda() {
        System.out.println();
        System.out.println(Color.pintar("  COMANDOS", Color.NEGRITA + Color.CIAN));
        System.out.println("    B7\t\t\tdisparar a esa coordenada (fila A-J, columna 1-10)");
        System.out.println("    chat <mensaje>\tescribirle al rival");
        System.out.println("    tableros\t\tver los dos tableros");
        System.out.println("    barcos\t\testado de tus barcos y de los enemigos hundidos");
        System.out.println("    stats\t\ttus estadísticas e historial de partidas");
        System.out.println("    otra\t\tbuscar otra partida (cuando terminó la actual)");
        System.out.println("    salir\t\tsalir del juego");
        System.out.println();
    }
}
