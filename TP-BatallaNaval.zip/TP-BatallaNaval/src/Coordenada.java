/**
 * Conversión entre lo que escribe el jugador ("B7") y los índices del tablero (fila 1, columna 6).
 * Filas: letras A a J. Columnas: números 1 a 10.
 */
public class Coordenada {

    /** Devuelve {fila, columna} (empezando en 0) o null si el texto no es una coordenada válida. */
    public static int[] parsear(String texto) {
        if (texto == null) {
            return null;
        }
        String t = texto.trim().toUpperCase().replace(" ", "");
        if (t.length() < 2 || t.length() > 3) {
            return null;
        }
        int fila = t.charAt(0) - 'A';
        int columna;
        try {
            columna = Integer.parseInt(t.substring(1)) - 1;
        } catch (NumberFormatException e) {
            return null;
        }
        if (fila < 0 || fila >= Tablero.TAMANIO || columna < 0 || columna >= Tablero.TAMANIO) {
            return null;
        }
        return new int[]{fila, columna};
    }

    /** (1, 6) → "B7" */
    public static String texto(int fila, int columna) {
        return (char) ('A' + fila) + String.valueOf(columna + 1);
    }
}
