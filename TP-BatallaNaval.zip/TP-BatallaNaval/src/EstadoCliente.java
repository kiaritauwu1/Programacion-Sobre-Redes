import java.util.ArrayList;

/**
 * Estado del juego del lado del cliente.
 *
 * Lo comparten dos hilos: el hilo principal (lee el teclado) y el hilo ReceptorServidor
 * (recibe los mensajes del servidor). Por eso todos los métodos son synchronized, y el hilo
 * principal puede quedarse esperando con wait() hasta que el receptor cambie la fase (notifyAll).
 */
public class EstadoCliente {

    public enum Fase { ESPERANDO_RIVAL, COLOCANDO, ESPERANDO_RIVAL_BARCOS, JUGANDO, TERMINADA, DESCONECTADO }

    private Fase fase = Fase.ESPERANDO_RIVAL;
    private boolean miTurno;
    private String nombre;
    private String rival;
    private Tablero propio = new Tablero();         // mis barcos (copia del servidor)
    private Tablero enemigo = new Tablero();        // lo que sé del enemigo (solo mis disparos)
    private final ArrayList<String> enemigosHundidos = new ArrayList<>();

    public synchronized Fase getFase() { return fase; }

    public synchronized void setFase(Fase nueva) {
        fase = nueva;
        notifyAll();                                 // despierta al hilo principal si estaba esperando
    }

    /** El hilo principal se queda esperando mientras la fase sea 'actual'. */
    public synchronized void esperarMientras(Fase actual) {
        while (fase == actual) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    /** Prepara todo para una partida nueva. */
    public synchronized void nuevaPartida(String rival) {
        this.rival = rival;
        this.propio = new Tablero();
        this.enemigo = new Tablero();
        this.enemigosHundidos.clear();
        this.miTurno = false;
    }

    public synchronized boolean isMiTurno() { return miTurno; }
    public synchronized void setMiTurno(boolean miTurno) { this.miTurno = miTurno; }

    public synchronized String getNombre() { return nombre; }
    public synchronized void setNombre(String nombre) { this.nombre = nombre; }

    public synchronized String getRival() { return rival; }

    public synchronized Tablero getPropio() { return propio; }
    public synchronized void setPropio(Tablero propio) { this.propio = propio; }

    public synchronized Tablero getEnemigo() { return enemigo; }

    public synchronized ArrayList<String> getEnemigosHundidos() { return enemigosHundidos; }

    /** Muestra los dos tableros lado a lado. */
    public synchronized void mostrarTableros() {
        Tablero.mostrarDosTableros(propio, "TU FLOTA (" + nombre + ")", enemigo, "ENEMIGO (" + rival + ")");
    }
}
