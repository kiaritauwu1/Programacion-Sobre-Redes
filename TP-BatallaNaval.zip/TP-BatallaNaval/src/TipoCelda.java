/**
 * Estados posibles de una casilla del tablero.
 */
public enum TipoCelda {
    AGUA,       // celda sin barco
    BARCO,      // celda con parte de un barco
    IMPACTO,    // celda con barco que fue disparada
    FALLO       // celda de agua que fue disparada
}
