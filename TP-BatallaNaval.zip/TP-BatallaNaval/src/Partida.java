import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Una partida entre dos jugadores. El servidor puede tener muchas a la vez.
 *
 * El servidor es quien manda: guarda los tableros reales de los dos jugadores,
 * controla de quién es el turno, valida cada disparo y decide quién gana.
 *
 * SINCRONIZACIÓN: todos los métodos públicos son synchronized. Los llaman los hilos de
 * los dos jugadores, y así nunca se ejecutan dos acciones a la vez sobre la misma partida
 * (por ejemplo, un disparo y una desconexión al mismo tiempo).
 */
public class Partida {

    private enum Estado { COLOCANDO, JUGANDO, TERMINADA }

    private static int contador = 0;

    private final int id;
    private final ManejadorJugador jugador1;
    private final ManejadorJugador jugador2;
    private Tablero tablero1;
    private Tablero tablero2;
    private ManejadorJugador turno;
    private Estado estado;
    private int disparos;
    private final long inicio;

    public Partida(ManejadorJugador jugador1, ManejadorJugador jugador2) {
        this.id = siguienteId();
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.estado = Estado.COLOCANDO;
        this.inicio = System.currentTimeMillis();
    }

    private static synchronized int siguienteId() {
        return ++contador;
    }

    // =====================================================================
    //  INICIO Y UBICACIÓN DE BARCOS
    // =====================================================================

    public synchronized void iniciar() {
        Log.evento("PARTIDA", Color.VERDE, "Partida #" + id,
                Color.pintar(jugador1.getNombre() + " vs " + jugador2.getNombre(), Color.NEGRITA) + " — ubicando barcos");
        Mensaje m1 = new Mensaje(Mensaje.Tipo.PARTIDA_ENCONTRADA, jugador2.getNombre());
        m1.setRemitente("Partida #" + id);
        jugador1.enviar(m1);
        Mensaje m2 = new Mensaje(Mensaje.Tipo.PARTIDA_ENCONTRADA, jugador1.getNombre());
        m2.setRemitente("Partida #" + id);
        jugador2.enviar(m2);
    }

    /** Recibe y valida la ubicación de los barcos de un jugador. */
    public synchronized void registrarBarcos(ManejadorJugador jugador, ArrayList<PosicionBarco> posiciones) {
        if (estado != Estado.COLOCANDO) {
            jugador.enviar(new Mensaje(Mensaje.Tipo.ERROR, "Ya no se pueden ubicar barcos."));
            return;
        }
        Tablero tablero = validarFlota(posiciones);
        if (tablero == null) {
            Log.error(jugador.getOrigen(), "Ubicación de barcos inválida, se rechaza.");
            jugador.enviar(new Mensaje(Mensaje.Tipo.BARCOS_RECHAZADOS, "La ubicación de los barcos no es válida. Volvé a ubicarlos."));
            return;
        }
        if (jugador == jugador1) tablero1 = tablero; else tablero2 = tablero;
        Log.evento("BARCOS", Color.CIAN, jugador.getOrigen(), "Ubicó sus " + Config.CANTIDAD_BARCOS + " barcos (validado).");

        if (tablero1 == null || tablero2 == null) {
            jugador.enviar(new Mensaje(Mensaje.Tipo.ESPERANDO_RIVAL_BARCOS,
                    "Barcos ubicados. Esperando que " + rivalDe(jugador).getNombre() + " ubique los suyos..."));
            return;
        }

        // Los dos están listos: empieza el juego
        estado = Estado.JUGANDO;
        turno = jugador1;
        Log.evento("PARTIDA", Color.VERDE, "Partida #" + id, "¡Comienza la batalla! Empieza " + turno.getNombre());
        jugador1.enviar(new Mensaje(Mensaje.Tipo.INICIO_JUEGO, "¡Comienza la batalla contra " + jugador2.getNombre() + "!"));
        jugador2.enviar(new Mensaje(Mensaje.Tipo.INICIO_JUEGO, "¡Comienza la batalla contra " + jugador1.getNombre() + "!"));
        notificarTurno();
    }

    /** Arma un tablero con las posiciones recibidas y comprueba que sea exactamente la flota oficial. */
    private Tablero validarFlota(ArrayList<PosicionBarco> posiciones) {
        if (posiciones == null || posiciones.size() != Config.CANTIDAD_BARCOS) {
            return null;
        }
        Tablero tablero = new Tablero();
        Set<String> nombres = new HashSet<>();
        for (PosicionBarco p : posiciones) {
            if (Config.longitudDe(p.getNombre()) != p.getLongitud() || !nombres.add(p.getNombre())) {
                return null;                     // barco que no existe, longitud trucha o repetido
            }
            if (!tablero.colocarBarco(p.getNombre(), p.getFila(), p.getColumna(), p.getLongitud(), p.isHorizontal())) {
                return null;                     // fuera del tablero o superpuesto
            }
        }
        return tablero;
    }

    // =====================================================================
    //  DISPAROS Y TURNOS
    // =====================================================================

    public synchronized void disparar(ManejadorJugador tirador, int fila, int columna) {
        if (estado != Estado.JUGANDO) {
            tirador.enviar(new Mensaje(Mensaje.Tipo.ERROR, "La partida no está en juego."));
            return;
        }
        if (tirador != turno) {
            tirador.enviar(new Mensaje(Mensaje.Tipo.ERROR, "No es tu turno."));
            return;
        }

        ManejadorJugador rival = rivalDe(tirador);
        Tablero objetivo = tableroDe(rival);
        String resultado = objetivo.disparar(fila, columna);
        String coord = Coordenada.texto(fila, columna);

        // Disparo inválido: se avisa y el turno sigue siendo del mismo jugador
        if (resultado.equals(Tablero.RES_INVALIDA) || resultado.equals(Tablero.RES_REPETIDO)) {
            Log.aviso(tirador.getOrigen(), "Disparo rechazado en " + coord + ": " + resultado);
            tirador.enviar(new Mensaje(Mensaje.Tipo.ERROR, resultado + " (" + coord + ")."));
            tirador.enviar(new Mensaje(Mensaje.Tipo.TU_TURNO));
            return;
        }

        disparos++;
        boolean impacto = !resultado.equals(Tablero.RES_AGUA);
        String hundido = resultado.startsWith(Tablero.RES_HUNDIDO)
                ? resultado.substring(Tablero.RES_HUNDIDO.length()).trim() : null;

        String color = hundido != null ? Color.ROJO : impacto ? Color.AMARILLO : Color.AZUL;
        Log.evento("DISPARO", Color.MAGENTA, tirador.getOrigen(),
                "→ " + rival.getNombre() + " en " + coord + ": " + Color.pintar(resultado, Color.NEGRITA + color));

        // Se avisa a los dos: al que disparó y al que recibió el disparo
        tirador.enviar(Mensaje.resultado(Mensaje.Tipo.RESULTADO_DISPARO, tirador.getNombre(), fila, columna, resultado, impacto, hundido));
        rival.enviar(Mensaje.resultado(Mensaje.Tipo.DISPARO_RECIBIDO, tirador.getNombre(), fila, columna, resultado, impacto, hundido));

        if (objetivo.todosLosBarcosCaidos()) {
            terminar(tirador, rival, "flota hundida");
            return;
        }

        turno = rival;              // los turnos se alternan
        notificarTurno();
    }

    private void notificarTurno() {
        ManejadorJugador espera = rivalDe(turno);
        turno.enviar(new Mensaje(Mensaje.Tipo.TU_TURNO));
        espera.enviar(new Mensaje(Mensaje.Tipo.TURNO_RIVAL, turno.getNombre()));
    }

    // =====================================================================
    //  CHAT Y FIN
    // =====================================================================

    public synchronized void chat(ManejadorJugador autor, String texto) {
        if (texto == null || texto.isBlank()) return;
        Log.evento("CHAT", Color.CIAN, autor.getOrigen(), texto);
        Mensaje m = new Mensaje(Mensaje.Tipo.CHAT, texto);
        m.setRemitente(autor.getNombre());
        rivalDe(autor).enviar(m);
    }

    /** Un jugador se fue o se cortó: el otro gana por abandono. */
    public synchronized void abandonar(ManejadorJugador jugador) {
        if (estado == Estado.TERMINADA) {
            return;
        }
        estado = Estado.TERMINADA;
        ManejadorJugador otro = rivalDe(jugador);
        Log.evento("PARTIDA", Color.AMARILLO, "Partida #" + id, jugador.getNombre() + " abandonó. Gana " + otro.getNombre());
        otro.enviar(new Mensaje(Mensaje.Tipo.RIVAL_DESCONECTADO, jugador.getNombre() + " abandonó la partida. ¡Ganaste por abandono!"));
        Historial.registrar(id, jugador1.getNombre(), jugador2.getNombre(), otro.getNombre(), "abandono", disparos, segundos());
        jugador1.setPartida(null);
        jugador2.setPartida(null);
    }

    private void terminar(ManejadorJugador ganador, ManejadorJugador perdedor, String motivo) {
        estado = Estado.TERMINADA;
        Log.evento("PARTIDA", Color.VERDE, "Partida #" + id,
                Color.pintar("¡GANÓ " + ganador.getNombre() + "!", Color.NEGRITA + Color.VERDE)
                        + " (" + disparos + " disparos, " + segundos() + " s)");

        Mensaje gano = new Mensaje(Mensaje.Tipo.FIN_PARTIDA, perdedor.getNombre());
        gano.setGano(true);
        ganador.enviar(gano);
        Mensaje perdio = new Mensaje(Mensaje.Tipo.FIN_PARTIDA, ganador.getNombre());
        perdio.setGano(false);
        perdedor.enviar(perdio);

        Historial.registrar(id, jugador1.getNombre(), jugador2.getNombre(), ganador.getNombre(), motivo, disparos, segundos());
        jugador1.setPartida(null);
        jugador2.setPartida(null);
    }

    // =====================================================================
    //  AUXILIARES
    // =====================================================================

    private ManejadorJugador rivalDe(ManejadorJugador jugador) {
        return jugador == jugador1 ? jugador2 : jugador1;
    }

    private Tablero tableroDe(ManejadorJugador jugador) {
        return jugador == jugador1 ? tablero1 : tablero2;
    }

    private long segundos() {
        return (System.currentTimeMillis() - inicio) / 1000;
    }
}
