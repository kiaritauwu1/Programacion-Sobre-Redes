import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;

/**
 * Atiende a UN jugador en su propio hilo (implementa Runnable).
 *
 * STREAMS:
 *  - ObjectOutputStream se crea ANTES que ObjectInputStream y se hace flush: así se envía el
 *    encabezado del stream y el otro lado puede crear su ObjectInputStream sin quedarse bloqueado.
 *  - Ambos se cierran solos con try-with-resources (junto con el socket).
 *
 * HILOS:
 *  - Este hilo solo LEE los mensajes de su jugador y se los pasa a la Partida.
 *  - El método enviar() es synchronized porque también lo usa el hilo del rival
 *    (por ejemplo, cuando el rival dispara, su hilo le avisa a este jugador).
 */
public class ManejadorJugador implements Runnable {

    private final Socket socket;
    private final SalaEspera sala;
    private ObjectOutputStream salida;
    private String nombre;
    private String origen;
    private volatile Partida partida;     // volatile: la asignan otros hilos (la sala o el rival)

    public ManejadorJugador(Socket socket, SalaEspera sala) {
        this.socket = socket;
        this.sala = sala;
        this.origen = Thread.currentThread().getName();
    }

    @Override
    public void run() {
        origen = Thread.currentThread().getName() + " " + socket.getInetAddress().getHostAddress();
        Log.conexion(origen, "Nueva conexión desde " + socket.getInetAddress().getHostAddress() + ":" + socket.getPort()
                + " → hilo " + Thread.currentThread().getName());

        try (Socket s = socket;
             ObjectOutputStream out = crearSalida(s);
             ObjectInputStream entrada = new ObjectInputStream(new BufferedInputStream(s.getInputStream()))) {

            if (!autenticar(entrada)) {
                return;
            }
            sala.buscarRival(this);

            boolean seguir = true;
            while (seguir) {
                Mensaje m = (Mensaje) entrada.readObject();   // espera el próximo mensaje del jugador
                seguir = procesar(m);
            }
            Log.desconexion(origen, "Salió del juego.");

        } catch (EOFException | SocketException e) {
            Log.desconexion(origen, "Se desconectó.");
        } catch (ClassNotFoundException e) {
            Log.error(origen, "Llegó un objeto desconocido: " + e.getMessage());
        } catch (IOException e) {
            Log.error(origen, "Error de comunicación: " + e.getMessage());
        } finally {
            // Pase lo que pase: se saca de la sala, se avisa al rival y se libera el nombre
            sala.quitar(this);
            Partida p = partida;
            if (p != null) {
                p.abandonar(this);
            }
            ServidorBatalla.liberarNombre(nombre);
            Log.sistema("Fin del hilo " + Thread.currentThread().getName() + (nombre == null ? "" : " (" + nombre + ")"));
        }
    }

    private ObjectOutputStream crearSalida(Socket s) throws IOException {
        salida = new ObjectOutputStream(new BufferedOutputStream(s.getOutputStream()));
        salida.flush();
        return salida;
    }

    /** Pide el nombre hasta que sea válido y no esté en uso. */
    private boolean autenticar(ObjectInputStream entrada) throws IOException, ClassNotFoundException {
        while (true) {
            Mensaje m = (Mensaje) entrada.readObject();
            if (m.getTipo() == Mensaje.Tipo.SALIR) {
                return false;
            }
            if (m.getTipo() != Mensaje.Tipo.CONECTAR) {
                enviar(new Mensaje(Mensaje.Tipo.ERROR, "Primero tenés que conectarte con tu nombre."));
                continue;
            }
            String pedido = m.getTexto() == null ? "" : m.getTexto().trim();
            if (!pedido.matches("[\\p{L}0-9_]{2,15}")) {
                enviar(new Mensaje(Mensaje.Tipo.ERROR, "Nombre inválido: de 2 a 15 letras o números, sin espacios."));
            } else if (!ServidorBatalla.reservarNombre(pedido)) {
                enviar(new Mensaje(Mensaje.Tipo.ERROR, "El nombre \"" + pedido + "\" ya está en uso. Elegí otro."));
            } else {
                nombre = pedido;
                origen = Thread.currentThread().getName() + " " + nombre;
                Log.seguridad(origen, Color.pintar("Jugador autenticado: " + nombre, Color.VERDE));
                enviar(new Mensaje(Mensaje.Tipo.BIENVENIDA, "¡Bienvenido/a, " + nombre + "!"));
                return true;
            }
        }
    }

    /** Procesa un mensaje. Devuelve false cuando el jugador quiere salir. */
    private boolean procesar(Mensaje m) {
        Partida p = partida;
        switch (m.getTipo()) {
            case COLOCAR_BARCOS:
                if (p != null) p.registrarBarcos(this, m.getBarcos());
                else enviar(new Mensaje(Mensaje.Tipo.ERROR, "No estás en ninguna partida."));
                break;
            case DISPARO:
                if (p != null) p.disparar(this, m.getFila(), m.getColumna());
                else enviar(new Mensaje(Mensaje.Tipo.ERROR, "No estás en ninguna partida."));
                break;
            case CHAT:
                if (p != null) p.chat(this, m.getTexto());
                else enviar(new Mensaje(Mensaje.Tipo.ERROR, "No hay rival para chatear."));
                break;
            case BUSCAR_PARTIDA:
                if (p == null) sala.buscarRival(this);
                else enviar(new Mensaje(Mensaje.Tipo.ERROR, "Ya estás en una partida."));
                break;
            case ESTADISTICAS:
                enviar(new Mensaje(Mensaje.Tipo.ESTADISTICAS, Historial.estadisticas(nombre)));
                break;
            case SALIR:
                return false;
            default:
                enviar(new Mensaje(Mensaje.Tipo.ERROR, "Mensaje no esperado: " + m.getTipo()));
        }
        return true;
    }

    /**
     * Envía un mensaje a este jugador.
     * synchronized: lo pueden llamar a la vez este hilo y el del rival, y los objetos no deben mezclarse.
     */
    public synchronized void enviar(Mensaje m) {
        try {
            salida.writeObject(m);
            salida.reset();          // evita que el stream reutilice objetos ya enviados
            salida.flush();
        } catch (IOException e) {
            Log.error(origen, "No se pudo enviar " + m.getTipo() + ": " + e.getMessage());
        }
    }

    public String getNombre() { return nombre; }
    public String getOrigen() { return origen; }
    public Partida getPartida() { return partida; }
    public void setPartida(Partida partida) { this.partida = partida; }
}
