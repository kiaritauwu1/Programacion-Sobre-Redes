import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Random;

/**
 * CLIENTE DE BATALLA NAVAL
 *
 * HILOS:
 *  - Hilo principal: lee lo que escribe el jugador (ubicación de barcos, disparos, chat).
 *  - Hilo ReceptorServidor: recibe los mensajes del servidor y actualiza la pantalla.
 *  - Los dos comparten el objeto EstadoCliente (sincronizado).
 *
 * STREAMS:
 *  - Socket: ObjectOutputStream / ObjectInputStream (se envían objetos Mensaje serializados).
 *  - Teclado: BufferedReader sobre System.in.
 *  - Todo se cierra con try-with-resources al salir.
 */
public class ClienteBatalla {

    private static final BufferedReader TECLADO = new BufferedReader(new InputStreamReader(System.in));
    private static final EstadoCliente ESTADO = new EstadoCliente();
    private static ObjectOutputStream salida;

    public static void main(String[] args) {
        Pantalla.titulo("BATALLA NAVAL  ·  CLIENTE");

        String ip = leer("  IP del servidor [ENTER = 127.0.0.1]: ");
        if (ip == null) return;
        if (ip.isEmpty()) ip = "127.0.0.1";
        String textoPuerto = leer("  Puerto [ENTER = " + Config.PUERTO + "]: ");
        if (textoPuerto == null) return;
        int puerto = Config.PUERTO;
        try {
            if (!textoPuerto.isEmpty()) puerto = Integer.parseInt(textoPuerto);
        } catch (NumberFormatException e) {
            Pantalla.error("Puerto inválido, se usa " + Config.PUERTO);
        }

        Socket socket = new Socket();
        try {
            Pantalla.info("Conectando a " + ip + ":" + puerto + "...");
            socket.connect(new InetSocketAddress(ip, puerto), 5000);
        } catch (IOException e) {
            Pantalla.error("No se pudo conectar: " + e.getMessage() + " (¿servidor abierto? ¿IP correcta? ¿firewall?)");
            try { socket.close(); } catch (IOException ignorada) { }
            return;
        }

        // El ObjectOutputStream se crea primero y se hace flush para no bloquear al servidor
        try (Socket s = socket;
             ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(s.getOutputStream()))) {
            out.flush();
            salida = out;
            try (ObjectInputStream entrada = new ObjectInputStream(new BufferedInputStream(s.getInputStream()))) {
                Pantalla.exito("Conectado al servidor " + ip + ":" + puerto);

                if (!autenticar(entrada)) {
                    return;
                }

                // Desde acá, otro hilo escucha al servidor y este hilo atiende el teclado
                Thread receptor = new Thread(new ReceptorServidor(entrada, ESTADO), "Receptor");
                receptor.setDaemon(true);
                receptor.start();

                Pantalla.ayuda();
                buclePrincipal();
            }
        } catch (SocketException e) {
            Pantalla.error("Se cortó la conexión con el servidor.");
        } catch (IOException | ClassNotFoundException e) {
            Pantalla.error("Error de comunicación: " + e.getMessage());
        }
        Pantalla.info("Streams y socket cerrados. ¡Hasta la próxima!");
    }

    // =====================================================================
    //  CONEXIÓN
    // =====================================================================

    private static boolean autenticar(ObjectInputStream entrada) throws IOException, ClassNotFoundException {
        while (true) {
            String nombre = leer("  Tu nombre de jugador: ");
            if (nombre == null) {
                enviar(new Mensaje(Mensaje.Tipo.SALIR));
                return false;
            }
            enviar(new Mensaje(Mensaje.Tipo.CONECTAR, nombre));
            Mensaje respuesta = (Mensaje) entrada.readObject();
            if (respuesta.getTipo() == Mensaje.Tipo.BIENVENIDA) {
                ESTADO.setNombre(nombre);
                Pantalla.exito(respuesta.getTexto());
                return true;
            }
            Pantalla.error(respuesta.getTexto());
        }
    }

    // =====================================================================
    //  BUCLE PRINCIPAL
    // =====================================================================

    private static void buclePrincipal() {
        while (true) {
            EstadoCliente.Fase fase = ESTADO.getFase();
            switch (fase) {
                case ESPERANDO_RIVAL:
                    ESTADO.esperarMientras(EstadoCliente.Fase.ESPERANDO_RIVAL);   // espera sin consumir teclado
                    break;
                case COLOCANDO:
                    colocarBarcos();
                    break;
                case DESCONECTADO:
                    return;
                default:
                    String linea = leer("");
                    if (linea == null || linea.equalsIgnoreCase("salir")) {
                        salir();
                        return;
                    }
                    procesarComando(linea);
            }
        }
    }

    private static void procesarComando(String linea) {
        if (linea.isEmpty() || ESTADO.getFase() == EstadoCliente.Fase.DESCONECTADO) {
            return;
        }
        String comando = linea.toLowerCase();

        if (comando.startsWith("chat ")) {
            enviarChat(linea.substring(5));
        } else if (comando.equals("ayuda") || comando.equals("help")) {
            Pantalla.ayuda();
        } else if (comando.equals("tableros")) {
            ESTADO.mostrarTableros();
        } else if (comando.equals("barcos")) {
            ESTADO.getPropio().mostrarBarcos();
            Pantalla.info("Barcos enemigos hundidos: " + (ESTADO.getEnemigosHundidos().isEmpty()
                    ? "ninguno" : String.join(", ", ESTADO.getEnemigosHundidos())));
        } else if (comando.equals("stats")) {
            enviar(new Mensaje(Mensaje.Tipo.ESTADISTICAS));
        } else if (comando.equals("otra")) {
            if (ESTADO.getFase() == EstadoCliente.Fase.TERMINADA) {
                ESTADO.setFase(EstadoCliente.Fase.ESPERANDO_RIVAL);
                enviar(new Mensaje(Mensaje.Tipo.BUSCAR_PARTIDA));
            } else {
                Pantalla.error("Todavía estás en una partida.");
            }
        } else if (ESTADO.getFase() == EstadoCliente.Fase.JUGANDO) {
            disparar(linea);
        } else if (ESTADO.getFase() == EstadoCliente.Fase.TERMINADA) {
            Pantalla.error("La partida terminó. Escribí OTRA, STATS o SALIR.");
        } else if (ESTADO.getFase() == EstadoCliente.Fase.ESPERANDO_RIVAL_BARCOS) {
            Pantalla.info("Esperando que " + ESTADO.getRival() + " termine de ubicar sus barcos...");
        } else {
            Pantalla.error("Comando no reconocido. Escribí AYUDA.");
        }
    }

    private static void disparar(String texto) {
        int[] c = Coordenada.parsear(texto);
        if (c == null) {
            Pantalla.error("Coordenada inválida. Usá fila A-J y columna 1-10, por ejemplo B7.");
            return;
        }
        if (!ESTADO.isMiTurno()) {
            Pantalla.error("No es tu turno. Esperá el disparo de " + ESTADO.getRival() + ".");
            return;
        }
        if (ESTADO.getEnemigo().getCelda(c[0], c[1]).isDisparada()) {
            Pantalla.error("Ya disparaste a " + Coordenada.texto(c[0], c[1]) + ". Elegí otra casilla.");
            return;
        }
        ESTADO.setMiTurno(false);
        enviar(Mensaje.disparo(c[0], c[1]));
    }

    // =====================================================================
    //  UBICACIÓN DE BARCOS
    // =====================================================================

    private static void colocarBarcos() {
        Tablero tablero = new Tablero();
        ArrayList<PosicionBarco> posiciones = new ArrayList<>();

        Pantalla.info("Ubicá tus barcos. Escribí la coordenada inicial y la orientación:");
        Pantalla.info("  H = horizontal (hacia la derecha)   V = vertical (hacia abajo)   Ej: " + Color.pintar("A1 H", Color.NEGRITA)
                + "   o " + Color.pintar("AUTO", Color.NEGRITA) + " para ubicar al azar los que faltan.");

        for (int i = 0; i < Config.CANTIDAD_BARCOS; i++) {
            String nombre = Config.NOMBRES_BARCOS[i];
            int longitud = Config.LONGITUDES_BARCOS[i];
            boolean colocado = false;

            while (!colocado) {
                if (ESTADO.getFase() != EstadoCliente.Fase.COLOCANDO) {
                    return;                                   // la partida se canceló (rival desconectado)
                }
                tablero.mostrarTablero(false);
                String linea = leer(Color.pintar("  " + nombre + " (" + longitud + " casillas): ", Color.NEGRITA + Color.AMARILLO));
                if (linea == null || linea.equalsIgnoreCase("salir")) {
                    salir();
                    return;
                }
                if (ESTADO.getFase() != EstadoCliente.Fase.COLOCANDO) {
                    procesarComando(linea);                   // la partida terminó mientras escribía
                    return;
                }
                if (linea.toLowerCase().startsWith("chat ")) {
                    enviarChat(linea.substring(5));
                    continue;
                }
                if (linea.equalsIgnoreCase("auto")) {
                    colocarAlAzar(tablero, posiciones, i);
                    i = Config.CANTIDAD_BARCOS;               // ya están todos
                    break;
                }

                String[] partes = linea.trim().split("\\s+");
                int[] c = partes.length == 2 ? Coordenada.parsear(partes[0]) : null;
                String orientacion = partes.length == 2 ? partes[1].toUpperCase() : "";
                if (c == null || !(orientacion.equals("H") || orientacion.equals("V"))) {
                    Pantalla.error("Formato: coordenada y orientación, por ejemplo C3 V");
                    continue;
                }
                boolean horizontal = orientacion.equals("H");
                if (tablero.colocarBarco(nombre, c[0], c[1], longitud, horizontal)) {
                    posiciones.add(new PosicionBarco(nombre, c[0], c[1], longitud, horizontal));
                    colocado = true;
                } else {
                    Pantalla.error("El " + nombre + " no entra ahí o se superpone con otro barco.");
                }
            }
        }

        tablero.mostrarTablero(false);
        tablero.mostrarBarcos();
        ESTADO.setPropio(tablero);
        ESTADO.setFase(EstadoCliente.Fase.ESPERANDO_RIVAL_BARCOS);
        Mensaje m = new Mensaje(Mensaje.Tipo.COLOCAR_BARCOS);
        m.setBarcos(posiciones);
        enviar(m);
    }

    /** Ubica al azar los barcos que faltan (desde el índice 'desde'). */
    private static void colocarAlAzar(Tablero tablero, ArrayList<PosicionBarco> posiciones, int desde) {
        Random azar = new Random();
        for (int i = desde; i < Config.CANTIDAD_BARCOS; i++) {
            String nombre = Config.NOMBRES_BARCOS[i];
            int longitud = Config.LONGITUDES_BARCOS[i];
            boolean colocado = false;
            while (!colocado) {
                int fila = azar.nextInt(Tablero.TAMANIO);
                int col = azar.nextInt(Tablero.TAMANIO);
                boolean horizontal = azar.nextBoolean();
                if (tablero.colocarBarco(nombre, fila, col, longitud, horizontal)) {
                    posiciones.add(new PosicionBarco(nombre, fila, col, longitud, horizontal));
                    colocado = true;
                }
            }
        }
    }

    // =====================================================================
    //  AUXILIARES
    // =====================================================================

    private static void enviarChat(String texto) {
        if (texto.isBlank()) return;
        enviar(new Mensaje(Mensaje.Tipo.CHAT, texto.trim()));
        Pantalla.chat("Vos", texto.trim());
    }

    private static void salir() {
        ESTADO.setFase(EstadoCliente.Fase.DESCONECTADO);
        enviar(new Mensaje(Mensaje.Tipo.SALIR));
    }

    /** Envía un objeto Mensaje al servidor. synchronized: un solo envío a la vez. */
    private static synchronized void enviar(Mensaje m) {
        try {
            salida.writeObject(m);
            salida.reset();
            salida.flush();
        } catch (IOException e) {
            Pantalla.error("No se pudo enviar al servidor: " + e.getMessage());
        }
    }

    /** Lee una línea del teclado. Si viene de un archivo (pruebas), la muestra en pantalla. */
    private static String leer(String mensaje) {
        System.out.print(mensaje);
        System.out.flush();
        try {
            String linea = TECLADO.readLine();
            if (linea != null && System.console() == null) {
                System.out.println(linea);
            }
            return linea == null ? null : linea.trim();
        } catch (IOException e) {
            return null;
        }
    }
}
