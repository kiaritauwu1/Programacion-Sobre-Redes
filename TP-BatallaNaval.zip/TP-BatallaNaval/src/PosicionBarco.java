import java.io.Serializable;

/**
 * Ubicación de un barco que el cliente envía al servidor (viaja serializada dentro de un Mensaje).
 */
public class PosicionBarco implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String nombre;
    private final int fila;
    private final int columna;
    private final int longitud;
    private final boolean horizontal;

    public PosicionBarco(String nombre, int fila, int columna, int longitud, boolean horizontal) {
        this.nombre = nombre;
        this.fila = fila;
        this.columna = columna;
        this.longitud = longitud;
        this.horizontal = horizontal;
    }

    public String getNombre() { return nombre; }
    public int getFila() { return fila; }
    public int getColumna() { return columna; }
    public int getLongitud() { return longitud; }
    public boolean isHorizontal() { return horizontal; }
}
