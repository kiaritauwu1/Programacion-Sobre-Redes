/**
 * Un barco de la flota.
 */
public class Barco {

    private final String nombre;
    private final int longitud;
    private int impactos;

    public Barco(String nombre, int longitud) {
        this.nombre = nombre;
        this.longitud = longitud;
        this.impactos = 0;
    }

    /** Suma un impacto al barco. */
    public void recibirImpacto() {
        impactos++;
    }

    /** El barco está hundido cuando todas sus casillas fueron impactadas. */
    public boolean estaHundido() {
        return impactos >= longitud;
    }

    public String getNombre() { return nombre; }
    public int getLongitud() { return longitud; }
    public int getImpactos() { return impactos; }
}
