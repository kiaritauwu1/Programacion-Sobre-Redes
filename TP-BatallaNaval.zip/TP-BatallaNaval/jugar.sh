#!/bin/sh
# Compila y abre el cliente de Batalla Naval (para la VM Debian o Alpine)
cd "$(dirname "$0")" || exit 1
mkdir -p bin
javac -encoding UTF-8 -d bin src/*.java || { echo "No se pudo compilar. ¿Está instalada la JDK? (java -version)"; exit 1; }
java -Dfile.encoding=UTF-8 -cp bin ClienteBatalla
