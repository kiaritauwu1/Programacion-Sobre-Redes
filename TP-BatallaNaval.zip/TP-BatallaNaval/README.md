# Batalla Naval multijugador (Sockets TCP + Hilos + POO)

Juego por consola para 2 jugadores en red. El servidor arma partidas de a dos y puede tener varias partidas al mismo tiempo.

## Cómo jugar

1. En la PC servidor: `1-SERVIDOR.bat` (muestra la IP de la PC).
2. Cada jugador: `2-JUGADOR.bat`, escribe la IP del servidor, el puerto (ENTER = 7000) y su nombre.
3. Cuando hay dos jugadores en la sala, empieza la partida: cada uno ubica sus barcos (`A1 H`, `C5 V` o `AUTO`).
4. En tu turno escribí la coordenada del disparo, por ejemplo `B7`.

Comandos: `B7` disparar · `chat <mensaje>` · `tableros` · `barcos` · `stats` · `otra` · `salir`

Símbolos: `~` agua · `B` barco · `X` impacto · `O` fallo

## Clases

| Clase | Rol |
|---|---|
| `TipoCelda`, `Celda`, `Barco`, `Tablero` | Modelo del juego (`ArrayList<ArrayList<Celda>>` de 10x10) |
| `Config`, `Coordenada` | Flota oficial, puerto y conversión de coordenadas (`B7`) |
| `Mensaje`, `PosicionBarco` | Protocolo: objetos serializables que viajan por el socket |
| `ServidorBatalla` | `ServerSocket`: acepta jugadores y crea un `Thread` por cada uno |
| `ManejadorJugador` | Hilo de cada jugador (lee sus mensajes, `enviar()` sincronizado) |
| `SalaEspera` | Empareja jugadores de a dos (sincronizado) |
| `Partida` | Estado de una partida: tableros, turnos, disparos, ganador (sincronizado) |
| `Historial` | Guarda las partidas en `historial_partidas.txt` y calcula estadísticas |
| `ClienteBatalla` | Cliente: conexión, ubicación de barcos, disparos, chat |
| `ReceptorServidor` | Hilo del cliente que escucha al servidor |
| `EstadoCliente`, `Pantalla` | Estado compartido entre hilos del cliente y salida con colores |
| `Log`, `Color` | Log del servidor y colores ANSI |

## Extras implementados

- Sala de espera para emparejar jugadores
- Varias partidas simultáneas en el servidor
- Chat entre jugadores durante la partida
- Estadísticas e historial de partidas en archivo de texto
