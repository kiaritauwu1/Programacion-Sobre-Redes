@echo off
chcp 65001 >nul
title BATALLA NAVAL - JUGADOR
cd /d "%~dp0"
if not exist bin\ClienteBatalla.class (
  if not exist bin mkdir bin
  javac -encoding UTF-8 -d bin src\*.java
)
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -cp bin ClienteBatalla
pause
