import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/**
 * CLIENTE DE NUBE
 *
 * Pide la IP del servidor, se conecta y ofrece una consola de comandos:
 *   LOGIN <usuario> <clave>     inicia sesión
 *   LIST                        lista los archivos de la nube con su tamaño
 *   UPLOAD <nombre_archivo>     sube un archivo (lo busca en la carpeta "mis_archivos" o en la ruta indicada)
 *   DOWNLOAD <nombre_archivo>   descarga un archivo a la carpeta "descargas"
 *   EXIT                        cierra la sesión y los sockets
 *
 * HILOS: el cliente usa un solo hilo, porque cada comando espera su respuesta
 * antes de que el usuario escriba el siguiente.
 *
 * STREAMS:
 *  - Teclado: BufferedReader(InputStreamReader(System.in))
 *  - Socket:  DataInputStream / DataOutputStream (texto con readUTF/writeUTF, archivos como bytes)
 *  - Disco:   FileInputStream para leer lo que se sube, FileOutputStream para escribir lo que se baja
 */
public class ClienteNube {

    private static final int PUERTO = 6000;
    private static final File CARPETA_SUBIDAS = new File("mis_archivos");
    private static final File CARPETA_DESCARGAS = new File("descargas");

    private static final BufferedReader TECLADO = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) {
        Log.titulo("CLIENTE DE NUBE");
        CARPETA_SUBIDAS.mkdirs();
        CARPETA_DESCARGAS.mkdirs();

        String ip = preguntar("IP del servidor [ENTER = 127.0.0.1]: ");
        if (ip == null) return;
        if (ip.isEmpty()) ip = "127.0.0.1";

        Socket socket = new Socket();
        try {
            Log.sistema("Conectando a " + ip + ":" + PUERTO + "...");
            socket.connect(new InetSocketAddress(ip, PUERTO), 5000);
        } catch (IOException e) {
            Log.error("", "No se pudo conectar a " + ip + ":" + PUERTO + " → " + e.getMessage()
                    + "  (¿servidor abierto? ¿misma red? ¿firewall?)");
            try { socket.close(); } catch (IOException ignorada) { }
            return;
        }

        // try-with-resources: cierra streams y socket al salir (EXIT, error o desconexión)
        try (Socket s = socket;
             DataInputStream entrada = new DataInputStream(new BufferedInputStream(s.getInputStream()));
             DataOutputStream salida = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()))) {

            Log.conexion("", "Conectado al servidor " + Color.pintar(ip + ":" + PUERTO, Color.NEGRITA)
                    + " desde el puerto local " + s.getLocalPort());
            mostrarAyuda();

            boolean seguir = true;
            while (seguir) {
                String linea = preguntar(Color.pintar("nube> ", Color.NEGRITA + Color.VERDE));
                if (linea == null) linea = "EXIT";          // se cerró la entrada: se sale prolijo
                if (linea.isEmpty()) continue;

                String[] partes = linea.split(" ", 2);
                String comando = partes[0].toUpperCase();
                String argumento = partes.length > 1 ? partes[1].trim() : "";

                switch (comando) {
                    case "LOGIN":    simple(entrada, salida, "LOGIN " + argumento); break;
                    case "LIST":     listar(entrada, salida); break;
                    case "UPLOAD":   subir(entrada, salida, argumento); break;
                    case "DOWNLOAD": descargar(entrada, salida, argumento); break;
                    case "EXIT":
                        simple(entrada, salida, "EXIT");
                        seguir = false;
                        break;
                    case "AYUDA":
                    case "HELP":     mostrarAyuda(); break;
                    default:
                        Log.error("", "Comando desconocido. Escribí AYUDA para ver los comandos.");
                }
            }
            Log.desconexion("", "Sesión cerrada. Streams y socket liberados.");

        } catch (EOFException | SocketException e) {
            Log.desconexion("", "El servidor cerró la conexión.");
        } catch (IOException e) {
            Log.error("", "Error de comunicación: " + e.getMessage());
        }
    }

    // =====================================================================
    //  COMANDOS
    // =====================================================================

    /** Comandos de una sola respuesta: LOGIN y EXIT. */
    private static void simple(DataInputStream entrada, DataOutputStream salida, String comando) throws IOException {
        Transferencia.enviarTexto(salida, comando);
        mostrarRespuesta(Transferencia.recibirTexto(entrada));
    }

    private static void listar(DataInputStream entrada, DataOutputStream salida) throws IOException {
        Transferencia.enviarTexto(salida, "LIST");
        String respuesta = Transferencia.recibirTexto(entrada);
        if (!respuesta.startsWith("OK")) {
            mostrarRespuesta(respuesta);
            return;
        }
        int cantidad = Integer.parseInt(respuesta.substring(3).trim());
        System.out.println();
        System.out.println(Color.pintar(String.format("\t%-40s %12s %16s", "ARCHIVO EN LA NUBE", "TAMAÑO", "BYTES"), Color.NEGRITA + Color.CIAN));
        System.out.println(Color.pintar("\t" + "─".repeat(70), Color.GRIS));
        long total = 0;
        for (int i = 0; i < cantidad; i++) {
            String[] datos = entrada.readUTF().split("\\|", 2);      // tamaño|nombre
            long bytes = Long.parseLong(datos[0]);
            total += bytes;
            System.out.printf("\t%-40s %12s %16s%n", datos[1], Transferencia.tamanioLegible(bytes), String.format("%,d", bytes));
        }
        if (cantidad == 0) {
            System.out.println(Color.pintar("\t(la nube está vacía)", Color.GRIS));
        }
        System.out.println(Color.pintar("\t" + "─".repeat(70), Color.GRIS));
        System.out.println("\t" + cantidad + " archivo(s), " + Transferencia.tamanioLegible(total) + " en total");
        System.out.println();
    }

    private static void subir(DataInputStream entrada, DataOutputStream salida, String nombre) throws IOException {
        if (nombre.isEmpty()) {
            Log.error("", "Uso: UPLOAD <nombre_archivo>");
            return;
        }
        nombre = nombre.replace("\"", "");
        // Se busca primero la ruta tal cual y si no, dentro de "mis_archivos"
        File archivo = new File(nombre);
        if (!archivo.isFile()) {
            archivo = new File(CARPETA_SUBIDAS, nombre);
        }
        if (!archivo.isFile()) {
            Log.error("", "No existe \"" + nombre + "\". Poné el archivo en la carpeta "
                    + CARPETA_SUBIDAS.getAbsolutePath() + " o escribí la ruta completa.");
            return;
        }

        long tamanio = archivo.length();
        // 1) Se avisa tamaño y nombre; el servidor contesta LISTO (o ERROR si no hay sesión)
        Transferencia.enviarTexto(salida, "UPLOAD " + tamanio + " " + archivo.getName());
        String respuesta = Transferencia.recibirTexto(entrada);
        if (!respuesta.equals("LISTO")) {
            mostrarRespuesta(respuesta);
            return;
        }

        // 2) Se leen los bytes del disco y se escriben en el socket
        Log.archivo("", "Subiendo " + archivo.getName() + " (" + Transferencia.tamanioLegible(tamanio) + ")...");
        long inicio = System.currentTimeMillis();
        String huellaLocal;
        try (InputStream lectura = new BufferedInputStream(new FileInputStream(archivo))) {
            huellaLocal = Transferencia.copiar(lectura, salida, tamanio);
        }

        // 3) El servidor confirma con la huella de lo que recibió
        respuesta = Transferencia.recibirTexto(entrada);
        long ms = System.currentTimeMillis() - inicio;
        if (respuesta.startsWith("OK")) {
            String huellaServidor = respuesta.substring(3).trim();
            Log.ok("", "UPLOAD completo: " + archivo.getName() + " — " + String.format("%,d", tamanio) + " bytes en " + ms + " ms");
            verificar(huellaLocal, huellaServidor);
        } else {
            mostrarRespuesta(respuesta);
        }
    }

    private static void descargar(DataInputStream entrada, DataOutputStream salida, String nombre) throws IOException {
        if (nombre.isEmpty()) {
            Log.error("", "Uso: DOWNLOAD <nombre_archivo>");
            return;
        }
        Transferencia.enviarTexto(salida, "DOWNLOAD " + nombre);
        String respuesta = Transferencia.recibirTexto(entrada);
        if (!respuesta.startsWith("OK")) {
            mostrarRespuesta(respuesta);
            return;
        }

        long tamanio = Long.parseLong(respuesta.substring(3).trim());
        File destino = new File(CARPETA_DESCARGAS, new File(nombre).getName());
        File temporal = new File(CARPETA_DESCARGAS, destino.getName() + ".descargando");

        // Se reciben los bytes del socket y se reconstruye el archivo en el disco
        Log.archivo("", "Descargando " + destino.getName() + " (" + Transferencia.tamanioLegible(tamanio) + ")...");
        long inicio = System.currentTimeMillis();
        String huellaLocal;
        try (OutputStream escritura = new BufferedOutputStream(new FileOutputStream(temporal))) {
            huellaLocal = Transferencia.copiar(entrada, escritura, tamanio);
        } catch (IOException e) {
            temporal.delete();
            throw e;
        }
        Files.move(temporal.toPath(), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);

        String huellaServidor = Transferencia.recibirTexto(entrada).substring(3).trim();
        long ms = System.currentTimeMillis() - inicio;
        Log.ok("", "DOWNLOAD completo: " + destino.getAbsolutePath() + " — " + String.format("%,d", tamanio) + " bytes en " + ms + " ms");
        verificar(huellaLocal, huellaServidor);
    }

    // =====================================================================
    //  AUXILIARES
    // =====================================================================

    private static void verificar(String huellaLocal, String huellaServidor) {
        if (huellaLocal.equals(huellaServidor)) {
            Log.ok("", "Integridad verificada: SHA-256 local = servidor = " + huellaLocal);
        } else {
            Log.error("", "¡El archivo llegó distinto! local " + huellaLocal + " distinto de servidor " + huellaServidor);
        }
    }

    private static void mostrarRespuesta(String respuesta) {
        if (respuesta.startsWith("OK")) {
            Log.ok("", respuesta.substring(2).trim());
        } else if (respuesta.startsWith("ERROR")) {
            Log.error("", respuesta.substring(5).trim());
        } else {
            Log.sistema(respuesta);
        }
    }

    private static void mostrarAyuda() {
        System.out.println();
        System.out.println(Color.pintar("\tCOMANDOS DISPONIBLES", Color.NEGRITA + Color.CIAN));
        System.out.println("\tLOGIN <usuario> <clave>\t\tinicia sesión (obligatorio primero)");
        System.out.println("\tLIST\t\t\t\tarchivos de la nube con su tamaño");
        System.out.println("\tUPLOAD <nombre_archivo>\t\tsube un archivo de la carpeta mis_archivos");
        System.out.println("\tDOWNLOAD <nombre_archivo>\tbaja un archivo a la carpeta descargas");
        System.out.println("\tEXIT\t\t\t\tcierra la sesión");
        System.out.println();
    }

    private static String preguntar(String mensaje) {
        System.out.print(mensaje);
        System.out.flush();
        try {
            String linea = TECLADO.readLine();
            return linea == null ? null : linea.trim();
        } catch (IOException e) {
            return null;
        }
    }
}
