import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

/**
 * MANEJADOR DE UN CLIENTE — se ejecuta en su propio hilo (implementa Runnable).
 *
 * LÓGICA DE HILOS:
 *  - Cada cliente conectado tiene su propio ManejadorCliente con sus propias variables
 *    (socket, streams, usuario logueado). Como no comparten esos datos, las sesiones
 *    no se interfieren entre sí.
 *  - Lo único compartido es la carpeta de la nube. Para que dos subidas simultáneas no
 *    dejen archivos a medio escribir, cada subida se escribe primero en un archivo temporal
 *    con nombre único y recién al terminar se renombra al nombre final (movimiento atómico).
 *
 * STREAMS:
 *  - entrada: DataInputStream(BufferedInputStream(socket.getInputStream()))
 *  - salida:  DataOutputStream(BufferedOutputStream(socket.getOutputStream()))
 *  - Comandos y respuestas viajan con writeUTF/readUTF; los archivos, como bytes crudos.
 *
 * PROTOCOLO (cliente → servidor):
 *  LOGIN usuario clave        → OK ... | ERROR ...
 *  LIST                       → OK cantidad, y luego una línea por archivo: tamaño|nombre
 *  UPLOAD tamaño nombre       → LISTO (el cliente envía los bytes) → OK huella
 *  DOWNLOAD nombre            → OK tamaño, luego los bytes, luego OK huella | ERROR ...
 *  EXIT                       → OK y se cierra la conexión
 */
public class ManejadorCliente implements Runnable {

    private final Socket socket;
    private final String ipRemota;
    private String usuario;          // null mientras no se haya autenticado
    private String origen;           // texto para el log: "Cliente-1 192.168.1.20"

    public ManejadorCliente(Socket socket) {
        this.socket = socket;
        this.ipRemota = socket.getInetAddress().getHostAddress() + ":" + socket.getPort();
    }

    @Override
    public void run() {
        // Thread.currentThread().getName() devuelve el nombre que le puso el ServidorNube ("Cliente-N")
        origen = Thread.currentThread().getName() + " " + socket.getInetAddress().getHostAddress();
        int activas = ServidorNube.SESIONES_ACTIVAS.incrementAndGet();
        Log.conexion(origen, "Nueva conexión desde " + Color.pintar(ipRemota, Color.NEGRITA)
                + "  → atendida en el hilo " + Thread.currentThread().getName()
                + "  (sesiones activas: " + activas + ")");

        // try-with-resources: al salir cierra los streams y el socket, pase lo que pase
        try (Socket s = socket;
             DataInputStream entrada = new DataInputStream(new BufferedInputStream(s.getInputStream()));
             DataOutputStream salida = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()))) {

            boolean seguir = true;
            while (seguir) {
                String linea = Transferencia.recibirTexto(entrada);   // espera el próximo comando
                String[] partes = linea.trim().split(" ", 2);
                String comando = partes[0].toUpperCase();
                String argumentos = partes.length > 1 ? partes[1].trim() : "";

                // El LOGIN se muestra sin la clave
                String paraLog = comando.equals("LOGIN") ? "LOGIN " + argumentos.split(" ")[0] + " ****" : linea;
                Log.comando(origen, paraLog);

                // Autenticación obligatoria antes de cualquier comando de archivos
                if (usuario == null && !comando.equals("LOGIN") && !comando.equals("EXIT")) {
                    Log.seguridad(origen, Color.pintar("Rechazado: " + comando + " sin autenticar", Color.ROJO));
                    Transferencia.enviarTexto(salida, "ERROR Primero tenés que iniciar sesión: LOGIN <usuario> <clave>");
                    continue;
                }

                switch (comando) {
                    case "LOGIN":    login(argumentos, salida); break;
                    case "LIST":     listar(salida); break;
                    case "UPLOAD":   recibirArchivo(argumentos, entrada, salida); break;
                    case "DOWNLOAD": enviarArchivo(argumentos, salida); break;
                    case "EXIT":
                        Transferencia.enviarTexto(salida, "OK Sesión finalizada. ¡Hasta luego!");
                        seguir = false;
                        break;
                    default:
                        Transferencia.enviarTexto(salida, "ERROR Comando desconocido: " + comando);
                }
            }
            Log.desconexion(origen, "El cliente envió EXIT. Streams y socket cerrados.");

        } catch (EOFException | SocketException e) {
            Log.desconexion(origen, "El cliente se desconectó sin avisar.");
        } catch (IOException e) {
            Log.error(origen, "Error de comunicación: " + e.getMessage());
        } finally {
            int quedan = ServidorNube.SESIONES_ACTIVAS.decrementAndGet();
            Log.sistema("Fin del hilo " + Thread.currentThread().getName() + ". Sesiones activas: " + quedan);
        }
    }

    // =====================================================================
    //  COMANDOS
    // =====================================================================

    private void login(String argumentos, DataOutputStream salida) throws IOException {
        String[] datos = argumentos.split(" ");
        if (datos.length != 2) {
            Transferencia.enviarTexto(salida, "ERROR Uso: LOGIN <usuario> <clave>");
            return;
        }
        String clave = ServidorNube.USUARIOS.get(datos[0]);
        if (clave != null && clave.equals(datos[1])) {
            usuario = datos[0];
            origen = Thread.currentThread().getName() + " " + usuario + "@" + socket.getInetAddress().getHostAddress();
            Log.seguridad(origen, Color.pintar("Inicio de sesión correcto", Color.VERDE));
            Transferencia.enviarTexto(salida, "OK Bienvenido/a, " + usuario + ". Ya podés usar LIST, UPLOAD y DOWNLOAD.");
        } else {
            Log.seguridad(origen, Color.pintar("Usuario o clave incorrectos (" + datos[0] + ")", Color.ROJO));
            Transferencia.enviarTexto(salida, "ERROR Usuario o clave incorrectos.");
        }
    }

    private void listar(DataOutputStream salida) throws IOException {
        File[] archivos = ServidorNube.CARPETA_NUBE.listFiles(f -> f.isFile() && !f.getName().startsWith("."));
        if (archivos == null) {
            archivos = new File[0];
        }
        Arrays.sort(archivos, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));

        // Primero la cantidad, después una línea por archivo con "tamaño|nombre"
        Transferencia.enviarTexto(salida, "OK " + archivos.length);
        for (File f : archivos) {
            salida.writeUTF(f.length() + "|" + f.getName());
        }
        salida.flush();
        Log.ok(origen, "Se enviaron " + archivos.length + " archivos en el listado.");
    }

    private void recibirArchivo(String argumentos, DataInputStream entrada, DataOutputStream salida) throws IOException {
        // Formato: UPLOAD <tamaño> <nombre>
        String[] datos = argumentos.split(" ", 2);
        long tamanio;
        try {
            tamanio = Long.parseLong(datos[0]);
        } catch (NumberFormatException e) {
            tamanio = -1;
        }
        if (datos.length < 2 || tamanio < 0) {
            Transferencia.enviarTexto(salida, "ERROR Uso: UPLOAD <nombre_archivo>");
            return;
        }
        String nombre = nombreSeguro(datos[1]);
        if (nombre.isEmpty() || nombre.startsWith(".")) {
            Transferencia.enviarTexto(salida, "ERROR Nombre de archivo inválido.");
            return;
        }

        // Se avisa al cliente que puede empezar a mandar los bytes
        Transferencia.enviarTexto(salida, "LISTO");

        // Archivo temporal con nombre único por hilo: dos subidas simultáneas no se pisan
        File temporal = new File(ServidorNube.CARPETA_NUBE, "." + Thread.currentThread().getName() + "-" + nombre + ".tmp");
        File destino = new File(ServidorNube.CARPETA_NUBE, nombre);
        long inicio = System.currentTimeMillis();

        String huella;
        try (OutputStream archivo = new BufferedOutputStream(new FileOutputStream(temporal))) {
            // Lee del socket exactamente 'tamanio' bytes y los escribe en el disco
            huella = Transferencia.copiar(entrada, archivo, tamanio);
        } catch (IOException e) {
            temporal.delete();
            throw e;                                   // conexión cortada a mitad: se informa arriba
        }
        Files.move(temporal.toPath(), destino.toPath(),
                StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);

        long ms = System.currentTimeMillis() - inicio;
        Log.archivo(origen, Color.pintar("SUBIDA completa: ", Color.VERDE) + nombre + "  ("
                + Transferencia.tamanioLegible(tamanio) + ", " + tamanio + " bytes, " + ms + " ms)  SHA-256: " + huella);
        Transferencia.enviarTexto(salida, "OK " + huella);
    }

    private void enviarArchivo(String argumentos, DataOutputStream salida) throws IOException {
        if (argumentos.isEmpty()) {
            Transferencia.enviarTexto(salida, "ERROR Uso: DOWNLOAD <nombre_archivo>");
            return;
        }
        File archivo = new File(ServidorNube.CARPETA_NUBE, nombreSeguro(argumentos));
        if (!archivo.isFile()) {
            Log.error(origen, "DOWNLOAD de un archivo que no existe: " + argumentos);
            Transferencia.enviarTexto(salida, "ERROR No existe el archivo \"" + argumentos + "\" en la nube. Usá LIST.");
            return;
        }

        long tamanio = archivo.length();
        Transferencia.enviarTexto(salida, "OK " + tamanio);        // 1) aviso del tamaño
        long inicio = System.currentTimeMillis();
        String huella;
        try (InputStream lectura = new BufferedInputStream(new FileInputStream(archivo))) {
            huella = Transferencia.copiar(lectura, salida, tamanio); // 2) los bytes, del disco al socket
        }
        Transferencia.enviarTexto(salida, "OK " + huella);         // 3) huella para verificar integridad

        long ms = System.currentTimeMillis() - inicio;
        Log.archivo(origen, Color.pintar("DESCARGA completa: ", Color.VERDE) + archivo.getName() + "  ("
                + Transferencia.tamanioLegible(tamanio) + ", " + tamanio + " bytes, " + ms + " ms)  SHA-256: " + huella);
    }

    /** Se queda solo con el nombre del archivo (evita rutas como ../../windows). */
    private static String nombreSeguro(String nombre) {
        String limpio = new File(nombre.trim()).getName();
        return limpio.replaceAll("[\\\\/:*?\"<>|]", "_");
    }
}
