import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Log en consola con hora, tipo de evento y color.
 *
 * Los métodos son "synchronized": como en el servidor varios hilos escriben al mismo
 * tiempo, así se evita que las líneas de dos clientes se mezclen en la pantalla.
 */
public class Log {

    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm:ss");

    public static synchronized void evento(String tipo, String color, String origen, String detalle) {
        String hora = Color.pintar("[" + LocalTime.now().format(HORA) + "]", Color.GRIS);
        String colTipo = Color.pintar(String.format("%-11s", tipo), Color.NEGRITA + color);
        String colOrigen = origen.isEmpty() ? "" : Color.pintar(String.format("%-32s", origen), Color.AMARILLO) + " ";
        System.out.println(hora + "  " + colTipo + " " + colOrigen + detalle);
    }

    public static void conexion(String origen, String d)    { evento("CONEXIÓN", Color.VERDE, origen, d); }
    public static void ok(String origen, String d)          { evento("OK", Color.VERDE, origen, d); }
    public static void comando(String origen, String d)     { evento("COMANDO", Color.CIAN, origen, d); }
    public static void archivo(String origen, String d)     { evento("ARCHIVO", Color.MAGENTA, origen, d); }
    public static void seguridad(String origen, String d)   { evento("SEGURIDAD", Color.MAGENTA, origen, d); }
    public static void desconexion(String origen, String d) { evento("DESCONEXIÓN", Color.AMARILLO, origen, d); }
    public static void error(String origen, String d)       { evento("ERROR", Color.ROJO, origen, d); }
    public static void sistema(String d)                    { evento("SISTEMA", Color.GRIS, "", d); }

    public static void titulo(String texto) {
        String linea = "═".repeat(texto.length() + 6);
        System.out.println();
        System.out.println(Color.pintar("╔" + linea + "╗", Color.AZUL));
        System.out.println(Color.pintar("║   ", Color.AZUL) + Color.pintar(texto, Color.NEGRITA + Color.BLANCO)
                + Color.pintar("   ║", Color.AZUL));
        System.out.println(Color.pintar("╚" + linea + "╝", Color.AZUL));
    }
}
