import java.io.File;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * SERVIDOR DE NUBE
 *
 * LÓGICA DE HILOS:
 *  - El hilo principal (main) solo hace una cosa: esperar conexiones con accept().
 *  - Cada vez que se conecta un cliente, crea un objeto ManejadorCliente con ese socket
 *    y lo ejecuta en un HILO NUEVO (new Thread(...).start()).
 *  - Así el main vuelve enseguida a accept() y puede recibir a otro usuario mientras
 *    el primero sigue subiendo o bajando archivos: ninguna sesión bloquea a las demás.
 *
 * Los archivos se guardan en la carpeta "nube_servidor" (se crea sola).
 */
public class ServidorNube {

    public static final int PUERTO = 6000;
    public static final File CARPETA_NUBE = new File("nube_servidor");

    /** Usuarios habilitados (usuario → clave). Map.of es inmutable: seguro para leer desde varios hilos. */
    public static final Map<String, String> USUARIOS = Map.of(
            "alumno", "1234",
            "admin", "admin123"
    );

    /** Cantidad de sesiones activas. AtomicInteger permite sumar/restar desde varios hilos sin errores. */
    public static final AtomicInteger SESIONES_ACTIVAS = new AtomicInteger(0);
    private static final AtomicInteger CONTADOR_CLIENTES = new AtomicInteger(0);

    public static void main(String[] args) {
        Log.titulo("SERVIDOR DE NUBE  ·  MULTIHILO  ·  PUERTO " + PUERTO);

        if (!CARPETA_NUBE.exists() && CARPETA_NUBE.mkdirs()) {
            Log.sistema("Se creó la carpeta de la nube: " + CARPETA_NUBE.getAbsolutePath());
        } else {
            Log.sistema("Carpeta de la nube: " + CARPETA_NUBE.getAbsolutePath());
        }
        mostrarIps();
        Log.sistema("Usuarios habilitados: " + USUARIOS.keySet());

        try (ServerSocket servidor = new ServerSocket(PUERTO)) {
            Log.sistema("Escuchando en el puerto " + PUERTO + ". Esperando clientes...");

            while (true) {
                // El hilo principal queda bloqueado acá hasta que llega una conexión
                Socket socket = servidor.accept();

                int numero = CONTADOR_CLIENTES.incrementAndGet();
                String nombreHilo = "Cliente-" + numero;

                // Se deriva la conexión a un hilo independiente y el main vuelve a escuchar
                Thread hilo = new Thread(new ManejadorCliente(socket), nombreHilo);
                hilo.start();
            }
        } catch (IOException e) {
            Log.error("", "No se pudo abrir el puerto " + PUERTO + ": " + e.getMessage()
                    + " (¿ya hay un servidor abierto?)");
        }
    }

    /** Muestra las IP de esta PC para que el cliente sepa a cuál conectarse. */
    private static void mostrarIps() {
        try {
            for (NetworkInterface red : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!red.isUp() || red.isLoopback() || red.isVirtual()) continue;
                for (InetAddress ip : Collections.list(red.getInetAddresses())) {
                    if (ip instanceof Inet4Address) {
                        Log.sistema("IP de esta PC: " + Color.pintar(ip.getHostAddress(), Color.NEGRITA + Color.BLANCO)
                                + "  (" + red.getDisplayName() + ")");
                    }
                }
            }
        } catch (SocketException e) {
            Log.sistema("No se pudieron listar las IP. Usá ipconfig para verla.");
        }
    }
}
