import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Envío y recepción de archivos por un socket (la usan el servidor y el cliente).
 *
 * STREAMS USADOS:
 *  - DataOutputStream / DataInputStream envuelven los streams del socket y permiten enviar
 *    tipos de Java: writeUTF/readUTF para los comandos y respuestas de texto,
 *    y write/read para los bytes crudos del archivo.
 *
 * CÓMO VIAJA UN ARCHIVO:
 *  1. Primero se avisa el tamaño (va dentro del mensaje de texto del protocolo).
 *  2. Después se envían los bytes del archivo, de a bloques de 8 KB leídos del disco.
 *  3. El que recibe lee EXACTAMENTE esa cantidad de bytes, ni uno más: así sabe dónde
 *     termina el archivo y dónde empieza el próximo mensaje, sin cerrar la conexión.
 *
 * Mientras se copian los bytes se calcula la huella SHA-256 para comprobar
 * que el archivo llegó idéntico al original.
 */
public class Transferencia {

    private static final int TAMANIO_BLOQUE = 8192;

    /**
     * Copia 'cantidad' bytes desde 'origen' hacia 'destino'.
     * Devuelve la huella SHA-256 (en hexadecimal) de los bytes copiados.
     */
    public static String copiar(InputStream origen, OutputStream destino, long cantidad) throws IOException {
        MessageDigest sha = crearSha256();
        byte[] bloque = new byte[TAMANIO_BLOQUE];
        long restantes = cantidad;

        while (restantes > 0) {
            int aLeer = (int) Math.min(bloque.length, restantes);
            int leidos = origen.read(bloque, 0, aLeer);       // bloquea hasta que haya datos
            if (leidos == -1) {
                throw new EOFException("la conexión se cortó: faltaban " + restantes + " bytes");
            }
            destino.write(bloque, 0, leidos);
            sha.update(bloque, 0, leidos);
            restantes -= leidos;
        }
        destino.flush();
        return aHex(sha.digest());
    }

    /** Envía una línea de texto del protocolo (comando o respuesta). */
    public static void enviarTexto(DataOutputStream salida, String texto) throws IOException {
        salida.writeUTF(texto);
        salida.flush();
    }

    /** Recibe una línea de texto del protocolo. */
    public static String recibirTexto(DataInputStream entrada) throws IOException {
        return entrada.readUTF();
    }

    /** Tamaño legible: 1536 → "1.5 KB". */
    public static String tamanioLegible(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.2f MB", bytes / (1024.0 * 1024));
    }

    private static MessageDigest crearSha256() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Java no tiene SHA-256", e);
        }
    }

    private static String aHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {                         // primeros 8 bytes alcanzan para comparar
            sb.append(String.format("%02x", bytes[i]));
        }
        return sb.toString();
    }
}
