# Nube con Sockets TCP y Hilos

Dos programas independientes: **ServidorNube** (multihilo) y **ClienteNube**.

| Clase | Qué hace |
|---|---|
| `ServidorNube.java` | Escucha en el puerto 6000 y deriva cada conexión a un hilo nuevo |
| `ManejadorCliente.java` | Atiende a un cliente en su propio hilo: LOGIN, LIST, UPLOAD, DOWNLOAD, EXIT |
| `ClienteNube.java` | Pide la IP del servidor y ofrece la consola de comandos |
| `Transferencia.java` | Envío/recepción de archivos por streams, con huella SHA-256 |
| `Log.java`, `Color.java` | Log en consola con colores |

- Carpeta de la nube (servidor): `nube_servidor/`
- Archivos a subir (cliente): `mis_archivos/`
- Archivos descargados (cliente): `descargas/`
- Usuarios: `alumno` / `1234` y `admin` / `admin123`

## Comandos del cliente

```
LOGIN <usuario> <clave>
LIST
UPLOAD <nombre_archivo>
DOWNLOAD <nombre_archivo>
EXIT
```

## Cómo probarlo en dos PCs (misma red Wi-Fi o cable)

1. Copiar esta carpeta a las dos PCs (se necesita Java JDK 11 o superior).
2. En la PC **servidor**: `0-PERMITIR-FIREWALL.bat` (una sola vez) y después `1-SERVIDOR.bat`.
3. En la PC **cliente**: `2-CLIENTE.bat` y escribir la IP que muestra el servidor.
4. `0-VER-IP-Y-USUARIO.bat` muestra el usuario de la PC e `ipconfig` para las capturas.
