@echo off
rem Abre el puerto TCP 6000 en el firewall de Windows (solo hace falta en la PC SERVIDOR).
rem Windows pide permiso de administrador.
net session >nul 2>&1
if errorlevel 1 (
  powershell -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)
netsh advfirewall firewall add rule name="TP Nube puerto 6000" dir=in action=allow protocol=TCP localport=6000
echo.
echo Listo: el puerto 6000 quedo permitido en el firewall.
pause
