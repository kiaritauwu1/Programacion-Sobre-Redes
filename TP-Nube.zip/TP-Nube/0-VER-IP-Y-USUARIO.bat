@echo off
chcp 65001 >nul
title IPCONFIG - %COMPUTERNAME%
echo ==================================================
echo   Usuario de la PC:  %USERNAME%
echo   Nombre de la PC:   %COMPUTERNAME%
echo ==================================================
echo.
whoami
echo.
ipconfig
echo.
pause
