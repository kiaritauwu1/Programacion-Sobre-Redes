# Chatbot de comercio electrónico con Sockets TCP

Sistema cliente–servidor en Java con `Socket` y `ServerSocket`, **sin hilos**: el servidor atiende a un único cliente a la vez y, cuando ese cliente sale, vuelve a esperar al siguiente. La comunicación es bidireccional y secuencial (pedido → respuesta).

Toda la información que viaja por la red (mensajes y archivos) va **encriptada con AES-128 (GCM)** en ambos extremos.

## Archivos

| Archivo | Para qué sirve |
|---|---|
| `ServidorTCP.java` | Servidor y chatbot: usuarios, arreglo de productos con stock, recepción de comprobantes |
| `ClienteTCP.java` | Cliente interactivo por consola con los comandos |
| `Chatbot.java` | Frases y soluciones comerciales precargadas, preguntas base |
| `Cripto.java` | Encriptación y desencriptación AES (`javax.crypto.Cipher`) |
| `Canal.java` | Envío y recepción de mensajes cifrados sobre el socket; cierre de streams y socket |
| `Protocolo.java` | Formato de los mensajes entre cliente y servidor |
| `Log.java` / `Color.java` | Log en tiempo real con tabulaciones y colores ANSI |

## Cómo ejecutarlo en dos computadoras

1. Copiar el proyecto en las dos computadoras (las dos necesitan la misma clave, que está en `Cripto.java`).
2. En la computadora **servidor**, ejecutar `ServidorTCP`. Al iniciar muestra su IP (por ejemplo `192.168.0.15`).
3. En la computadora **cliente**, ejecutar `ClienteTCP` e ingresar esa IP y el puerto `5000`.
4. Si no conecta, permitir Java en el firewall de Windows de la computadora servidor (puerto TCP 5000).

Para probar en una sola computadora, en el cliente apretar ENTER para usar `127.0.0.1`.

## Comandos del cliente

| Comando | Acción |
|---|---|
| `autenticar` | Valida usuario y clave (3 intentos como máximo) |
| `ayuda` | Muestra las preguntas base guiadas del chatbot |
| `ver stock <producto>` | Consulta existencias en el arreglo del servidor (`ver stock` solo: listado completo) |
| `subir comprobante` | Envía un archivo de hasta 10 MB al servidor (se verifica con SHA-256) |
| `ver historial de chat` | Repasa los mensajes enviados en la sesión |
| `salir` | Finaliza y cierra streams y socket |

Cualquier otro texto se envía como mensaje al chatbot (por ejemplo `Hola, tengo un problema con mi pedido`).

**Usuarios de prueba:** `alumno` / `1234` y `admin` / `admin123`

Los comprobantes recibidos se guardan en la carpeta `comprobantes_recibidos/` del servidor.

## Colores

Los colores ANSI se ven en la consola de IntelliJ, VS Code, Eclipse y Windows Terminal. En el CMD clásico de Windows pueden verse códigos raros: usar Windows Terminal.
