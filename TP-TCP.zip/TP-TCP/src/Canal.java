import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;

/**
 * Canal de comunicación cifrado sobre un Socket TCP (lo usan cliente y servidor).
 *
 * Cada mensaje viaja así:   [ tamaño (int, 4 bytes) | bytes encriptados con AES ]
 * El tamaño delante permite saber exactamente dónde termina cada mensaje,
 * sirva para texto o para el contenido de un archivo.
 */
public class Canal implements Closeable {

    /** Máximo que se acepta en un solo mensaje (protege de tamaños absurdos). */
    public static final int MAXIMO_BYTES = 12 * 1024 * 1024;

    private final Socket socket;
    private final DataInputStream entrada;
    private final DataOutputStream salida;
    private int ultimoCifrado;

    public Canal(Socket socket) throws IOException {
        this.socket = socket;
        this.salida = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
        this.entrada = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
    }

    // ---------- Bytes ----------

    public void enviarBytes(byte[] datos) throws IOException, GeneralSecurityException {
        byte[] cifrado = Cripto.encriptar(datos);
        salida.writeInt(cifrado.length);
        salida.write(cifrado);
        salida.flush();
        ultimoCifrado = cifrado.length;
    }

    public byte[] recibirBytes() throws IOException, GeneralSecurityException {
        int tamanio = entrada.readInt();          // bloquea hasta que llegue un mensaje
        if (tamanio <= 0 || tamanio > MAXIMO_BYTES) {
            throw new IOException("se recibió un tamaño de mensaje inválido (" + tamanio + " bytes)");
        }
        byte[] cifrado = new byte[tamanio];
        entrada.readFully(cifrado);
        ultimoCifrado = tamanio;
        return Cripto.desencriptar(cifrado);
    }

    // ---------- Texto ----------

    public void enviarTexto(String texto) throws IOException, GeneralSecurityException {
        enviarBytes(texto.getBytes(StandardCharsets.UTF_8));
    }

    public String recibirTexto() throws IOException, GeneralSecurityException {
        return new String(recibirBytes(), StandardCharsets.UTF_8);
    }

    // ---------- Datos de la conexión ----------

    /** Bytes cifrados del último mensaje enviado o recibido (para mostrar en el log). */
    public int getUltimoCifrado() {
        return ultimoCifrado;
    }

    public String getRemoto() {
        return socket.getInetAddress().getHostAddress() + ":" + socket.getPort();
    }

    /** Cierra en orden: stream de salida, stream de entrada y por último el socket. */
    @Override
    public void close() {
        try { salida.close(); } catch (IOException ignorada) { }
        try { entrada.close(); } catch (IOException ignorada) { }
        try { socket.close(); } catch (IOException ignorada) { }
    }
}
