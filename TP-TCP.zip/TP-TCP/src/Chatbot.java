import java.text.Normalizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Chatbot de comercio electrónico del servidor.
 * Responde de forma automática con un listado de frases y soluciones precargadas,
 * buscando palabras clave en el mensaje del cliente.
 */
public class Chatbot {

    public static final String MENU =
            "Menú de Soporte: 1. Estado de Envío | 2. Devoluciones | 3. Reclamos. "
            + "Por favor, introduzca un comando válido.";

    /** Preguntas base guiadas (se muestran con el comando "ayuda"). */
    public static final String[] PREGUNTAS_BASE = {
        "¿Cuál es el estado de mi envío?",
        "¿Cómo hago una devolución?",
        "Quiero hacer un reclamo",
        "¿Qué medios de pago aceptan?",
        "¿Cuál es el horario de atención?",
        "¿Cómo pido la factura de mi compra?"
    };

    /**
     * Frases precargadas: cada fila tiene las palabras clave (separadas por coma)
     * y la respuesta. Se revisan en orden; gana la primera que coincide.
     * Las palabras clave están sin tildes y en minúscula (el mensaje se normaliza igual).
     */
    private static final String[][] RESPUESTAS = {
        {"estado,envio,seguimiento,donde esta,llega,demora,tracking",
         "Estado de Envío: los pedidos se despachan dentro de las 48 h hábiles. "
         + "Con el número de pedido podés seguirlo en tienda.com/seguimiento. "
         + "Si pasaron más de 7 días sin novedades, escribí \"reclamo\"."},
        {"devol,cambio,reembolso,arrepent",
         "Devoluciones: tenés 10 días corridos desde que recibiste el producto (Botón de Arrepentimiento). "
         + "El producto tiene que estar sin uso y en su caja. El reembolso se acredita en 5 a 10 días hábiles."},
        {"reclamo,queja,roto,danado,falla,defectuoso,no funciona,incompleto",
         "Reclamos: lamentamos el inconveniente. Generamos el caso #R-" + 1000
         + ". Si tenés un comprobante o foto, usá el comando \"subir comprobante\" y un agente lo revisa en 24 h."},
        {"pago,tarjeta,cuota,transferencia,mercado pago,efectivo",
         "Medios de pago: tarjetas de crédito (hasta 6 cuotas sin interés), débito, Mercado Pago y transferencia. "
         + "Si pagaste por transferencia, enviá el comprobante con \"subir comprobante\"."},
        {"horario,atencion,atienden,abierto",
         "Horario de atención: lunes a viernes de 9 a 18 h y sábados de 9 a 13 h. El chatbot responde las 24 h."},
        {"factura,comprobante fiscal,cuit,afip,arca",
         "Facturación: la factura se envía por mail al despachar el pedido. "
         + "Si necesitás factura A, indicá tu CUIT y razón social."},
        {"precio,oferta,descuento,promo,cupon",
         "Promociones: esta semana 15% OFF en periféricos con el cupón TIENDA15. "
         + "Consultá existencias con el comando \"ver stock\"."},
        {"stock,hay,disponible,existencia",
         "Para consultar existencias usá el comando \"ver stock\" (necesitás estar autenticado)."},
        {"gracias,genial,perfecto,excelente",
         "¡De nada! ¿Te puedo ayudar con algo más? Escribí \"ayuda\" para ver las opciones."},
        {"chau,adios,hasta luego",
         "¡Gracias por comunicarte con TiendaNet! Para cerrar la sesión usá el comando \"salir\"."},
    };

    /** Respuestas a las preguntas base elegidas por número (1 a 6). */
    private static final int[] RESPUESTA_POR_NUMERO = {0, 1, 2, 3, 4, 5};

    private static final Pattern NOMBRE = Pattern.compile(
            "(?:mi nombre es|me llamo)\\s+([\\p{L}]+(?:\\s+[\\p{L}]+){0,3})", Pattern.CASE_INSENSITIVE);

    /** Si el mensaje dice "mi nombre es ..." o "me llamo ...", devuelve el nombre con mayúsculas. Si no, null. */
    public static String detectarNombre(String mensaje) {
        Matcher m = NOMBRE.matcher(mensaje);
        if (!m.find()) {
            return null;
        }
        StringBuilder nombre = new StringBuilder();
        for (String palabra : m.group(1).trim().split("\\s+")) {
            nombre.append(Character.toUpperCase(palabra.charAt(0)))
                  .append(palabra.substring(1).toLowerCase())
                  .append(" ");
        }
        return nombre.toString().trim();
    }

    /** Respuesta automática para un mensaje libre del cliente. */
    public static String responder(String mensaje, String nombreCliente) {
        String texto = normalizar(mensaje);

        // ¿Se presentó?
        String nombre = detectarNombre(mensaje);
        if (nombre != null) {
            return "¡Hola, " + nombre + "! Bienvenido/a al soporte de TiendaNet.\n" + MENU;
        }

        // ¿Eligió una pregunta base por número?
        if (texto.matches("[1-6]")) {
            return RESPUESTAS[RESPUESTA_POR_NUMERO[Integer.parseInt(texto) - 1]][1];
        }

        // Búsqueda por palabras clave
        for (String[] fila : RESPUESTAS) {
            for (String clave : fila[0].split(",")) {
                if (texto.contains(clave)) {
                    return fila[1];
                }
            }
        }

        // Saludo o problema general → menú de soporte
        String saludo = nombreCliente == null ? "" : nombreCliente + ", ";
        if (texto.matches(".*\\b(hola|buen dia|buenas|problema|pedido|compra|consulta|ayuda)\\b.*")) {
            return capitalizar(saludo) + MENU;
        }
        return "No entendí tu consulta" + (nombreCliente == null ? "" : ", " + nombreCliente) + ". " + MENU;
    }

    /** Menú completo de ayuda con las preguntas base y los comandos. */
    public static String ayuda() {
        StringBuilder sb = new StringBuilder();
        sb.append("PREGUNTAS BASE (escribí el número o la pregunta):\n");
        for (int i = 0; i < PREGUNTAS_BASE.length; i++) {
            sb.append("   ").append(i + 1).append(".\t").append(PREGUNTAS_BASE[i]).append("\n");
        }
        sb.append("COMANDOS DISPONIBLES:\n");
        sb.append("   autenticar\t\t\tvalida tu usuario y clave\n");
        sb.append("   ayuda\t\t\tmuestra este menú\n");
        sb.append("   ver stock <producto>\t\tconsulta existencias (requiere autenticar)\n");
        sb.append("   subir comprobante\t\tenvía un archivo al servidor (requiere autenticar)\n");
        sb.append("   ver historial de chat\trepasa los mensajes de la sesión\n");
        sb.append("   salir\t\t\tcierra la comunicación");
        return sb.toString();
    }

    /** Minúsculas y sin tildes, para comparar sin importar cómo se escribió. */
    public static String normalizar(String texto) {
        String sinTildes = Normalizer.normalize(texto, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return sinTildes.toLowerCase().trim();
    }

    private static String capitalizar(String texto) {
        return texto.isEmpty() ? texto : Character.toUpperCase(texto.charAt(0)) + texto.substring(1);
    }
}
