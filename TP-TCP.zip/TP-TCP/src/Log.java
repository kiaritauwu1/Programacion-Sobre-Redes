import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Log en tiempo real, igual en el cliente y en el servidor.
 *
 * Cada evento ocupa una fila con 3 columnas separadas por tabulaciones:
 *
 *   [hora]      TIPO DE EVENTO    │ detalle
 *                                 │ continuación del detalle (si tiene varias líneas)
 *
 * Colores:  verde = conexión / éxito     cian = recibido      azul = enviado
 *           magenta = seguridad          amarillo = aviso / desconexión
 *           rojo = error                 gris = sistema
 */
public class Log {

    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final int ANCHO_TIPO = 12;
    private static final String SANGRIA = "\t\t\t\t";   // alinea las líneas de continuación con la columna "detalle"

    /** Escribe un evento con su color. */
    public static void evento(String tipo, String color, String detalle) {
        String hora = Color.pintar("[" + LocalTime.now().format(HORA) + "]", Color.GRIS);
        String columnaTipo = Color.pintar(String.format("%-" + ANCHO_TIPO + "s", tipo), Color.NEGRITA + color);
        String barra = Color.pintar("│ ", Color.GRIS);

        String[] lineas = detalle.split("\n");
        System.out.println(hora + "\t" + columnaTipo + "\t" + barra + lineas[0]);
        for (int i = 1; i < lineas.length; i++) {
            System.out.println(SANGRIA + barra + lineas[i]);
        }
    }

    public static void conexion(String detalle)    { evento("CONEXIÓN", Color.VERDE, detalle); }
    public static void exito(String detalle)       { evento("OK", Color.VERDE, detalle); }
    public static void recibido(String detalle)    { evento("RECIBIDO", Color.CIAN, detalle); }
    public static void enviado(String detalle)     { evento("ENVIADO", Color.AZUL, detalle); }
    public static void comando(String detalle)     { evento("COMANDO", Color.MAGENTA, detalle); }
    public static void seguridad(String detalle)   { evento("SEGURIDAD", Color.MAGENTA, detalle); }
    public static void archivo(String detalle)     { evento("ARCHIVO", Color.CIAN, detalle); }
    public static void aviso(String detalle)       { evento("AVISO", Color.AMARILLO, detalle); }
    public static void desconexion(String detalle) { evento("DESCONEXIÓN", Color.AMARILLO, detalle); }
    public static void error(String detalle)       { evento("ERROR", Color.ROJO, detalle); }
    public static void sistema(String detalle)     { evento("SISTEMA", Color.GRIS, detalle); }

    /** Texto gris chico para indicar cuántos bytes cifrados viajaron. */
    public static String cifrado(int bytes) {
        return Color.pintar("  (AES: " + bytes + " bytes cifrados)", Color.GRIS);
    }

    /** Separador entre sesiones o bloques. */
    public static void separador() {
        System.out.println(Color.pintar("────────────────────────────────────────────────────────────────────────────────", Color.GRIS));
    }

    /** Cartel de título al iniciar cada programa. */
    public static void titulo(String texto) {
        String linea = "═".repeat(texto.length() + 6);
        System.out.println();
        System.out.println(Color.pintar("╔" + linea + "╗", Color.AZUL));
        System.out.println(Color.pintar("║   ", Color.AZUL) + Color.pintar(texto, Color.NEGRITA + Color.BLANCO)
                + Color.pintar("   ║", Color.AZUL));
        System.out.println(Color.pintar("╚" + linea + "╝", Color.AZUL));
    }
}
