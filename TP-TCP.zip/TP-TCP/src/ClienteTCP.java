import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.nio.file.Files;
import java.security.GeneralSecurityException;

/**
 * CLIENTE TCP — se conecta al chatbot del servidor.
 *
 * Comandos (se escriben tal cual en la consola):
 *   autenticar                 valida usuario y clave
 *   ayuda                      menú con las preguntas base del chatbot
 *   ver stock <producto>       existencias en el arreglo del servidor
 *   subir comprobante          envía un archivo al servidor
 *   ver historial de chat      mensajes enviados en la sesión
 *   salir                      cierra streams y socket
 * Cualquier otro texto se envía como mensaje de chat.
 *
 * Toda la información viaja encriptada con AES (ver Cripto y Canal).
 */
public class ClienteTCP {

    private static final String IP_POR_DEFECTO = "127.0.0.1";
    private static final int TIMEOUT_CONEXION_MS = 5000;
    private static final long MAX_ARCHIVO = 10 * 1024 * 1024;   // 10 MB

    private static final BufferedReader TECLADO = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) {
        Log.titulo("CLIENTE TCP  ·  SOPORTE TIENDANET  ·  AES");

        // 1) Datos del servidor
        String ip = preguntar("IP del servidor [ENTER = " + IP_POR_DEFECTO + "]: ");
        if (ip == null) return;
        if (ip.isEmpty()) ip = IP_POR_DEFECTO;
        String puertoTexto = preguntar("Puerto [ENTER = " + Protocolo.PUERTO + "]: ");
        if (puertoTexto == null) return;
        int puerto = Protocolo.PUERTO;
        if (!puertoTexto.isEmpty()) {
            try {
                puerto = Integer.parseInt(puertoTexto);
            } catch (NumberFormatException e) {
                Log.aviso("Puerto inválido, se usa " + Protocolo.PUERTO + ".");
            }
        }

        // 2) Conexión
        Log.sistema("Conectando a " + ip + ":" + puerto + "...");
        Socket socket = new Socket();
        try {
            socket.connect(new InetSocketAddress(ip, puerto), TIMEOUT_CONEXION_MS);
        } catch (IOException e) {
            Log.error("No se pudo conectar a " + ip + ":" + puerto + " → " + e.getMessage()
                    + "\nRevisá que el servidor esté abierto, la IP y el firewall.");
            try { socket.close(); } catch (IOException ignorada) { }
            return;
        }

        Canal canal;
        try {
            canal = new Canal(socket);
        } catch (IOException e) {
            Log.error("No se pudieron abrir los streams: " + e.getMessage());
            try { socket.close(); } catch (IOException ignorada) { }
            return;
        }
        Log.conexion("Conectado al servidor " + Color.pintar(canal.getRemoto(), Color.NEGRITA));
        Log.seguridad("Canal cifrado con AES-128 (GCM). Todo lo que se envía y recibe viaja encriptado.");
        Log.sistema("Escribí tu mensaje o un comando. Comandos: autenticar · ayuda · ver stock · "
                + "subir comprobante · ver historial de chat · salir");

        // 3) Bucle de comandos (secuencial: se envía un pedido y se espera su respuesta)
        boolean seguir = true;
        while (seguir) {
            Log.separador();
            String linea = preguntar(Color.pintar("Vos > ", Color.NEGRITA + Color.VERDE));
            if (linea == null) {
                linea = "salir";                  // se cerró la entrada: se sale prolijamente
            }
            if (linea.isEmpty()) {
                continue;
            }
            String comando = linea.toLowerCase().replaceAll("\\s+", " ").trim();

            try {
                if (comando.equals("salir")) {
                    seguir = salir(canal);
                } else if (comando.equals("ayuda")) {
                    seguir = enviarYMostrar(canal, Protocolo.armar(Protocolo.AYUDA), "Comando ayuda");
                } else if (comando.equals("autenticar")) {
                    seguir = autenticar(canal);
                } else if (comando.equals("ver stock") || comando.startsWith("ver stock ")) {
                    seguir = verStock(canal, linea.trim().substring("ver stock".length()).trim());
                } else if (comando.equals("subir comprobante")) {
                    seguir = subirComprobante(canal);
                } else if (comando.equals("ver historial de chat")) {
                    seguir = enviarYMostrar(canal, Protocolo.armar(Protocolo.HISTORIAL), "Comando ver historial de chat");
                } else {
                    seguir = enviarYMostrar(canal, Protocolo.armar(Protocolo.CHAT, linea),
                            "Mensaje: " + Color.pintar("\"" + linea + "\"", Color.BLANCO + Color.NEGRITA));
                }
            } catch (EOFException | SocketException e) {
                Log.desconexion("El servidor cerró la conexión.");
                seguir = false;
            } catch (IOException e) {
                Log.error("Error de comunicación: " + e.getMessage());
                seguir = false;
            } catch (GeneralSecurityException e) {
                Log.error("No se pudo encriptar/desencriptar (¿la clave del servidor es distinta?).");
            }
        }

        // 4) Liberar recursos: streams y socket
        canal.close();
        Log.desconexion("Streams y socket cerrados. Recursos de red liberados.");
    }

    // =====================================================================
    //  COMANDOS
    // =====================================================================

    private static boolean autenticar(Canal canal) throws IOException, GeneralSecurityException {
        String usuario = preguntar("   Usuario: ");
        String clave = preguntar("   Clave: ");
        if (usuario == null || clave == null) return false;
        return enviarYMostrar(canal, Protocolo.armar(Protocolo.AUTENTICAR, usuario, clave),
                "Comando autenticar — usuario \"" + usuario + "\", clave ****");
    }

    private static boolean verStock(Canal canal, String producto) throws IOException, GeneralSecurityException {
        if (producto.isEmpty()) {
            producto = preguntar("   Producto [ENTER = ver todos]: ");
            if (producto == null) return false;
        }
        return enviarYMostrar(canal, Protocolo.armar(Protocolo.STOCK, producto),
                "Comando ver stock" + (producto.isEmpty() ? " (todos)" : " — \"" + producto + "\""));
    }

    private static boolean subirComprobante(Canal canal) throws IOException, GeneralSecurityException {
        String ruta = preguntar("   Ruta del archivo: ");
        if (ruta == null) return false;
        ruta = ruta.replace("\"", "").trim();     // al arrastrar un archivo, Windows agrega comillas

        File archivo = new File(ruta);
        if (!archivo.isFile()) {
            Log.error("El archivo \"" + ruta + "\" no existe o es una carpeta.");
            return true;
        }
        if (archivo.length() == 0 || archivo.length() > MAX_ARCHIVO) {
            Log.error("El archivo tiene que pesar entre 1 byte y 10 MB (pesa " + archivo.length() + " bytes).");
            return true;
        }
        byte[] contenido = Files.readAllBytes(archivo.toPath());

        // 1) Pedido con nombre y tamaño
        canal.enviarTexto(Protocolo.armar(Protocolo.SUBIR, archivo.getName(), String.valueOf(contenido.length)));
        Log.enviado("Comando subir comprobante — \"" + archivo.getName() + "\" (" + contenido.length + " bytes)"
                + Log.cifrado(canal.getUltimoCifrado()));

        // 2) El servidor confirma si puede recibirlo
        String[] respuesta = recibirYMostrar(canal);
        if (respuesta[0].equals(Protocolo.CHAU)) return false;
        if (!respuesta[0].equals(Protocolo.LISTO)) return true;

        // 3) Envío del contenido encriptado
        String huella = Cripto.huella(contenido);
        canal.enviarBytes(contenido);
        Log.archivo("Enviados " + contenido.length + " bytes de \"" + archivo.getName() + "\"\nSHA-256: " + huella
                + Log.cifrado(canal.getUltimoCifrado()));

        // 4) Resultado final: se compara la huella para confirmar que llegó intacto
        respuesta = recibirYMostrar(canal);
        if (respuesta[0].equals(Protocolo.OK)) {
            if (respuesta[1].contains(huella)) {
                Log.exito("Integridad verificada: la huella SHA-256 del servidor coincide con la local.");
            } else {
                Log.error("La huella SHA-256 del servidor NO coincide: el archivo pudo haberse dañado.");
            }
        }
        return !respuesta[0].equals(Protocolo.CHAU);
    }

    private static boolean salir(Canal canal) throws IOException, GeneralSecurityException {
        enviarYMostrar(canal, Protocolo.armar(Protocolo.SALIR), "Comando salir");
        return false;
    }

    // =====================================================================
    //  ENVÍO / RECEPCIÓN
    // =====================================================================

    /** Envía un pedido, registra el envío y muestra la respuesta. Devuelve false si la sesión terminó. */
    private static boolean enviarYMostrar(Canal canal, String pedido, String descripcion)
            throws IOException, GeneralSecurityException {
        canal.enviarTexto(pedido);
        Log.enviado(descripcion + Log.cifrado(canal.getUltimoCifrado()));
        String[] respuesta = recibirYMostrar(canal);
        return !respuesta[0].equals(Protocolo.CHAU);
    }

    /** Recibe la respuesta del servidor, la desencripta y la muestra con el color de su estado. */
    private static String[] recibirYMostrar(Canal canal) throws IOException, GeneralSecurityException {
        String[] partes = Protocolo.partir(canal.recibirTexto(), 2);
        String estado = partes[0];
        String texto = partes.length > 1 ? partes[1] : "";
        String cifrado = Log.cifrado(canal.getUltimoCifrado());

        switch (estado) {
            case Protocolo.OK:
                Log.evento("RECIBIDO", Color.VERDE, Color.pintar("Bot [OK]: ", Color.NEGRITA + Color.VERDE) + texto + cifrado);
                break;
            case Protocolo.ERROR:
                Log.evento("RECIBIDO", Color.ROJO, Color.pintar("Bot [ERROR]: ", Color.NEGRITA + Color.ROJO) + texto + cifrado);
                break;
            case Protocolo.CHAU:
                Log.evento("RECIBIDO", Color.AMARILLO, Color.pintar("Bot [FIN]: ", Color.NEGRITA + Color.AMARILLO) + texto + cifrado);
                break;
            case Protocolo.LISTO:
                Log.evento("RECIBIDO", Color.CIAN, Color.pintar("Servidor: ", Color.NEGRITA) + texto + cifrado);
                break;
            default:
                Log.recibido(Color.pintar("Bot: ", Color.NEGRITA + Color.CIAN) + texto + cifrado);
        }
        return new String[]{estado, texto};
    }

    /** Lee una línea del teclado. Devuelve null si se cerró la entrada. */
    private static String preguntar(String mensaje) {
        System.out.print(mensaje);
        System.out.flush();
        try {
            String linea = TECLADO.readLine();
            return linea == null ? null : linea.trim();
        } catch (IOException e) {
            return null;
        }
    }
}
