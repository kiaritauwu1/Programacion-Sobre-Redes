import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.file.Files;
import java.security.GeneralSecurityException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;

/**
 * SERVIDOR TCP — Chatbot de comercio electrónico.
 *
 *  - Sin hilos: espera conexiones con accept() en un bucle infinito y atiende
 *    a UN cliente a la vez. Cuando ese cliente sale, vuelve a esperar al siguiente.
 *  - Toda la comunicación está encriptada con AES (ver Cripto y Canal).
 *  - Tiene precargados los usuarios, el arreglo de productos con su stock y las frases del chatbot.
 *
 * Ejecutar PRIMERO el servidor y después el cliente.
 */
public class ServidorTCP {

    public static final int PUERTO = Protocolo.PUERTO;

    // ---------- Datos precargados para las pruebas ----------

    private static final String[] PRODUCTOS = {
        "Notebook Lenovo IdeaPad", "Mouse inalámbrico", "Teclado mecánico", "Monitor 24 pulgadas",
        "Auriculares Bluetooth", "Webcam Full HD", "Disco SSD 1TB", "Pendrive 64GB",
        "Impresora multifunción", "Silla gamer"
    };
    private static final int[] CANTIDADES = {
        12, 45, 0, 7, 3, 18, 25, 120, 2, 9
    };

    private static final String[] USUARIOS = {"alumno", "admin"};
    private static final String[] CLAVES   = {"1234", "admin123"};
    private static final int MAX_INTENTOS = 3;

    private static final File CARPETA_COMPROBANTES = new File("comprobantes_recibidos");
    private static final long MAX_ARCHIVO = 10 * 1024 * 1024;   // 10 MB

    // ---------- Estado de la sesión del cliente actual ----------

    private static boolean autenticado;
    private static String usuario;
    private static int intentosFallidos;
    private static String nombreCliente;
    private static ArrayList<String> historial;

    public static void main(String[] args) {
        Log.titulo("SERVIDOR TCP  ·  CHATBOT TIENDANET  ·  AES");
        mostrarDirecciones();
        Log.seguridad("Canal cifrado con AES-128 (GCM). Clave compartida cargada.");

        try (ServerSocket servidor = new ServerSocket(PUERTO)) {
            while (true) {                                      // espera activa: atiende un cliente por vez
                Log.separador();
                Log.sistema("Esperando la conexión de un cliente en el puerto " + PUERTO + "...");
                Socket socket = servidor.accept();              // bloquea hasta que se conecte alguien
                atenderCliente(socket);
            }
        } catch (IOException e) {
            Log.error("No se pudo abrir el puerto " + PUERTO + ": " + e.getMessage()
                    + "\n¿Ya hay otro servidor abierto en ese puerto?");
        }
    }

    // =====================================================================
    //  ATENCIÓN DE UN CLIENTE (secuencial: pedido → respuesta → pedido...)
    // =====================================================================

    private static void atenderCliente(Socket socket) {
        autenticado = false;
        usuario = null;
        intentosFallidos = 0;
        nombreCliente = null;
        historial = new ArrayList<>();

        Canal canal;
        try {
            canal = new Canal(socket);
        } catch (IOException e) {
            Log.error("No se pudieron abrir los streams del cliente: " + e.getMessage());
            return;
        }
        String remoto = canal.getRemoto();
        Log.conexion("Cliente conectado desde " + Color.pintar(remoto, Color.NEGRITA));

        boolean seguir = true;
        while (seguir) {
            String pedido;
            try {
                pedido = canal.recibirTexto();
            } catch (GeneralSecurityException e) {
                Log.error("Llegó un mensaje que no se pudo desencriptar (¿clave distinta o datos alterados?)");
                seguir = responder(canal, Protocolo.ERROR, "No se pudo desencriptar tu mensaje.");
                continue;
            } catch (EOFException | SocketException e) {
                Log.desconexion("El cliente " + remoto + " se desconectó sin avisar.");
                break;
            } catch (IOException e) {
                Log.error("Error de comunicación: " + e.getMessage());
                break;
            }

            String[] partes = Protocolo.partir(pedido, 3);
            String comando = partes[0];
            String dato1 = partes.length > 1 ? partes[1] : "";
            String dato2 = partes.length > 2 ? partes[2] : "";

            switch (comando) {
                case Protocolo.CHAT:       seguir = procesarChat(canal, dato1); break;
                case Protocolo.AYUDA:      seguir = procesarAyuda(canal); break;
                case Protocolo.AUTENTICAR: seguir = procesarAutenticar(canal, dato1, dato2); break;
                case Protocolo.STOCK:      seguir = procesarStock(canal, dato1); break;
                case Protocolo.SUBIR:      seguir = procesarSubir(canal, dato1, dato2); break;
                case Protocolo.HISTORIAL:  seguir = procesarHistorial(canal); break;
                case Protocolo.SALIR:
                    Log.recibido("Comando " + Color.pintar("salir", Color.NEGRITA) + Log.cifrado(canal.getUltimoCifrado()));
                    registrar("salir");
                    responder(canal, Protocolo.CHAU, "Sesión finalizada. ¡Gracias por comunicarte con TiendaNet"
                            + (nombreCliente == null ? "" : ", " + nombreCliente) + "!");
                    seguir = false;
                    break;
                default:
                    Log.error("Comando desconocido recibido: " + comando);
                    seguir = responder(canal, Protocolo.ERROR, "Comando desconocido.");
            }
        }

        canal.close();
        Log.desconexion("Streams y socket de " + remoto + " cerrados. Recursos liberados.");
    }

    // =====================================================================
    //  COMANDOS
    // =====================================================================

    private static boolean procesarChat(Canal canal, String texto) {
        Log.recibido("Mensaje de chat: " + Color.pintar("\"" + texto + "\"", Color.BLANCO + Color.NEGRITA)
                + Log.cifrado(canal.getUltimoCifrado()));
        registrar(texto);

        String nombre = Chatbot.detectarNombre(texto);
        if (nombre != null) {
            nombreCliente = nombre;
            Log.exito("Cliente identificado como " + Color.pintar(nombre, Color.NEGRITA));
        }
        return responder(canal, Protocolo.INFO, Chatbot.responder(texto, nombreCliente));
    }

    private static boolean procesarAyuda(Canal canal) {
        Log.recibido("Comando " + Color.pintar("ayuda", Color.NEGRITA) + Log.cifrado(canal.getUltimoCifrado()));
        registrar("ayuda");
        return responder(canal, Protocolo.INFO, Chatbot.ayuda());
    }

    private static boolean procesarAutenticar(Canal canal, String user, String clave) {
        Log.recibido("Comando " + Color.pintar("autenticar", Color.NEGRITA) + " — usuario \"" + user
                + "\", clave ****" + Log.cifrado(canal.getUltimoCifrado()));
        registrar("autenticar (" + user + ")");

        for (int i = 0; i < USUARIOS.length; i++) {
            if (USUARIOS[i].equals(user) && CLAVES[i].equals(clave)) {
                autenticado = true;
                usuario = user;
                intentosFallidos = 0;
                Log.seguridad(Color.pintar("Autenticación EXITOSA", Color.VERDE) + " del usuario \"" + user + "\"");
                return responder(canal, Protocolo.OK, "Acceso concedido. Bienvenido/a, " + user
                        + ". Ya podés usar \"ver stock\" y \"subir comprobante\".");
            }
        }

        intentosFallidos++;
        int restantes = MAX_INTENTOS - intentosFallidos;
        Log.seguridad(Color.pintar("Autenticación FALLIDA", Color.ROJO) + " (usuario \"" + user + "\") — intento "
                + intentosFallidos + " de " + MAX_INTENTOS);
        if (restantes <= 0) {
            Log.aviso("Se superó el máximo de intentos. Se cierra la conexión por seguridad.");
            responder(canal, Protocolo.CHAU, "Usuario o clave incorrectos. Superaste los " + MAX_INTENTOS
                    + " intentos: se cierra la conexión por seguridad.");
            return false;
        }
        return responder(canal, Protocolo.ERROR, "Usuario o clave incorrectos. Te " + (restantes == 1 ? "queda 1 intento." : "quedan " + restantes + " intentos."));
    }

    private static boolean procesarStock(Canal canal, String producto) {
        Log.recibido("Comando " + Color.pintar("ver stock", Color.NEGRITA)
                + (producto.isEmpty() ? " (todos)" : " — producto \"" + producto + "\"")
                + Log.cifrado(canal.getUltimoCifrado()));
        registrar("ver stock " + producto);
        if (!autenticado) {
            Log.aviso("Consulta de stock rechazada: el cliente no está autenticado.");
            return responder(canal, Protocolo.ERROR, "Primero tenés que autenticarte (comando: autenticar).");
        }

        // Sin producto: se devuelve el listado completo
        if (producto.trim().isEmpty()) {
            StringBuilder tabla = new StringBuilder("STOCK COMPLETO:\n");
            for (int i = 0; i < PRODUCTOS.length; i++) {
                tabla.append(String.format("   %-26s %5d u.   %s%n", PRODUCTOS[i], CANTIDADES[i], estadoStock(CANTIDADES[i])));
            }
            Log.comando("Se envía el listado completo (" + PRODUCTOS.length + " productos).");
            return responder(canal, Protocolo.OK, tabla.toString().trim());
        }

        // Búsqueda en el arreglo: primero exacta, después por coincidencia parcial
        String buscado = Chatbot.normalizar(producto);
        ArrayList<Integer> encontrados = new ArrayList<>();
        for (int i = 0; i < PRODUCTOS.length; i++) {
            if (Chatbot.normalizar(PRODUCTOS[i]).equals(buscado)) {
                encontrados.clear();
                encontrados.add(i);
                break;
            }
            if (Chatbot.normalizar(PRODUCTOS[i]).contains(buscado)) {
                encontrados.add(i);
            }
        }

        if (encontrados.isEmpty()) {
            Log.aviso("Producto \"" + producto + "\" no encontrado en el arreglo.");
            return responder(canal, Protocolo.ERROR, "No existe el producto \"" + producto + "\". "
                    + "Escribí \"ver stock\" sin producto para ver el listado completo.");
        }
        if (encontrados.size() > 1) {
            StringBuilder opciones = new StringBuilder("Hay " + encontrados.size() + " productos que coinciden, sé más específico:\n");
            for (int i : encontrados) {
                opciones.append("   - ").append(PRODUCTOS[i]).append("\n");
            }
            Log.aviso("Búsqueda ambigua: " + encontrados.size() + " coincidencias para \"" + producto + "\".");
            return responder(canal, Protocolo.INFO, opciones.toString().trim());
        }

        int i = encontrados.get(0);
        Log.comando("Stock consultado: " + PRODUCTOS[i] + " = " + CANTIDADES[i] + " unidades.");
        return responder(canal, Protocolo.OK, "Producto:\t" + PRODUCTOS[i] + "\nExistencias:\t"
                + CANTIDADES[i] + " unidades\nEstado:\t\t" + estadoStock(CANTIDADES[i]));
    }

    private static boolean procesarSubir(Canal canal, String nombreArchivo, String tamanioTexto) {
        Log.recibido("Comando " + Color.pintar("subir comprobante", Color.NEGRITA) + " — archivo \"" + nombreArchivo
                + "\" (" + tamanioTexto + " bytes)" + Log.cifrado(canal.getUltimoCifrado()));
        registrar("subir comprobante " + nombreArchivo);

        long tamanio;
        try {
            tamanio = Long.parseLong(tamanioTexto);
        } catch (NumberFormatException e) {
            tamanio = -1;
        }
        if (!autenticado) {
            Log.aviso("Transferencia rechazada: el cliente no está autenticado.");
            return responder(canal, Protocolo.ERROR, "Primero tenés que autenticarte (comando: autenticar).");
        }
        if (tamanio <= 0 || tamanio > MAX_ARCHIVO) {
            Log.aviso("Transferencia rechazada: tamaño inválido (" + tamanioTexto + " bytes).");
            return responder(canal, Protocolo.ERROR, "El archivo tiene que pesar entre 1 byte y 10 MB.");
        }

        // 1) Avisar al cliente que puede enviar el contenido
        if (!responder(canal, Protocolo.LISTO, "Servidor listo para recibir el archivo.")) {
            return false;
        }

        // 2) Recibir el contenido (encriptado) y guardarlo
        try {
            byte[] contenido = canal.recibirBytes();
            Log.archivo("Recibidos " + contenido.length + " bytes de \"" + nombreArchivo + "\""
                    + Log.cifrado(canal.getUltimoCifrado()));
            if (contenido.length != tamanio) {
                Log.error("El archivo llegó incompleto (" + contenido.length + " de " + tamanio + " bytes).");
                return responder(canal, Protocolo.ERROR, "El archivo llegó incompleto. Intentá de nuevo.");
            }

            CARPETA_COMPROBANTES.mkdirs();
            String seguro = new File(nombreArchivo).getName().replaceAll("[^\\w.\\-]", "_");
            String marca = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            File destino = new File(CARPETA_COMPROBANTES, marca + "_" + usuario + "_" + seguro);
            Files.write(destino.toPath(), contenido);

            String huella = Cripto.huella(contenido);
            Log.archivo(Color.pintar("Guardado: ", Color.VERDE) + destino.getPath() + "\nSHA-256: " + huella);
            return responder(canal, Protocolo.OK, "Comprobante recibido y guardado como " + destino.getName()
                    + "\nTamaño: " + contenido.length + " bytes\nSHA-256: " + huella);

        } catch (GeneralSecurityException e) {
            Log.error("No se pudo desencriptar el archivo recibido.");
            return responder(canal, Protocolo.ERROR, "No se pudo desencriptar el archivo.");
        } catch (IOException e) {
            Log.error("Error al recibir o guardar el archivo: " + e.getMessage());
            return responder(canal, Protocolo.ERROR, "Error al guardar el archivo en el servidor.");
        }
    }

    private static boolean procesarHistorial(Canal canal) {
        Log.recibido("Comando " + Color.pintar("ver historial de chat", Color.NEGRITA) + Log.cifrado(canal.getUltimoCifrado()));
        StringBuilder sb = new StringBuilder("HISTORIAL DE LA SESIÓN (" + historial.size() + " mensajes enviados):\n");
        if (historial.isEmpty()) {
            sb.append("   (todavía no enviaste mensajes)");
        }
        for (int i = 0; i < historial.size(); i++) {
            sb.append(String.format("   %2d.  %s%n", i + 1, historial.get(i)));
        }
        registrar("ver historial de chat");
        return responder(canal, Protocolo.INFO, sb.toString().trim());
    }

    // =====================================================================
    //  AUXILIARES
    // =====================================================================

    /** Envía la respuesta encriptada y la registra en el log. Devuelve false si se perdió la conexión. */
    private static boolean responder(Canal canal, String estado, String texto) {
        try {
            canal.enviarTexto(Protocolo.armar(estado, texto));
            Log.enviado("[" + estado + "] " + texto + Log.cifrado(canal.getUltimoCifrado()));
            return true;
        } catch (IOException | GeneralSecurityException e) {
            Log.error("No se pudo enviar la respuesta: " + e.getMessage());
            return false;
        }
    }

    private static void registrar(String mensaje) {
        historial.add("[" + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) + "]  " + mensaje);
    }

    private static String estadoStock(int cantidad) {
        if (cantidad == 0) return "SIN STOCK";
        if (cantidad < 5) return "ÚLTIMAS UNIDADES";
        return "DISPONIBLE";
    }

    /** Muestra las IP de esta computadora para que el cliente sepa a cuál conectarse. */
    private static void mostrarDirecciones() {
        ArrayList<String> ips = new ArrayList<>();
        try {
            for (NetworkInterface red : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!red.isUp() || red.isLoopback()) continue;
                for (InetAddress ip : Collections.list(red.getInetAddresses())) {
                    if (ip instanceof Inet4Address) {
                        ips.add(ip.getHostAddress() + "  (" + red.getDisplayName() + ")");
                    }
                }
            }
        } catch (SocketException e) {
            // si no se pueden listar, se muestra solo localhost
        }
        StringBuilder sb = new StringBuilder("Conectate desde el cliente a alguna de estas IP, puerto " + PUERTO + ":");
        for (String ip : ips) {
            sb.append("\n   ").append(Color.pintar(ip, Color.NEGRITA));
        }
        sb.append("\n   127.0.0.1  (misma computadora)");
        Log.sistema(sb.toString());
    }
}
