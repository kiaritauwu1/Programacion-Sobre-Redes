/**
 * Mensajes que se intercambian cliente y servidor (siempre viajan encriptados).
 *
 * Pedido del cliente:     COMANDO|dato1|dato2
 * Respuesta del servidor: ESTADO|texto
 *
 * La comunicación es secuencial: el cliente envía un pedido y espera la respuesta
 * antes de enviar el siguiente.
 */
public class Protocolo {

    public static final int PUERTO = 5000;
    public static final String SEP = "|";

    // Comandos del cliente
    public static final String CHAT = "CHAT";             // CHAT|texto libre
    public static final String AYUDA = "AYUDA";           // AYUDA
    public static final String AUTENTICAR = "AUTENTICAR"; // AUTENTICAR|usuario|clave
    public static final String STOCK = "STOCK";           // STOCK|producto   (vacío = todos)
    public static final String SUBIR = "SUBIR";           // SUBIR|nombreArchivo|tamaño   → luego los bytes
    public static final String HISTORIAL = "HISTORIAL";   // HISTORIAL
    public static final String SALIR = "SALIR";           // SALIR

    // Estados de la respuesta del servidor
    public static final String OK = "OK";
    public static final String ERROR = "ERROR";
    public static final String INFO = "INFO";
    public static final String LISTO = "LISTO";           // el servidor está listo para recibir el archivo
    public static final String CHAU = "CHAU";             // el servidor confirma el cierre

    public static String armar(String... partes) {
        return String.join(SEP, partes);
    }

    /** Separa un mensaje en como máximo 'cantidad' partes (la última puede contener '|'). */
    public static String[] partir(String mensaje, int cantidad) {
        return mensaje.split("\\" + SEP, cantidad);
    }
}
