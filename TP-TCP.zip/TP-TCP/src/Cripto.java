import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Encriptación y desencriptación de TODO lo que viaja por la red (en ambos extremos).
 *
 * Algoritmo: AES de 128 bits en modo GCM (javax.crypto.Cipher, "AES/GCM/NoPadding").
 *  - La clave sale de una frase secreta compartida que tienen cliente y servidor
 *    (se le aplica SHA-256 y se usan los primeros 16 bytes).
 *  - Cada mensaje usa un IV aleatorio, así el mismo texto nunca viaja igual dos veces.
 *  - GCM detecta si el mensaje fue alterado en el camino o si la clave no coincide.
 *
 * Formato de cada mensaje cifrado:  [ IV (12 bytes) | datos cifrados + etiqueta GCM (16 bytes) ]
 *
 * IMPORTANTE: el cliente y el servidor tienen que tener la MISMA frase secreta.
 */
public class Cripto {

    private static final String FRASE_SECRETA = "TP-Sockets-TCP-Chatbot-Clave-Compartida-2026";

    private static final String TRANSFORMACION = "AES/GCM/NoPadding";
    private static final int BYTES_IV = 12;
    private static final int BITS_TAG = 128;

    private static final SecretKey CLAVE = derivarClave(FRASE_SECRETA);
    private static final SecureRandom ALEATORIO = new SecureRandom();

    private static SecretKey derivarClave(String frase) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(frase.getBytes(StandardCharsets.UTF_8));
            return new SecretKeySpec(Arrays.copyOf(hash, 16), "AES");
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Java no tiene SHA-256 disponible", e);
        }
    }

    public static byte[] encriptar(byte[] datos) throws GeneralSecurityException {
        byte[] iv = new byte[BYTES_IV];
        ALEATORIO.nextBytes(iv);

        Cipher cipher = Cipher.getInstance(TRANSFORMACION);
        cipher.init(Cipher.ENCRYPT_MODE, CLAVE, new GCMParameterSpec(BITS_TAG, iv));
        byte[] cifrado = cipher.doFinal(datos);

        byte[] resultado = new byte[BYTES_IV + cifrado.length];
        System.arraycopy(iv, 0, resultado, 0, BYTES_IV);
        System.arraycopy(cifrado, 0, resultado, BYTES_IV, cifrado.length);
        return resultado;
    }

    public static byte[] desencriptar(byte[] datos) throws GeneralSecurityException {
        if (datos.length < BYTES_IV + BITS_TAG / 8) {
            throw new GeneralSecurityException("mensaje cifrado incompleto");
        }
        Cipher cipher = Cipher.getInstance(TRANSFORMACION);
        cipher.init(Cipher.DECRYPT_MODE, CLAVE, new GCMParameterSpec(BITS_TAG, datos, 0, BYTES_IV));
        return cipher.doFinal(datos, BYTES_IV, datos.length - BYTES_IV);
    }

    /** Huella SHA-256 (primeros 16 caracteres) para verificar que un archivo llegó intacto. */
    public static String huella(byte[] datos) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(datos);
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                hex.append(String.format("%02x", hash[i]));
            }
            return hex.toString();
        } catch (GeneralSecurityException e) {
            return "????????????????";
        }
    }
}
